# 🏦 Crédit TT — Portail de Gestion des Crédits
### Tunisie Telecom — Application Web

---

## 📋 Prérequis

- **XAMPP** (Apache + MySQL + PHP 7.4+)
- Navigateur moderne (Chrome, Firefox, Edge)

---

## 🚀 Installation sous XAMPP

### Étape 1 — Copier le projet
Copiez le dossier `credit_tt/` dans :
```
C:\xampp\htdocs\credit_tt\
```

### Étape 2 — Démarrer XAMPP
Lancez **Apache** et **MySQL** depuis le panneau de contrôle XAMPP.

### Étape 3 — Créer la base de données
1. Ouvrez votre navigateur → `http://localhost/phpmyadmin`
2. Cliquez sur **"Nouvelle base de données"**
3. Nom : `credit_tt` → Cliquez **Créer**
4. Sélectionnez la base `credit_tt`
5. Cliquez sur l'onglet **SQL**
6. Copiez-collez le contenu du fichier `database/schema.sql`
7. Cliquez **Exécuter**

### Étape 4 — Configurer la connexion
Ouvrez `config/database.php` et vérifiez :
```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'credit_tt');
define('DB_USER', 'root');
define('DB_PASS', '');  // Laissez vide pour XAMPP par défaut
```

### Étape 5 — Accéder à l'application
Ouvrez : **http://localhost/credit_tt/**

---

## 🔑 Comptes de test

| Rôle | Matricule | Mot de passe |
|------|-----------|--------------|
| Admin | `00001` | `password` |
| Employé | `11111` | `password` |
| Employé | `22222` | `password` |

---

## 📁 Structure du projet

```
credit_tt/
├── assets/
│   ├── css/style.css          # Feuille de style principale
│   ├── js/app.js              # JavaScript + génération PDF
│   └── images/                # (logo, etc.)
├── config/
│   ├── config.php             # Configuration globale
│   └── database.php           # Connexion PDO MySQL
├── database/
│   └── schema.sql             # Script SQL complet
├── includes/
│   ├── auth_helper.php        # Fonctions d'authentification
│   ├── header.php             # En-tête HTML
│   ├── footer.php             # Pied de page HTML
│   ├── sidebar.php            # Barre de navigation latérale
│   └── navbar.php             # Barre de navigation supérieure
├── auth/
│   ├── login.php              # Page de connexion
│   ├── register.php           # Page d'inscription
│   └── logout.php             # Déconnexion
├── dashboard/
│   └── index.php              # Tableau de bord
├── credits/
│   ├── list.php               # Liste des demandes
│   ├── create.php             # Nouvelle demande
│   ├── view.php               # Détail d'une demande
│   ├── edit.php               # Modifier une demande
│   └── delete.php             # Supprimer une demande
├── admin/
│   ├── all_credits.php        # Admin: tous les crédits
│   └── users.php              # Admin: utilisateurs
├── index.php                  # Point d'entrée (redirection)
└── README.md                  # Ce fichier
```

---

## ✨ Fonctionnalités

- ✅ Authentification sécurisée (inscription, connexion, sessions PHP)
- ✅ Hashage des mots de passe (bcrypt)
- ✅ Tableau de bord avec statistiques
- ✅ Gestion complète des demandes (CRUD)
- ✅ 3 types de crédits (Solfa, Personnel, Consommation)
- ✅ Filtres et pagination
- ✅ Simulateur de mensualité
- ✅ Génération PDF professionnelle (jsPDF)
- ✅ Interface responsive (Bootstrap 5)
- ✅ Panel administrateur
- ✅ Protection CSRF basique

---

## 🛠️ Technologies

| Couche | Technologies |
|--------|-------------|
| Frontend | HTML5, CSS3, JavaScript, Bootstrap 5 |
| Backend | PHP 7.4+ (procédural + PDO) |
| Base de données | MySQL 5.7+ |
| PDF | jsPDF 2.5 |
| Icônes | FontAwesome 6 |
| Polices | Sora + IBM Plex Sans |

---

© 2025 Tunisie Telecom. Développé par Nour Lassoued.
