<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/auth_helper.php';

requireLogin();

$pageTitle  = 'Tableau de bord';
$breadcrumb = [];

$user = getCurrentUser();
$db   = getDB();

// Statistiques
$stmt = $db->prepare("SELECT COUNT(*) FROM credits WHERE user_id = ?");
$stmt->execute([$user['id']]);
$total = $stmt->fetchColumn();

$stmt = $db->prepare("SELECT COUNT(*) FROM credits WHERE user_id = ? AND statut = 'En attente'");
$stmt->execute([$user['id']]);
$pending = $stmt->fetchColumn();

$stmt = $db->prepare("SELECT COUNT(*) FROM credits WHERE user_id = ? AND statut = 'Accepté'");
$stmt->execute([$user['id']]);
$accepted = $stmt->fetchColumn();

$stmt = $db->prepare("SELECT COUNT(*) FROM credits WHERE user_id = ? AND statut = 'Refusé'");
$stmt->execute([$user['id']]);
$refused = $stmt->fetchColumn();

$stmt = $db->prepare("SELECT COALESCE(SUM(montant),0) FROM credits WHERE user_id = ? AND statut = 'Accepté'");
$stmt->execute([$user['id']]);
$totalMontant = $stmt->fetchColumn();

// Dernières demandes
$stmt = $db->prepare("SELECT * FROM credits WHERE user_id = ? ORDER BY created_at DESC LIMIT 5");
$stmt->execute([$user['id']]);
$recentCredits = $stmt->fetchAll();

// Répartition par type
$stmt = $db->prepare("SELECT type_credit, COUNT(*) as nb FROM credits WHERE user_id = ? GROUP BY type_credit");
$stmt->execute([$user['id']]);
$byType = $stmt->fetchAll();

require_once '../includes/header.php';
?>
<div class="d-flex">
<?php require_once '../includes/sidebar.php'; ?>
<?php require_once '../includes/navbar.php'; ?>

<!-- Stats -->
<div class="stats-grid">
    <div class="stat-card primary">
        <div class="stat-icon"><i class="fa fa-file-alt"></i></div>
        <div>
            <div class="stat-value"><?= $total ?></div>
            <div class="stat-label">Total Demandes</div>
        </div>
    </div>
    <div class="stat-card warning">
        <div class="stat-icon"><i class="fa fa-clock"></i></div>
        <div>
            <div class="stat-value"><?= $pending ?></div>
            <div class="stat-label">En Attente</div>
        </div>
    </div>
    <div class="stat-card success">
        <div class="stat-icon"><i class="fa fa-check-circle"></i></div>
        <div>
            <div class="stat-value"><?= $accepted ?></div>
            <div class="stat-label">Acceptées</div>
        </div>
    </div>
    <div class="stat-card danger">
        <div class="stat-icon"><i class="fa fa-times-circle"></i></div>
        <div>
            <div class="stat-value"><?= $refused ?></div>
            <div class="stat-label">Refusées</div>
        </div>
    </div>
    <div class="stat-card secondary">
        <div class="stat-icon"><i class="fa fa-coins"></i></div>
        <div>
            <div class="stat-value"><?= number_format($totalMontant, 0, ',', ' ') ?></div>
            <div class="stat-label">DT Accordés</div>
        </div>
    </div>
</div>

<div class="row g-4">
    <!-- Dernières demandes -->
    <div class="col-lg-8">
        <div class="card-tt">
            <div class="card-tt-header">
                <div class="card-tt-title">
                    <i class="fa fa-list-ul"></i>
                    Mes dernières demandes
                </div>
                <a href="<?= BASE_URL ?>/credits/list.php" class="btn btn-outline-primary btn-sm">
                    Voir tout <i class="fa fa-arrow-right ms-1"></i>
                </a>
            </div>
            <?php if (empty($recentCredits)): ?>
            <div class="empty-state">
                <i class="fa fa-folder-open"></i>
                <h5>Aucune demande</h5>
                <p>Vous n'avez pas encore soumis de demande de crédit.</p>
                <a href="<?= BASE_URL ?>/credits/create.php" class="btn btn-primary btn-sm">
                    <i class="fa fa-plus me-1"></i> Nouvelle demande
                </a>
            </div>
            <?php else: ?>
            <div class="table-responsive">
                <table class="table-tt">
                    <thead>
                        <tr>
                            <th>Référence</th>
                            <th>Type</th>
                            <th>Montant</th>
                            <th>Échéance</th>
                            <th>Date</th>
                            <th>Statut</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($recentCredits as $c): ?>
                        <?php
                        $badgeClass = match($c['statut']) {
                            'Accepté' => 'accepte',
                            'Refusé'  => 'refuse',
                            default   => 'attente'
                        };
                        $badgeIcon = match($c['statut']) {
                            'Accepté' => 'fa-check-circle',
                            'Refusé'  => 'fa-times-circle',
                            default   => 'fa-clock'
                        };
                        ?>
                        <tr data-href="<?= BASE_URL ?>/credits/view.php?id=<?= $c['id'] ?>">
                            <td><span class="ref-cell"><?= sanitize($c['reference']) ?></span></td>
                            <td><span class="badge-type"><?= sanitize($c['type_credit']) ?></span></td>
                            <td class="fw-700"><?= number_format($c['montant'], 0, ',', ' ') ?> DT</td>
                            <td><?= $c['echeance'] ?> mois</td>
                            <td><?= date('d/m/Y', strtotime($c['date_depot'])) ?></td>
                            <td>
                                <span class="badge-statut <?= $badgeClass ?>">
                                    <i class="fa <?= $badgeIcon ?>"></i>
                                    <?= $c['statut'] ?>
                                </span>
                            </td>
                            <td>
                                <a href="<?= BASE_URL ?>/credits/view.php?id=<?= $c['id'] ?>" class="btn-action view" title="Consulter">
                                    <i class="fa fa-eye"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Sidebar cards -->
    <div class="col-lg-4">
        <!-- Profil card -->
        <div class="card-tt mb-4">
            <div class="card-tt-header">
                <div class="card-tt-title"><i class="fa fa-user-circle"></i> Mon Profil</div>
            </div>
            <div class="card-tt-body text-center">
                <div class="user-avatar mx-auto mb-3" style="width:60px;height:60px;font-size:1.2rem;background:var(--primary);">
                    <?= strtoupper(substr($user['prenom'],0,1) . substr($user['nom'],0,1)) ?>
                </div>
                <div class="fw-700 font-sora" style="font-size:1rem;"><?= sanitize($user['prenom'] . ' ' . $user['nom']) ?></div>
                <div style="font-size:.8rem;color:var(--text-muted);"><?= sanitize($user['email']) ?></div>
                <div class="mt-2">
                    <span class="badge-type">Mat: <?= sanitize($user['matricule']) ?></span>
                </div>
                <div class="mt-3 pt-3" style="border-top:1px solid var(--border);font-size:.78rem;color:var(--text-light);">
                    Membre depuis <?= date('F Y', strtotime($user['created_at'])) ?>
                </div>
            </div>
        </div>

        <!-- Répartition par type -->
        <?php if (!empty($byType)): ?>
        <div class="card-tt">
            <div class="card-tt-header">
                <div class="card-tt-title"><i class="fa fa-chart-pie"></i> Par type de crédit</div>
            </div>
            <div class="card-tt-body">
                <?php foreach ($byType as $t):
                    $pct = $total > 0 ? round($t['nb'] / $total * 100) : 0;
                    $colors = ['Solfa' => '#0057B8', 'Personnel' => '#00AEEF', 'Consommation' => '#28A745'];
                    $color  = $colors[$t['type_credit']] ?? '#6B7280';
                ?>
                <div class="mb-3">
                    <div class="d-flex justify-content-between mb-1">
                        <span style="font-size:.82rem;font-weight:600;"><?= $t['type_credit'] ?></span>
                        <span style="font-size:.78rem;color:var(--text-muted);"><?= $t['nb'] ?> (<?= $pct ?>%)</span>
                    </div>
                    <div style="height:6px;background:var(--border);border-radius:10px;overflow:hidden;">
                        <div style="width:<?= $pct ?>%;height:100%;background:<?= $color ?>;border-radius:10px;transition:width .5s ease;"></div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Actions rapides -->
        <div class="card-tt mt-4">
            <div class="card-tt-header">
                <div class="card-tt-title"><i class="fa fa-bolt"></i> Actions rapides</div>
            </div>
            <div class="card-tt-body d-grid gap-2">
                <a href="<?= BASE_URL ?>/credits/create.php" class="btn btn-primary btn-sm">
                    <i class="fa fa-plus me-2"></i>Nouvelle demande de crédit
                </a>
                <a href="<?= BASE_URL ?>/credits/list.php" class="btn btn-outline-primary btn-sm">
                    <i class="fa fa-list me-2"></i>Voir toutes mes demandes
                </a>
            </div>
        </div>
    </div>
</div>

    </div><!-- page-content -->
</div><!-- main-content -->
</div><!-- d-flex -->

<?php require_once '../includes/footer.php'; ?>
