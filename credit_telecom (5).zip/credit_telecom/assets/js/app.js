// ============================================
// assets/js/app.js — Crédit TT
// ============================================

document.addEventListener('DOMContentLoaded', function () {

    // ── Sidebar Toggle ──────────────────────
    const sidebar      = document.getElementById('sidebar');
    const overlay      = document.getElementById('sidebarOverlay');
    const toggleBtn    = document.getElementById('sidebarToggle');
    const closeBtn     = document.getElementById('sidebarClose');

    function openSidebar() {
        sidebar?.classList.add('open');
        overlay?.classList.add('open');
        document.body.style.overflow = 'hidden';
    }

    function closeSidebar() {
        sidebar?.classList.remove('open');
        overlay?.classList.remove('open');
        document.body.style.overflow = '';
    }

    toggleBtn?.addEventListener('click', openSidebar);
    closeBtn?.addEventListener('click', closeSidebar);
    overlay?.addEventListener('click', closeSidebar);

    // ── Password toggle ─────────────────────
    document.querySelectorAll('.toggle-pass').forEach(btn => {
        btn.addEventListener('click', function () {
            const input = this.closest('.input-icon-wrap').querySelector('input');
            const icon  = this.querySelector('i');
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.replace('fa-eye', 'fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.replace('fa-eye-slash', 'fa-eye');
            }
        });
    });

    // ── Auto-dismiss flash messages ──────────
    setTimeout(() => {
        document.querySelectorAll('.flash-alert').forEach(el => {
            const bsAlert = new bootstrap.Alert(el);
            bsAlert.close();
        });
    }, 5000);

    // ── Confirm delete ───────────────────────
    document.querySelectorAll('[data-confirm]').forEach(el => {
        el.addEventListener('click', function (e) {
            if (!confirm(this.dataset.confirm || 'Êtes-vous sûr ?')) {
                e.preventDefault();
            }
        });
    });

    // ── Table row click ──────────────────────
    document.querySelectorAll('tr[data-href]').forEach(row => {
        row.style.cursor = 'pointer';
        row.addEventListener('click', function (e) {
            if (!e.target.closest('a, button')) {
                window.location.href = this.dataset.href;
            }
        });
    });

});

// ── PDF Generation ───────────────────────────
function generatePDF(data) {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
    const W = doc.internal.pageSize.getWidth();

    // Background header
    doc.setFillColor(0, 87, 184);
    doc.rect(0, 0, W, 40, 'F');

    // TT Logo (text-based)
    doc.setFillColor(255, 255, 255);
    doc.roundedRect(14, 8, 24, 24, 4, 4, 'F');
    doc.setTextColor(0, 87, 184);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(14);
    doc.text('TT', 26, 23, { align: 'center' });

    // Header text
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(16);
    doc.text('TUNISIE TELECOM', W / 2, 16, { align: 'center' });
    doc.setFontSize(11);
    doc.setFont('helvetica', 'normal');
    doc.text('Portail de Gestion des Crédits', W / 2, 24, { align: 'center' });
    doc.setFontSize(9);
    doc.text('www.tunisietelecom.tn', W / 2, 32, { align: 'center' });

    // Title
    doc.setTextColor(0, 87, 184);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(14);
    doc.text('DEMANDE DE CRÉDIT — ' + (data.type || '').toUpperCase(), W / 2, 54, { align: 'center' });

    // Reference bar
    doc.setFillColor(245, 247, 250);
    doc.rect(14, 58, W - 28, 10, 'F');
    doc.setTextColor(100);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.text('Référence : ' + (data.reference || ''), W / 2, 64.5, { align: 'center' });

    let y = 78;

    function section(title, icon) {
        doc.setFillColor(0, 87, 184);
        doc.rect(14, y, 4, 8, 'F');
        doc.setTextColor(0, 87, 184);
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(10);
        doc.text(title, 21, y + 5.5);
        doc.setDrawColor(0, 87, 184);
        doc.setLineWidth(0.3);
        doc.line(21, y + 8, W - 14, y + 8);
        y += 14;
    }

    function row(label, value) {
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(9);
        doc.setTextColor(100, 116, 139);
        doc.text(label, 18, y);
        doc.setFont('helvetica', 'normal');
        doc.setTextColor(31, 41, 55);
        doc.text(String(value || '—'), 70, y);
        doc.setDrawColor(229, 231, 235);
        doc.setLineWidth(0.2);
        doc.line(18, y + 2, W - 14, y + 2);
        y += 10;
    }

    // Informations du demandeur
    section('INFORMATIONS DU DEMANDEUR');
    row('Nom & Prénom :', data.nom || '');
    row('Matricule :', data.matricule || '');
    row('Email :', data.email || '');

    y += 4;
    section('DÉTAILS DU CRÉDIT');
    row('Type de crédit :', data.type || '');
    row('Montant :', (data.montant || '') + ' DT');
    row('Durée :', (data.echeance || '') + ' mois');

    y += 4;
    section('STATUT ET DATE');

    // Statut badge
    let sColor = [255, 193, 7];
    if (data.statut === 'Accepté') sColor = [40, 167, 69];
    if (data.statut === 'Refusé')  sColor = [220, 53, 69];
    doc.setFillColor(...sColor);
    doc.roundedRect(68, y - 5, 30, 8, 2, 2, 'F');
    doc.setTextColor(255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.text(data.statut || 'En attente', 83, y, { align: 'center' });

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(100, 116, 139);
    doc.text('Statut :', 18, y);
    y += 10;
    row('Date de dépôt :', data.date_depot || '');

    if (data.commentaire) {
        y += 4;
        section('COMMENTAIRE');
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(9);
        doc.setTextColor(31, 41, 55);
        const lines = doc.splitTextToSize(data.commentaire, W - 36);
        doc.text(lines, 18, y);
        y += lines.length * 6;
    }

    // Signature area
    y = Math.max(y + 10, 210);
    doc.setDrawColor(200);
    doc.setLineWidth(0.3);
    doc.line(14, y, W / 2 - 10, y);
    doc.line(W / 2 + 10, y, W - 14, y);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(150);
    doc.text('Signature du demandeur', 14, y + 5);
    doc.text('Cachet et signature DRH', W / 2 + 10, y + 5);

    // Footer
    const pageH = doc.internal.pageSize.getHeight();
    doc.setFillColor(0, 87, 184);
    doc.rect(0, pageH - 18, W, 18, 'F');
    doc.setTextColor(255);
    doc.setFontSize(7.5);
    doc.setFont('helvetica', 'normal');
    doc.text('Tunisie Telecom — Direction des Ressources Humaines', W / 2, pageH - 10, { align: 'center' });
    doc.text('Document généré le ' + new Date().toLocaleDateString('fr-TN'), W / 2, pageH - 4, { align: 'center' });

    doc.save('CreditTT_' + (data.reference || 'demande') + '.pdf');
}
