<?php
$flash = getFlashMessage();
?>
<div class="main-content" id="mainContent">
    <!-- Top Navbar -->
    <nav class="topnav">
        <button class="sidebar-toggle-btn" id="sidebarToggle">
            <i class="fa fa-bars"></i>
        </button>
        <div class="topnav-title">
            <h1 class="page-title"><?= isset($pageTitle) ? $pageTitle : 'Dashboard' ?></h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/dashboard/index.php">Accueil</a></li>
                    <?php if (isset($breadcrumb)): foreach ($breadcrumb as $b): ?>
                    <li class="breadcrumb-item <?= isset($b['active']) ? 'active' : '' ?>"><?= isset($b['url']) ? '<a href="'.$b['url'].'">'.$b['label'].'</a>' : $b['label'] ?></li>
                    <?php endforeach; endif; ?>
                </ol>
            </nav>
        </div>
        <div class="topnav-actions">
            <a href="<?= BASE_URL ?>/credits/create.php" class="btn btn-primary btn-sm">
                <i class="fa fa-plus me-1"></i> Nouvelle Demande
            </a>
        </div>
    </nav>

    <!-- Flash Messages -->
    <?php if ($flash): ?>
    <div class="flash-container">
        <div class="alert alert-<?= $flash['type'] === 'success' ? 'success' : ($flash['type'] === 'error' ? 'danger' : 'info') ?> alert-dismissible fade show flash-alert" role="alert">
            <i class="fa fa-<?= $flash['type'] === 'success' ? 'check-circle' : ($flash['type'] === 'error' ? 'exclamation-circle' : 'info-circle') ?> me-2"></i>
            <?= sanitize($flash['message']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    </div>
    <?php endif; ?>

    <div class="page-content">
