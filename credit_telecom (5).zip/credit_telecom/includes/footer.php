    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="<?= BASE_URL ?>/assets/js/app.js"></script>
    <?= isset($extraJS) ? $extraJS : '' ?>
</body>
</html>
