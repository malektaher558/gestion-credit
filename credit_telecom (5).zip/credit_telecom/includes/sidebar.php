<?php
$currentUser = getCurrentUser();
if (!$currentUser) {
    session_destroy();
    header('Location: ' . BASE_URL . '/auth/login.php');
    exit();
}
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<!-- Sidebar -->
<aside class="sidebar" id="sidebar">
    <div class="sidebar-brand">
        <div class="brand-logo">
            <img src="<?= BASE_URL ?>/assets/img/logo_tt.png" alt="Tunisie Telecom" style="width:44px;height:44px;object-fit:contain;">
        </div>
        <div class="brand-text">
            <span class="brand-name">Crédit TT</span>
            <span class="brand-sub">Tunisie Telecom</span>
        </div>
        <button class="sidebar-toggle-btn d-lg-none" id="sidebarClose">
            <i class="fa fa-times"></i>
        </button>
    </div>

    <div class="sidebar-user">
        <div class="user-avatar">
            <?= strtoupper(substr($currentUser['prenom'], 0, 1) . substr($currentUser['nom'], 0, 1)) ?>
        </div>
        <div class="user-info">
            <span class="user-name"><?= sanitize($currentUser['prenom'] . ' ' . $currentUser['nom']) ?></span>
            <span class="user-mat">Mat: <?= sanitize($currentUser['matricule']) ?></span>
        </div>
    </div>

    <nav class="sidebar-nav">
        <div class="nav-section-label">NAVIGATION</div>
        <a href="<?= BASE_URL ?>/dashboard/index.php" class="nav-item <?= ($currentPage === 'index.php' && strpos($_SERVER['PHP_SELF'], 'dashboard') !== false) ? 'active' : '' ?>">
            <i class="fa fa-chart-pie nav-icon"></i>
            <span>Tableau de bord</span>
        </a>
        <a href="<?= BASE_URL ?>/credits/list.php" class="nav-item <?= ($currentPage === 'list.php') ? 'active' : '' ?>">
            <i class="fa fa-file-alt nav-icon"></i>
            <span>Mes Demandes</span>
            <?php
            $db = getDB();
            $stmt = $db->prepare("SELECT COUNT(*) FROM credits WHERE user_id = ? AND statut = 'En attente'");
            $stmt->execute([$currentUser['id']]);
            $pending = $stmt->fetchColumn();
            if ($pending > 0): ?>
            <span class="nav-badge"><?= $pending ?></span>
            <?php endif; ?>
        </a>
        <a href="<?= BASE_URL ?>/credits/create.php" class="nav-item <?= ($currentPage === 'create.php') ? 'active' : '' ?>">
            <i class="fa fa-plus-circle nav-icon"></i>
            <span>Nouvelle Demande</span>
        </a>

        <?php if (isAdmin()): ?>
        <div class="nav-section-label mt-3">ADMINISTRATION</div>
        <a href="<?= BASE_URL ?>/admin/users.php" class="nav-item <?= ($currentPage === 'users.php') ? 'active' : '' ?>">
            <i class="fa fa-users nav-icon"></i>
            <span>Utilisateurs</span>
        </a>
        <a href="<?= BASE_URL ?>/admin/all_credits.php" class="nav-item <?= ($currentPage === 'all_credits.php') ? 'active' : '' ?>">
            <i class="fa fa-database nav-icon"></i>
            <span>Tous les crédits</span>
        </a>
        <?php endif; ?>
    </nav>

    <div class="sidebar-footer">
        <a href="<?= BASE_URL ?>/auth/logout.php" class="nav-item logout-item">
            <i class="fa fa-sign-out-alt nav-icon"></i>
            <span>Déconnexion</span>
        </a>
    </div>
</aside>

<!-- Overlay mobile -->
<div class="sidebar-overlay" id="sidebarOverlay"></div>
