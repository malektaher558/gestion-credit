<?php
// Utilitaire reset mot de passe admin — SUPPRIMER après utilisation !
$password = 'Admin@2025';
$hash = password_hash($password, PASSWORD_DEFAULT);
echo "Hash : " . $hash . "<br><br>";

try {
    $pdo = new PDO('mysql:host=localhost;dbname=gestion_credit;charset=utf8mb4', 'root', '');
    $pdo->prepare("UPDATE admins SET password = ? WHERE email = ?")->execute([$hash, 'superadmin@tunisietelecom.tn']);
    $pdo->prepare("UPDATE admins SET password = ? WHERE email = ?")->execute([$hash, 'admin.drh@tunisietelecom.tn']);
    echo "✅ Mots de passe mis à jour !<br>";
    echo "Email : superadmin@tunisietelecom.tn — MDP : Admin@2025<br>";
    echo "Email : admin.drh@tunisietelecom.tn — MDP : Admin@2025";
} catch (PDOException $e) {
    echo "❌ Erreur : " . $e->getMessage();
}
?>
