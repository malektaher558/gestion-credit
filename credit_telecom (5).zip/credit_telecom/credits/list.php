<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/auth_helper.php';

requireLogin();

$pageTitle  = 'Mes Demandes de Crédit';
$breadcrumb = [['label' => 'Mes Demandes', 'active' => true]];

$user = getCurrentUser();
$db   = getDB();

// Filters
$filterType   = $_GET['type'] ?? '';
$filterStatut = $_GET['statut'] ?? '';
$search       = sanitize($_GET['q'] ?? '');
$page         = max(1, intval($_GET['page'] ?? 1));
$perPage      = ITEMS_PER_PAGE;

// Build query
$where  = "WHERE user_id = ?";
$params = [$user['id']];

if ($filterType) {
    $where .= " AND type_credit = ?";
    $params[] = $filterType;
}
if ($filterStatut) {
    $where .= " AND statut = ?";
    $params[] = $filterStatut;
}
if ($search) {
    $where .= " AND reference LIKE ?";
    $params[] = "%$search%";
}

$countStmt = $db->prepare("SELECT COUNT(*) FROM credits $where");
$countStmt->execute($params);
$total = $countStmt->fetchColumn();
$pages = max(1, ceil($total / $perPage));
$offset = ($page - 1) * $perPage;

$stmt = $db->prepare("SELECT * FROM credits $where ORDER BY created_at DESC LIMIT $perPage OFFSET $offset");
$stmt->execute($params);
$credits = $stmt->fetchAll();

require_once '../includes/header.php';
?>
<div class="d-flex">
<?php require_once '../includes/sidebar.php'; ?>
<?php require_once '../includes/navbar.php'; ?>

<div class="card-tt">
    <!-- Filter Bar -->
    <div class="filter-bar">
        <form method="GET" class="d-flex gap-2 flex-wrap align-items-center w-100">
            <div class="input-icon-wrap flex-grow-1" style="max-width:260px;">
                <i class="fa fa-search field-icon"></i>
                <input type="text" name="q" class="form-control" placeholder="Rechercher par référence..."
                       value="<?= sanitize($search) ?>" style="padding-left:36px;">
            </div>
            <select name="type" class="form-select">
                <option value="">Tous les types</option>
                <?php foreach (CREDIT_TYPES as $t): ?>
                <option value="<?= $t ?>" <?= $filterType === $t ? 'selected' : '' ?>><?= $t ?></option>
                <?php endforeach; ?>
            </select>
            <select name="statut" class="form-select">
                <option value="">Tous les statuts</option>
                <?php foreach (CREDIT_STATUTS as $s): ?>
                <option value="<?= $s ?>" <?= $filterStatut === $s ? 'selected' : '' ?>><?= $s ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="btn btn-primary btn-sm">
                <i class="fa fa-filter me-1"></i> Filtrer
            </button>
            <?php if ($filterType || $filterStatut || $search): ?>
            <a href="list.php" class="btn btn-outline-secondary btn-sm">
                <i class="fa fa-times me-1"></i> Réinitialiser
            </a>
            <?php endif; ?>
        </form>
    </div>

    <!-- Table -->
    <?php if (empty($credits)): ?>
    <div class="empty-state">
        <i class="fa fa-folder-open"></i>
        <h5>Aucune demande trouvée</h5>
        <p><?= ($filterType || $filterStatut || $search) ? 'Aucun résultat pour vos critères de recherche.' : 'Vous n\'avez pas encore soumis de demande de crédit.' ?></p>
        <a href="<?= BASE_URL ?>/credits/create.php" class="btn btn-primary btn-sm">
            <i class="fa fa-plus me-1"></i> Nouvelle demande
        </a>
    </div>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table-tt">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Référence</th>
                    <th>Type</th>
                    <th>Montant</th>
                    <th>Échéance</th>
                    <th>Date dépôt</th>
                    <th>Statut</th>
                    <th class="text-center">Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($credits as $i => $c):
                $badgeClass = match($c['statut']) {
                    'Accepté' => 'accepte',
                    'Refusé'  => 'refuse',
                    default   => 'attente'
                };
                $badgeIcon = match($c['statut']) {
                    'Accepté' => 'fa-check-circle',
                    'Refusé'  => 'fa-times-circle',
                    default   => 'fa-clock'
                };
            ?>
            <tr data-href="<?= BASE_URL ?>/credits/view.php?id=<?= $c['id'] ?>">
                <td style="color:var(--text-light);font-size:.8rem;"><?= $offset + $i + 1 ?></td>
                <td><span class="ref-cell"><?= sanitize($c['reference']) ?></span></td>
                <td><span class="badge-type"><?= sanitize($c['type_credit']) ?></span></td>
                <td class="fw-700"><?= number_format($c['montant'], 0, ',', ' ') ?> <span style="font-size:.75rem;color:var(--text-muted);">DT</span></td>
                <td><?= $c['echeance'] ?> mois</td>
                <td><?= date('d/m/Y', strtotime($c['date_depot'])) ?></td>
                <td>
                    <span class="badge-statut <?= $badgeClass ?>">
                        <i class="fa <?= $badgeIcon ?>"></i>
                        <?= $c['statut'] ?>
                    </span>
                </td>
                <td>
                    <div class="d-flex justify-content-center gap-1">
                        <a href="<?= BASE_URL ?>/credits/view.php?id=<?= $c['id'] ?>" class="btn-action view" title="Consulter">
                            <i class="fa fa-eye"></i>
                        </a>
                        <?php if ($c['statut'] === 'En attente'): ?>
                        <a href="<?= BASE_URL ?>/credits/edit.php?id=<?= $c['id'] ?>" class="btn-action edit" title="Modifier">
                            <i class="fa fa-edit"></i>
                        </a>
                        <a href="<?= BASE_URL ?>/credits/delete.php?id=<?= $c['id'] ?>"
                           class="btn-action delete"
                           title="Supprimer"
                           data-confirm="Supprimer définitivement cette demande ?">
                            <i class="fa fa-trash"></i>
                        </a>
                        <?php endif; ?>
                        <button class="btn-action pdf" title="Télécharger PDF"
                                onclick='generatePDF(<?= json_encode([
                                    "reference" => $c['reference'],
                                    "nom"       => $user['nom'] . ' ' . $user['prenom'],
                                    "matricule" => $user['matricule'],
                                    "email"     => $user['email'],
                                    "type"      => $c['type_credit'],
                                    "montant"   => number_format($c['montant'], 2, '.', ''),
                                    "echeance"  => $c['echeance'],
                                    "statut"    => $c['statut'],
                                    "commentaire" => $c['commentaire'],
                                    "date_depot"  => date('d/m/Y', strtotime($c['date_depot'])),
                                ]) ?>)'>
                            <i class="fa fa-file-pdf"></i>
                        </button>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination & Info -->
    <div class="d-flex align-items-center justify-content-between px-4 py-3" style="border-top:1px solid var(--border);">
        <div style="font-size:.8rem;color:var(--text-muted);">
            Affichage de <?= $offset + 1 ?> à <?= min($offset + $perPage, $total) ?> sur <?= $total ?> éléments
        </div>
        <?php if ($pages > 1): ?>
        <nav>
            <ul class="pagination mb-0 pagination-sm">
                <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                    <a class="page-link" href="?page=<?= $page-1 ?>&type=<?= $filterType ?>&statut=<?= $filterStatut ?>&q=<?= urlencode($search) ?>">
                        <i class="fa fa-chevron-left"></i>
                    </a>
                </li>
                <?php for ($p = 1; $p <= $pages; $p++): ?>
                <li class="page-item <?= $p === $page ? 'active' : '' ?>">
                    <a class="page-link" href="?page=<?= $p ?>&type=<?= $filterType ?>&statut=<?= $filterStatut ?>&q=<?= urlencode($search) ?>"><?= $p ?></a>
                </li>
                <?php endfor; ?>
                <li class="page-item <?= $page >= $pages ? 'disabled' : '' ?>">
                    <a class="page-link" href="?page=<?= $page+1 ?>&type=<?= $filterType ?>&statut=<?= $filterStatut ?>&q=<?= urlencode($search) ?>">
                        <i class="fa fa-chevron-right"></i>
                    </a>
                </li>
            </ul>
        </nav>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>

    </div><!-- page-content -->
</div><!-- main-content -->
</div><!-- d-flex -->

<?php require_once '../includes/footer.php'; ?>
