<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/auth_helper.php';

requireLogin();

$user = getCurrentUser();
$db   = getDB();
$id   = intval($_GET['id'] ?? 0);

$stmt = $db->prepare("SELECT c.*, u.nom, u.prenom, u.matricule, u.email FROM credits c JOIN users u ON c.user_id = u.id WHERE c.id = ?");
$stmt->execute([$id]);
$credit = $stmt->fetch();

if (!$credit || ($credit['user_id'] != $user['id'] && !isAdmin())) {
    flashMessage('error', 'Demande introuvable ou accès non autorisé.');
    redirect(BASE_URL . '/credits/list.php');
}

$pageTitle  = 'Détail de la demande';
$breadcrumb = [
    ['label' => 'Mes Demandes', 'url' => BASE_URL . '/credits/list.php'],
    ['label' => $credit['reference'], 'active' => true]
];

$badgeClass = match($credit['statut']) {
    'Accepté' => 'accepte',
    'Refusé'  => 'refuse',
    default   => 'attente'
};
$badgeIcon = match($credit['statut']) {
    'Accepté' => 'fa-check-circle',
    'Refusé'  => 'fa-times-circle',
    default   => 'fa-clock'
};

$pdfData = json_encode([
    'reference'  => $credit['reference'],
    'nom'        => $credit['prenom'] . ' ' . $credit['nom'],
    'matricule'  => $credit['matricule'],
    'email'      => $credit['email'],
    'type'       => $credit['type_credit'],
    'montant'    => number_format($credit['montant'], 2, '.', ''),
    'echeance'   => $credit['echeance'],
    'statut'     => $credit['statut'],
    'commentaire'=> $credit['commentaire'],
    'date_depot' => date('d/m/Y', strtotime($credit['date_depot'])),
]);

require_once '../includes/header.php';
?>
<div class="d-flex">
<?php require_once '../includes/sidebar.php'; ?>
<?php require_once '../includes/navbar.php'; ?>

<div class="row g-4">
    <!-- Main Detail -->
    <div class="col-lg-8">
        <div class="card-tt">
            <div class="card-tt-header">
                <div class="card-tt-title">
                    <i class="fa fa-file-alt"></i>
                    Détail de la demande
                </div>
                <div class="d-flex gap-2">
                    <?php if ($credit['statut'] === 'En attente'): ?>
                    <a href="edit.php?id=<?= $id ?>" class="btn btn-outline-primary btn-sm">
                        <i class="fa fa-edit me-1"></i> Modifier
                    </a>
                    <?php endif; ?>
                    <button class="btn btn-success btn-sm" onclick='generatePDF(<?= $pdfData ?>)'>
                        <i class="fa fa-file-pdf me-1"></i> Télécharger PDF
                    </button>
                </div>
            </div>
            <div class="card-tt-body">
                <!-- Reference header -->
                <div class="mb-4 p-3" style="background:var(--accent);border-radius:10px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;">
                    <div>
                        <div style="font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:var(--text-muted);">Référence</div>
                        <div class="detail-ref"><?= sanitize($credit['reference']) ?></div>
                    </div>
                    <span class="badge-statut <?= $badgeClass ?>">
                        <i class="fa <?= $badgeIcon ?>"></i>
                        <?= $credit['statut'] ?>
                    </span>
                </div>

                <!-- Informations du demandeur -->
                <div class="detail-section">
                    <div class="detail-section-title">
                        <i class="fa fa-user"></i> Informations du demandeur
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Nom & Prénom</span>
                        <span class="detail-value fw-700"><?= sanitize($credit['prenom'] . ' ' . $credit['nom']) ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Matricule</span>
                        <span class="detail-value"><?= sanitize($credit['matricule']) ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Email</span>
                        <span class="detail-value"><?= sanitize($credit['email']) ?></span>
                    </div>
                </div>

                <!-- Détails du crédit -->
                <div class="detail-section">
                    <div class="detail-section-title">
                        <i class="fa fa-coins"></i> Détails du crédit
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Type de crédit</span>
                        <span class="detail-value"><span class="badge-type"><?= sanitize($credit['type_credit']) ?></span></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Montant</span>
                        <span class="detail-value">
                            <span class="fw-700" style="font-size:1.1rem;color:var(--primary);">
                                <?= number_format($credit['montant'], 2, ',', ' ') ?> DT
                            </span>
                        </span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Durée</span>
                        <span class="detail-value fw-700"><?= $credit['echeance'] ?> mois</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Mensualité estimée</span>
                        <span class="detail-value fw-700" style="color:var(--secondary);" id="mensualiteDetail">—</span>
                    </div>
                </div>

                <!-- Statut et date -->
                <div class="detail-section">
                    <div class="detail-section-title">
                        <i class="fa fa-calendar-check"></i> Statut et Date
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Statut</span>
                        <span class="detail-value">
                            <span class="badge-statut <?= $badgeClass ?>">
                                <i class="fa <?= $badgeIcon ?>"></i>
                                <?= $credit['statut'] ?>
                            </span>
                        </span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Date de dépôt</span>
                        <span class="detail-value"><?= date('d/m/Y', strtotime($credit['date_depot'])) ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Créé le</span>
                        <span class="detail-value"><?= date('d/m/Y à H:i', strtotime($credit['created_at'])) ?></span>
                    </div>
                    <?php if ($credit['updated_at'] !== $credit['created_at']): ?>
                    <div class="detail-row">
                        <span class="detail-label">Modifié le</span>
                        <span class="detail-value"><?= date('d/m/Y à H:i', strtotime($credit['updated_at'])) ?></span>
                    </div>
                    <?php endif; ?>
                </div>

                <?php if ($credit['commentaire']): ?>
                <!-- Commentaire -->
                <div class="detail-section">
                    <div class="detail-section-title">
                        <i class="fa fa-comment-alt"></i> Commentaire
                    </div>
                    <div class="p-3" style="background:var(--accent);border-radius:8px;font-size:.875rem;color:var(--text);">
                        <?= nl2br(sanitize($credit['commentaire'])) ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Right column -->
    <div class="col-lg-4">
        <!-- Actions card -->
        <div class="card-tt mb-4">
            <div class="card-tt-header">
                <div class="card-tt-title"><i class="fa fa-cog"></i> Actions</div>
            </div>
            <div class="card-tt-body d-grid gap-2">
                <button class="btn btn-success" onclick='generatePDF(<?= $pdfData ?>)'>
                    <i class="fa fa-file-pdf me-2"></i>Télécharger le PDF
                </button>
                <?php if ($credit['statut'] === 'En attente'): ?>
                <a href="edit.php?id=<?= $id ?>" class="btn btn-outline-primary">
                    <i class="fa fa-edit me-2"></i>Modifier la demande
                </a>
                <a href="delete.php?id=<?= $id ?>"
                   class="btn btn-outline-danger"
                   data-confirm="Supprimer définitivement cette demande ?">
                    <i class="fa fa-trash me-2"></i>Supprimer
                </a>
                <?php endif; ?>
                <a href="list.php" class="btn btn-outline-secondary">
                    <i class="fa fa-arrow-left me-2"></i>Retour à la liste
                </a>
            </div>
        </div>

        <!-- Status timeline -->
        <div class="card-tt">
            <div class="card-tt-header">
                <div class="card-tt-title"><i class="fa fa-route"></i> Historique du statut</div>
            </div>
            <div class="card-tt-body">
                <div class="timeline">
                    <div class="timeline-item">
                        <div class="timeline-dot primary"></div>
                        <div style="font-size:.82rem;">
                            <strong>Demande soumise</strong>
                            <div style="color:var(--text-muted);"><?= date('d/m/Y', strtotime($credit['date_depot'])) ?></div>
                        </div>
                    </div>
                    <div class="timeline-item">
                        <div class="timeline-dot <?= $credit['statut'] === 'En attente' ? 'warning' : ($credit['statut'] === 'Accepté' ? 'success' : 'danger') ?>"></div>
                        <div style="font-size:.82rem;">
                            <strong><?= $credit['statut'] ?></strong>
                            <div style="color:var(--text-muted);">
                                <?php if ($credit['statut'] === 'En attente'): ?>
                                En cours de traitement par la DRH
                                <?php elseif ($credit['statut'] === 'Accepté'): ?>
                                Demande approuvée par la DRH
                                <?php else: ?>
                                Demande refusée par la DRH
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

    </div>
</div>
</div>

<script>
// Calculate mensualite
(function() {
    const m = <?= floatval($credit['montant']) ?>;
    const e = <?= intval($credit['echeance']) ?>;
    if (m && e) {
        const taux = 0.07 / 12;
        const mensual = m * taux / (1 - Math.pow(1 + taux, -e));
        document.getElementById('mensualiteDetail').textContent = mensual.toFixed(2) + ' DT/mois';
    }
})();
</script>

<?php require_once '../includes/footer.php'; ?>
