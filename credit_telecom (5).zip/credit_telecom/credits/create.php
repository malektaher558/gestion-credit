<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/auth_helper.php';

requireLogin();

$pageTitle  = 'Nouvelle Demande de Crédit';
$breadcrumb = [
    ['label' => 'Mes Demandes', 'url' => BASE_URL . '/credits/list.php'],
    ['label' => 'Nouvelle Demande', 'active' => true]
];

$user   = getCurrentUser();
$db     = getDB();
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $typeCredit  = sanitize($_POST['type_credit'] ?? '');
    $montant     = floatval($_POST['montant'] ?? 0);
    $echeance    = intval($_POST['echeance'] ?? 0);
    $commentaire = sanitize($_POST['commentaire'] ?? '');

    if (!in_array($typeCredit, CREDIT_TYPES))
        $errors[] = 'Type de crédit invalide.';
    if ($montant <= 0)
        $errors[] = 'Veuillez sélectionner un montant.';
    if ($echeance <= 0)
        $errors[] = 'Veuillez sélectionner une durée.';

    if (empty($errors)) {
        $reference = generateReference($user['id']);
        $dateDepot = date('Y-m-d');

        $stmt = $db->prepare("INSERT INTO credits (reference, user_id, type_credit, montant, echeance, commentaire, statut, date_depot)
                              VALUES (?, ?, ?, ?, ?, ?, 'En attente', ?)");
        $stmt->execute([$reference, $user['id'], $typeCredit, $montant, $echeance, $commentaire ?: null, $dateDepot]);

        flashMessage('success', "Demande $reference soumise avec succès !");
        redirect(BASE_URL . '/credits/list.php');
    }
}

// Mensualité estimée (simulateur simple)
$mensualite = 0;

require_once '../includes/header.php';
?>
<div class="d-flex">
<?php require_once '../includes/sidebar.php'; ?>
<?php require_once '../includes/navbar.php'; ?>

<div class="row g-4">
    <div class="col-lg-7">
        <div class="card-tt">
            <div class="card-tt-header">
                <div class="card-tt-title">
                    <i class="fa fa-file-signature"></i>
                    Formulaire de demande de crédit
                </div>
            </div>
            <div class="card-tt-body">
                <?php if (!empty($errors)): ?>
                <div class="alert alert-danger py-2 mb-4" style="border-radius:8px;font-size:.875rem;">
                    <ul class="mb-0 ps-3">
                        <?php foreach ($errors as $e): ?><li><?= $e ?></li><?php endforeach; ?>
                    </ul>
                </div>
                <?php endif; ?>

                <form method="POST" novalidate>
                    <!-- Section 1 -->
                    <div class="detail-section-title">
                        <i class="fa fa-info-circle"></i> Informations de base
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-12">
                            <label class="form-label"><i class="fa fa-credit-card"></i> Type de Crédit <span class="text-danger">*</span></label>
                            <select name="type_credit" class="form-select <?= isset($errors) && !empty($errors) && !in_array(sanitize($_POST['type_credit'] ?? ''), CREDIT_TYPES) ? 'is-invalid' : '' ?>" required id="typeCredit">
                                <option value="">— Sélectionner un type —</option>
                                <?php foreach (CREDIT_TYPES as $t): ?>
                                <option value="<?= $t ?>" <?= (isset($_POST['type_credit']) && $_POST['type_credit'] === $t) ? 'selected' : '' ?>>
                                    <?= $t ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-6">
                            <label class="form-label"><i class="fa fa-user"></i> Nom & Prénom</label>
                            <input type="text" class="form-control bg-light" value="<?= sanitize($user['prenom'] . ' ' . $user['nom']) ?>" readonly>
                        </div>
                        <div class="col-6">
                            <label class="form-label"><i class="fa fa-id-badge"></i> Matricule</label>
                            <input type="text" class="form-control bg-light" value="<?= sanitize($user['matricule']) ?>" readonly>
                        </div>
                    </div>

                    <!-- Section 2 -->
                    <div class="detail-section-title mt-4">
                        <i class="fa fa-coins"></i> Détails du crédit
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-6">
                            <label class="form-label"><i class="fa fa-money-bill"></i> Montant (DT) <span class="text-danger">*</span></label>
                            <select name="montant" class="form-select" required id="montantSelect">
                                <option value="">— Sélectionner —</option>
                                <?php foreach (CREDIT_AMOUNTS as $m): ?>
                                <option value="<?= $m ?>" <?= (isset($_POST['montant']) && floatval($_POST['montant']) == $m) ? 'selected' : '' ?>>
                                    <?= number_format($m, 0, ',', ' ') ?> DT
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-6">
                            <label class="form-label"><i class="fa fa-calendar-alt"></i> Échéance (mois) <span class="text-danger">*</span></label>
                            <select name="echeance" class="form-select" required id="echeanceSelect">
                                <option value="">— Sélectionner —</option>
                                <?php foreach (CREDIT_ECHEANCES as $e): ?>
                                <option value="<?= $e ?>" <?= (isset($_POST['echeance']) && intval($_POST['echeance']) == $e) ? 'selected' : '' ?>>
                                    <?= $e ?> mois
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label"><i class="fa fa-comment"></i> Commentaire (optionnel)</label>
                        <textarea name="commentaire" class="form-control" rows="3"
                                  placeholder="Motif ou informations complémentaires..."><?= sanitize($_POST['commentaire'] ?? '') ?></textarea>
                    </div>

                    <div class="d-flex gap-2 mt-4">
                        <a href="<?= BASE_URL ?>/credits/list.php" class="btn btn-outline-secondary">
                            <i class="fa fa-times me-1"></i> Annuler
                        </a>
                        <button type="submit" class="btn btn-primary">
                            <i class="fa fa-paper-plane me-1"></i> Confirmer la demande
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Simulator card -->
    <div class="col-lg-5">
        <div class="card-tt mb-4">
            <div class="card-tt-header">
                <div class="card-tt-title"><i class="fa fa-calculator"></i> Simulateur de mensualité</div>
            </div>
            <div class="card-tt-body text-center">
                <div style="color:var(--text-muted);font-size:.82rem;margin-bottom:12px;">Mensualité estimée</div>
                <div class="montant-big" id="mensualiteDisplay">—</div>
                <div style="font-size:.8rem;color:var(--text-muted);margin-top:4px;">DT / mois</div>
                <div id="simulDetails" class="mt-3 pt-3" style="border-top:1px solid var(--border);display:none;">
                    <div class="d-flex justify-content-between mb-2" style="font-size:.82rem;">
                        <span style="color:var(--text-muted);">Montant total :</span>
                        <span class="fw-700" id="simMontant">—</span>
                    </div>
                    <div class="d-flex justify-content-between mb-2" style="font-size:.82rem;">
                        <span style="color:var(--text-muted);">Durée :</span>
                        <span class="fw-700" id="simEcheance">—</span>
                    </div>
                    <div class="d-flex justify-content-between" style="font-size:.82rem;">
                        <span style="color:var(--text-muted);">Taux indicatif :</span>
                        <span class="fw-700">7% annuel</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Info card -->
        <div class="card-tt">
            <div class="card-tt-header">
                <div class="card-tt-title"><i class="fa fa-info-circle"></i> Informations</div>
            </div>
            <div class="card-tt-body">
                <div class="timeline">
                    <div class="timeline-item">
                        <div class="timeline-dot primary"></div>
                        <div style="font-size:.82rem;">
                            <strong>Crédit Solfa</strong>
                            <div style="color:var(--text-muted);">Pour les besoins courants. Montant jusqu'à 2 000 DT.</div>
                        </div>
                    </div>
                    <div class="timeline-item">
                        <div class="timeline-dot" style="background:var(--secondary);box-shadow:0 0 0 2px var(--secondary);"></div>
                        <div style="font-size:.82rem;">
                            <strong>Crédit Personnel</strong>
                            <div style="color:var(--text-muted);">Pour projets personnels. Jusqu'à 5 000 DT.</div>
                        </div>
                    </div>
                    <div class="timeline-item">
                        <div class="timeline-dot success"></div>
                        <div style="font-size:.82rem;">
                            <strong>Crédit Consommation</strong>
                            <div style="color:var(--text-muted);">Pour équipements ménagers. Jusqu'à 10 000 DT.</div>
                        </div>
                    </div>
                </div>
                <div class="mt-3 p-3" style="background:var(--accent);border-radius:8px;font-size:.78rem;color:var(--text-muted);">
                    <i class="fa fa-shield-alt text-primary-tt me-1"></i>
                    Votre demande sera traitée par la DRH sous 48-72h ouvrables.
                </div>
            </div>
        </div>
    </div>
</div>

    </div>
</div>
</div>

<script>
(function() {
    const montantSel  = document.getElementById('montantSelect');
    const echeanceSel = document.getElementById('echeanceSelect');
    const display     = document.getElementById('mensualiteDisplay');
    const details     = document.getElementById('simulDetails');
    const simM        = document.getElementById('simMontant');
    const simE        = document.getElementById('simEcheance');

    function update() {
        const m = parseFloat(montantSel.value);
        const e = parseInt(echeanceSel.value);
        if (m && e) {
            const taux     = 0.07 / 12;
            const mensual  = taux === 0 ? m/e : m * taux / (1 - Math.pow(1+taux, -e));
            display.textContent = mensual.toFixed(2);
            simM.textContent    = m.toLocaleString('fr-TN') + ' DT';
            simE.textContent    = e + ' mois';
            details.style.display = 'block';
        } else {
            display.textContent = '—';
            details.style.display = 'none';
        }
    }

    montantSel?.addEventListener('change', update);
    echeanceSel?.addEventListener('change', update);
    update();
})();
</script>

<?php require_once '../includes/footer.php'; ?>
