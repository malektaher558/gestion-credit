<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/auth_helper.php';

requireLogin();

$user = getCurrentUser();
$db   = getDB();
$id   = intval($_GET['id'] ?? 0);

$stmt = $db->prepare("SELECT * FROM credits WHERE id = ? AND user_id = ?");
$stmt->execute([$id, $user['id']]);
$credit = $stmt->fetch();

if (!$credit) {
    flashMessage('error', 'Demande introuvable.');
    redirect(BASE_URL . '/credits/list.php');
}

if ($credit['statut'] !== 'En attente') {
    flashMessage('error', 'Impossible de modifier une demande déjà traitée.');
    redirect(BASE_URL . '/credits/view.php?id=' . $id);
}

$pageTitle  = 'Modifier la demande';
$breadcrumb = [
    ['label' => 'Mes Demandes', 'url' => BASE_URL . '/credits/list.php'],
    ['label' => $credit['reference'], 'url' => BASE_URL . '/credits/view.php?id=' . $id],
    ['label' => 'Modifier', 'active' => true]
];

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $typeCredit  = sanitize($_POST['type_credit'] ?? '');
    $montant     = floatval($_POST['montant'] ?? 0);
    $echeance    = intval($_POST['echeance'] ?? 0);
    $commentaire = sanitize($_POST['commentaire'] ?? '');

    if (!in_array($typeCredit, CREDIT_TYPES))
        $errors[] = 'Type de crédit invalide.';
    if ($montant <= 0)
        $errors[] = 'Veuillez sélectionner un montant.';
    if ($echeance <= 0)
        $errors[] = 'Veuillez sélectionner une durée.';

    if (empty($errors)) {
        $stmt = $db->prepare("UPDATE credits SET type_credit=?, montant=?, echeance=?, commentaire=? WHERE id=? AND user_id=?");
        $stmt->execute([$typeCredit, $montant, $echeance, $commentaire ?: null, $id, $user['id']]);
        flashMessage('success', 'Demande modifiée avec succès !');
        redirect(BASE_URL . '/credits/view.php?id=' . $id);
    } else {
        // Update $credit with POST values for re-display
        $credit['type_credit'] = $typeCredit;
        $credit['montant']     = $montant;
        $credit['echeance']    = $echeance;
        $credit['commentaire'] = $commentaire;
    }
}

require_once '../includes/header.php';
?>
<div class="d-flex">
<?php require_once '../includes/sidebar.php'; ?>
<?php require_once '../includes/navbar.php'; ?>

<div class="row g-4 justify-content-center">
    <div class="col-lg-7">
        <div class="card-tt">
            <div class="card-tt-header">
                <div class="card-tt-title">
                    <i class="fa fa-edit"></i> Modifier la demande
                </div>
                <span class="ref-cell"><?= sanitize($credit['reference']) ?></span>
            </div>
            <div class="card-tt-body">
                <?php if (!empty($errors)): ?>
                <div class="alert alert-danger py-2 mb-4" style="border-radius:8px;font-size:.875rem;">
                    <ul class="mb-0 ps-3">
                        <?php foreach ($errors as $e): ?><li><?= $e ?></li><?php endforeach; ?>
                    </ul>
                </div>
                <?php endif; ?>

                <form method="POST" novalidate>
                    <div class="detail-section-title">
                        <i class="fa fa-info-circle"></i> Informations de base
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-12">
                            <label class="form-label"><i class="fa fa-credit-card"></i> Type de Crédit <span class="text-danger">*</span></label>
                            <select name="type_credit" class="form-select" required>
                                <option value="">— Sélectionner —</option>
                                <?php foreach (CREDIT_TYPES as $t): ?>
                                <option value="<?= $t ?>" <?= $credit['type_credit'] === $t ? 'selected' : '' ?>><?= $t ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-6">
                            <label class="form-label"><i class="fa fa-user"></i> Nom & Prénom</label>
                            <input type="text" class="form-control bg-light" value="<?= sanitize($user['prenom'] . ' ' . $user['nom']) ?>" readonly>
                        </div>
                        <div class="col-6">
                            <label class="form-label"><i class="fa fa-id-badge"></i> Matricule</label>
                            <input type="text" class="form-control bg-light" value="<?= sanitize($user['matricule']) ?>" readonly>
                        </div>
                    </div>

                    <div class="detail-section-title mt-4">
                        <i class="fa fa-coins"></i> Détails du crédit
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-6">
                            <label class="form-label"><i class="fa fa-money-bill"></i> Montant (DT) <span class="text-danger">*</span></label>
                            <select name="montant" class="form-select" required>
                                <option value="">— Sélectionner —</option>
                                <?php foreach (CREDIT_AMOUNTS as $m): ?>
                                <option value="<?= $m ?>" <?= floatval($credit['montant']) == $m ? 'selected' : '' ?>>
                                    <?= number_format($m, 0, ',', ' ') ?> DT
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-6">
                            <label class="form-label"><i class="fa fa-calendar-alt"></i> Échéance (mois) <span class="text-danger">*</span></label>
                            <select name="echeance" class="form-select" required>
                                <option value="">— Sélectionner —</option>
                                <?php foreach (CREDIT_ECHEANCES as $e): ?>
                                <option value="<?= $e ?>" <?= intval($credit['echeance']) == $e ? 'selected' : '' ?>>
                                    <?= $e ?> mois
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label"><i class="fa fa-comment"></i> Commentaire (optionnel)</label>
                        <textarea name="commentaire" class="form-control" rows="3"
                                  placeholder="Motif ou informations complémentaires..."><?= sanitize($credit['commentaire'] ?? '') ?></textarea>
                    </div>

                    <div class="d-flex gap-2 mt-4">
                        <a href="view.php?id=<?= $id ?>" class="btn btn-outline-secondary">
                            <i class="fa fa-times me-1"></i> Annuler
                        </a>
                        <button type="submit" class="btn btn-primary">
                            <i class="fa fa-save me-1"></i> Enregistrer les modifications
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

    </div>
</div>
</div>

<?php require_once '../includes/footer.php'; ?>
