<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/auth_helper.php';

requireLogin();

$user = getCurrentUser();
$db   = getDB();
$id   = intval($_GET['id'] ?? 0);

$stmt = $db->prepare("SELECT * FROM credits WHERE id = ? AND user_id = ?");
$stmt->execute([$id, $user['id']]);
$credit = $stmt->fetch();

if (!$credit) {
    flashMessage('error', 'Demande introuvable.');
    redirect(BASE_URL . '/credits/list.php');
}

if ($credit['statut'] !== 'En attente') {
    flashMessage('error', 'Impossible de supprimer une demande déjà traitée.');
    redirect(BASE_URL . '/credits/view.php?id=' . $id);
}

$stmt = $db->prepare("DELETE FROM credits WHERE id = ? AND user_id = ?");
$stmt->execute([$id, $user['id']]);

flashMessage('success', 'La demande ' . $credit['reference'] . ' a été supprimée.');
redirect(BASE_URL . '/credits/list.php');
?>
