-- ============================================
-- CRÉDIT TT - Script SQL Complet
-- Tunisie Telecom - Portail de Gestion Crédits
-- ============================================

CREATE DATABASE IF NOT EXISTS gestion_credit CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE gestion_credit;

-- Table des utilisateurs
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    matricule VARCHAR(10) NOT NULL UNIQUE,
    nom VARCHAR(100) NOT NULL,
    prenom VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('user', 'admin') DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table des crédits
CREATE TABLE IF NOT EXISTS credits (
    id INT AUTO_INCREMENT PRIMARY KEY,
    reference VARCHAR(30) NOT NULL UNIQUE,
    user_id INT NOT NULL,
    type_credit ENUM('Solfa', 'Personnel', 'Consommation') NOT NULL,
    montant DECIMAL(10,2) NOT NULL,
    echeance INT NOT NULL COMMENT 'Durée en mois',
    statut ENUM('En attente', 'Accepté', 'Refusé') DEFAULT 'En attente',
    commentaire TEXT,
    admin_comment TEXT DEFAULT NULL,
    processed_by INT DEFAULT NULL,
    processed_at TIMESTAMP NULL,
    date_depot DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table admins
CREATE TABLE IF NOT EXISTS admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    prenom VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('superadmin','admin') DEFAULT 'admin',
    avatar VARCHAR(255) DEFAULT NULL,
    last_login TIMESTAMP NULL,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Clé étrangère credits.processed_by -> admins
ALTER TABLE credits
    ADD CONSTRAINT fk_processed_by FOREIGN KEY (processed_by) REFERENCES admins(id) ON DELETE SET NULL;

-- Table notifications
CREATE TABLE IF NOT EXISTS notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    admin_id INT NOT NULL,
    type ENUM('new_request','accepted','refused','user_registered','system') NOT NULL,
    title VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    credit_id INT DEFAULT NULL,
    user_id INT DEFAULT NULL,
    is_read TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (admin_id) REFERENCES admins(id) ON DELETE CASCADE,
    FOREIGN KEY (credit_id) REFERENCES credits(id) ON DELETE SET NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- Données de test
-- ============================================

-- Utilisateurs (mot de passe: password)
INSERT INTO users (matricule, nom, prenom, email, password, role) VALUES
('00001', 'Admin', 'Système', 'admin@tunisietelecom.tn', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'user'),
('11111', 'Lassoued', 'Nour', 'nour.lassoued@tunisietelecom.tn', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'user'),
('22222', 'Ben Ali', 'Mohamed', 'mohamed.benali@tunisietelecom.tn', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'user');
-- Mot de passe pour tous les users: password

-- Admins (mot de passe: Admin@2025)
INSERT INTO admins (nom, prenom, email, password, role) VALUES
('Système', 'Super Admin', 'superadmin@tunisietelecom.tn', '$2b$10$dRg66Dt2GpFFrdGeMhK0Besw5XSaV.VfZFN6MYPiJ4UTB4cDYTyoS', 'superadmin'),
('DRH', 'Admin', 'admin.drh@tunisietelecom.tn', '$2b$10$dRg66Dt2GpFFrdGeMhK0Besw5XSaV.VfZFN6MYPiJ4UTB4cDYTyoS', 'admin');
-- Mot de passe pour tous les admins: Admin@2025

-- Crédits de test
INSERT INTO credits (reference, user_id, type_credit, montant, echeance, statut, commentaire, date_depot) VALUES
('CR-20250621-11111-0001', 2, 'Personnel', 2500.00, 15, 'En attente', NULL, '2025-06-21'),
('CR-20250515-11111-0002', 2, 'Solfa', 1000.00, 6, 'Accepté', 'Dossier complet', '2025-05-15'),
('CR-20250310-11111-0003', 2, 'Consommation', 5000.00, 24, 'Refusé', 'Capacité de remboursement insuffisante', '2025-03-10'),
('CR-20250601-22222-0001', 3, 'Personnel', 3000.00, 18, 'En attente', NULL, '2025-06-01'),
('CR-20250420-22222-0002', 3, 'Solfa', 800.00, 4, 'Accepté', 'Validé par RH', '2025-04-20');

-- Notifications de test
INSERT INTO notifications (admin_id, type, title, message, credit_id, user_id) VALUES
(1, 'new_request', 'Nouvelle demande de crédit', 'Une nouvelle demande de crédit Personnel de 2500 DT a été soumise par Nour Lassoued.', 1, 2),
(1, 'new_request', 'Nouvelle demande de crédit', 'Une nouvelle demande de crédit Consommation de 5000 DT a été soumise par Nour Lassoued.', 3, 2),
(1, 'accepted', 'Demande acceptée', 'La demande de crédit Solfa de 1000 DT de Nour Lassoued a été acceptée.', 2, 2);
