<?php
$host = 'localhost';
$db   = 'gestion_credit';
$user = 'root';
$pass = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
    $stmt = $pdo->prepare("SELECT * FROM admins WHERE email = ?");
    $stmt->execute(['superadmin@tunisietelecom.tn']);
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$admin) {
        echo "❌ Admin introuvable en base !";
    } else {
        echo "✅ Admin trouvé : " . $admin['email'] . "<br>";
        echo "Hash en BDD : " . $admin['password'] . "<br>";
        echo "Longueur hash : " . strlen($admin['password']) . "<br><br>";

        $test1 = password_verify('password', $admin['password']);
        $test2 = password_verify('Admin@2025', $admin['password']);

        echo "Test mot de passe 'password' : " . ($test1 ? "✅ OK" : "❌ FAUX") . "<br>";
        echo "Test mot de passe 'Admin@2025' : " . ($test2 ? "✅ OK" : "❌ FAUX") . "<br><br>";

        // Réinitialiser avec un nouveau hash généré maintenant
        $newHash = password_hash('Admin@2025', PASSWORD_BCRYPT);
        $pdo->prepare("UPDATE admins SET password = ?")->execute([$newHash]);
        echo "🔄 Nouveau hash généré et sauvegardé : " . $newHash . "<br>";
        echo "<br><strong>✅ Essayez maintenant avec : Admin@2025</strong>";
    }
} catch (PDOException $e) {
    echo "❌ Erreur BDD : " . $e->getMessage();
}
?>
