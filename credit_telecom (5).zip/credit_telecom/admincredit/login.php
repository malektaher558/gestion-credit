<?php
require_once 'includes/admin_config.php';

if (adminIsLoggedIn()) adminRedirect(ADMIN_BASE_URL . '/dashboard.php');

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = adminSanitize($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $error = 'Veuillez remplir tous les champs.';
    } else {
        $db   = getAdminDB();
        $stmt = $db->prepare("SELECT * FROM admins WHERE email = ? AND is_active = 1");
        $stmt->execute([$email]);
        $admin = $stmt->fetch();

        if ($admin && password_verify($password, $admin['password'])) {
            $_SESSION['admin_id']   = $admin['id'];
            $_SESSION['admin_role'] = $admin['role'];
            $_SESSION['admin_nom']  = $admin['nom'];

            // Update last login
            $db->prepare("UPDATE admins SET last_login=NOW() WHERE id=?")->execute([$admin['id']]);

            adminFlash('success', 'Bienvenue, ' . $admin['prenom'] . ' ' . $admin['nom'] . ' !');
            adminRedirect(ADMIN_BASE_URL . '/dashboard.php');
        } else {
            $error = 'Email ou mot de passe incorrect.';
            // Security delay
            sleep(1);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Admin Login — Crédit TT</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700;800&family=IBM+Plex+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= ADMIN_BASE_URL ?>/assets/css/admin.css">
</head>
<body>
<div class="auth-wrap">
    <div class="auth-box">
        <div class="auth-logo">
            <div class="auth-icon">
                <img src="<?= ADMIN_BASE_URL ?>/assets/img/logo_tt.png" alt="Tunisie Telecom" style="width:72px;height:72px;object-fit:contain;">
            </div>
            <h2>Administration</h2>
            <p>Crédit TT — Tunisie Telecom</p>
        </div>

        <?php if ($error): ?>
        <div class="alert alert-danger py-2 mb-3" style="font-size:.84rem;border-radius:8px;">
            <i class="fa fa-exclamation-triangle me-2"></i><?= $error ?>
        </div>
        <?php endif; ?>

        <form method="POST" novalidate>
            <div class="mb-3">
                <label class="form-label"><i class="fa fa-envelope"></i> Email administrateur</label>
                <div class="input-wrap">
                    <i class="fi fa fa-envelope"></i>
                    <input type="email" name="email" class="form-control"
                           placeholder="admin@tunisietelecom.tn"
                           value="<?= adminSanitize($_POST['email'] ?? '') ?>" required autofocus>
                </div>
            </div>

            <div class="mb-4">
                <label class="form-label"><i class="fa fa-lock"></i> Mot de passe</label>
                <div class="input-wrap">
                    <i class="fi fa fa-lock"></i>
                    <input type="password" name="password" class="form-control" placeholder="••••••••" required>
                    <button type="button" class="toggle-pass"><i class="fa fa-eye"></i></button>
                </div>
            </div>

            <button type="submit" class="btn-auth-submit">
                <i class="fa fa-shield-alt"></i> Accéder au panneau admin
            </button>
        </form>

        <div class="mt-4 p-3" style="background:rgba(0,87,184,.06);border-radius:9px;font-size:.76rem;color:var(--text-m);">
            <i class="fa fa-info-circle text-p me-1"></i>
            Accès réservé aux administrateurs autorisés.<br>
            En cas de problème, contactez le support DSI.
        </div>

        <hr style="margin:20px 0;border-color:var(--border)">
        <p style="font-size:.7rem;color:var(--text-l);text-align:center;">© 2025 Tunisie Telecom — Admin v<?= ADMIN_VERSION ?></p>
    </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
<script src="<?= ADMIN_BASE_URL ?>/assets/js/admin.js"></script>
</body>
</html>
