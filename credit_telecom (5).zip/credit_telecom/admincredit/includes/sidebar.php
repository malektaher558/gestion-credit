<?php
$admin       = getCurrentAdmin();
$unread      = getUnreadCount($admin['id']);
$currentFile = basename($_SERVER['PHP_SELF']);
$currentDir  = basename(dirname($_SERVER['PHP_SELF']));

function isActive(array $pages, string $file): string {
    return in_array($file, $pages) ? 'active' : '';
}
?>
<aside class="admin-sidebar" id="adminSidebar">
    <!-- Brand -->
    <div class="admin-brand">
        <div class="brand-icon">
            <img src="<?= ADMIN_BASE_URL ?>/assets/img/logo_tt.png" alt="Tunisie Telecom" style="width:42px;height:42px;object-fit:contain;border-radius:8px;">
        </div>
        <div>
            <div class="brand-title">Crédit TT</div>
            <div class="brand-sub">Administration</div>
        </div>
        <button class="sidebar-close d-lg-none" id="sidebarClose"><i class="fa fa-times"></i></button>
    </div>

    <!-- Admin profile -->
    <div class="admin-profile">
        <div class="admin-avatar"><?= strtoupper(substr($admin['prenom'],0,1).substr($admin['nom'],0,1)) ?></div>
        <div class="admin-info">
            <div class="admin-name"><?= adminSanitize($admin['prenom'].' '.$admin['nom']) ?></div>
            <div class="admin-role"><?= $admin['role'] === 'superadmin' ? '⭐ Super Admin' : '🔑 Admin' ?></div>
        </div>
    </div>

    <!-- Navigation -->
    <nav class="admin-nav">
        <div class="nav-label">PRINCIPAL</div>

        <a href="<?= ADMIN_BASE_URL ?>/dashboard.php" class="nav-link-item <?= isActive(['dashboard.php'], $currentFile) ?>">
            <i class="fa fa-chart-pie"></i><span>Tableau de bord</span>
        </a>

        <a href="<?= ADMIN_BASE_URL ?>/notifications.php" class="nav-link-item <?= isActive(['notifications.php'], $currentFile) ?>">
            <i class="fa fa-bell"></i><span>Notifications</span>
            <?php if ($unread > 0): ?>
            <span class="nav-badge-count"><?= $unread ?></span>
            <?php endif; ?>
        </a>

        <div class="nav-label mt-3">GESTION</div>

        <a href="<?= ADMIN_BASE_URL ?>/users.php" class="nav-link-item <?= isActive(['users.php','user_view.php','user_edit.php'], $currentFile) ?>">
            <i class="fa fa-users"></i><span>Utilisateurs</span>
        </a>

        <a href="<?= ADMIN_BASE_URL ?>/credits.php" class="nav-link-item <?= isActive(['credits.php','credit_view.php'], $currentFile) ?>">
            <i class="fa fa-file-invoice-dollar"></i><span>Demandes de crédit</span>
            <?php
            $pending = getAdminDB()->query("SELECT COUNT(*) FROM credits WHERE statut='En attente'")->fetchColumn();
            if ($pending > 0): ?>
            <span class="nav-badge-count"><?= $pending ?></span>
            <?php endif; ?>
        </a>

        <a href="<?= ADMIN_BASE_URL ?>/statistics.php" class="nav-link-item <?= isActive(['statistics.php'], $currentFile) ?>">
            <i class="fa fa-chart-bar"></i><span>Statistiques</span>
        </a>

        <?php if (isSuperAdmin()): ?>
        <div class="nav-label mt-3">SUPER ADMIN</div>
        <a href="<?= ADMIN_BASE_URL ?>/admins.php" class="nav-link-item <?= isActive(['admins.php'], $currentFile) ?>">
            <i class="fa fa-user-shield"></i><span>Admins</span>
        </a>
        <?php endif; ?>
    </nav>

    <!-- Footer -->
    <div class="sidebar-footer">
        <a href="<?= ADMIN_BASE_URL ?>/logout.php" class="nav-link-item logout-link">
            <i class="fa fa-sign-out-alt"></i><span>Déconnexion</span>
        </a>
        <div class="sidebar-version">v<?= ADMIN_VERSION ?></div>
    </div>
</aside>
<div class="sidebar-overlay" id="sidebarOverlay"></div>
