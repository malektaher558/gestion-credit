<?php
$admin  = getCurrentAdmin();
$unread = getUnreadCount($admin['id']);
$flash  = adminGetFlash();

// Recent notifications for dropdown
$db    = getAdminDB();
$notifStmt = $db->prepare("SELECT * FROM notifications WHERE admin_id=? ORDER BY created_at DESC LIMIT 5");
$notifStmt->execute([$admin['id']]);
$recentNotifs = $notifStmt->fetchAll();
?>
<div class="admin-main" id="adminMain">
<nav class="admin-topbar">
    <!-- Toggle -->
    <button class="topbar-toggle" id="sidebarToggle">
        <i class="fa fa-bars"></i>
    </button>

    <!-- Page title -->
    <div class="topbar-title">
        <h1><?= isset($pageTitle) ? adminSanitize($pageTitle) : 'Dashboard' ?></h1>
        <?php if (!empty($breadcrumb)): ?>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="<?= ADMIN_BASE_URL ?>/dashboard.php"><i class="fa fa-home"></i></a></li>
                <?php foreach ($breadcrumb as $b): ?>
                <li class="breadcrumb-item <?= isset($b['active']) ? 'active' : '' ?>">
                    <?= isset($b['url']) ? '<a href="'.$b['url'].'">'.adminSanitize($b['label']).'</a>' : adminSanitize($b['label']) ?>
                </li>
                <?php endforeach; ?>
            </ol>
        </nav>
        <?php endif; ?>
    </div>

    <!-- Topbar actions -->
    <div class="topbar-actions">
        <!-- Notifications dropdown -->
        <div class="dropdown">
            <button class="topbar-btn position-relative" data-bs-toggle="dropdown">
                <i class="fa fa-bell"></i>
                <?php if ($unread > 0): ?>
                <span class="notif-dot"><?= $unread ?></span>
                <?php endif; ?>
            </button>
            <div class="dropdown-menu dropdown-menu-end notif-dropdown">
                <div class="notif-header">
                    <span class="fw-700">Notifications</span>
                    <?php if ($unread > 0): ?>
                    <a href="<?= ADMIN_BASE_URL ?>/notifications.php?mark_read=1" class="notif-mark-read">Tout marquer lu</a>
                    <?php endif; ?>
                </div>
                <?php if (empty($recentNotifs)): ?>
                <div class="notif-empty"><i class="fa fa-bell-slash"></i><br>Aucune notification</div>
                <?php else: ?>
                <?php foreach ($recentNotifs as $n):
                    $icon = match($n['type']) {
                        'new_request'    => ['fa-file-plus', '#0057B8'],
                        'accepted'       => ['fa-check-circle', '#28A745'],
                        'refused'        => ['fa-times-circle', '#DC3545'],
                        'user_registered'=> ['fa-user-plus', '#00AEEF'],
                        default          => ['fa-bell', '#6B7280'],
                    };
                ?>
                <a href="<?= ADMIN_BASE_URL ?>/notifications.php" class="notif-item <?= $n['is_read'] ? '' : 'unread' ?>">
                    <div class="notif-icon" style="background:<?= $icon[1] ?>20;color:<?= $icon[1] ?>;">
                        <i class="fa <?= $icon[0] ?>"></i>
                    </div>
                    <div class="notif-body">
                        <div class="notif-title"><?= adminSanitize($n['title']) ?></div>
                        <div class="notif-time"><?= date('d/m H:i', strtotime($n['created_at'])) ?></div>
                    </div>
                </a>
                <?php endforeach; ?>
                <a href="<?= ADMIN_BASE_URL ?>/notifications.php" class="notif-footer">Voir toutes les notifications</a>
                <?php endif; ?>
            </div>
        </div>

        <!-- Admin menu -->
        <div class="dropdown">
            <button class="topbar-admin-btn" data-bs-toggle="dropdown">
                <div class="topbar-avatar"><?= strtoupper(substr($admin['prenom'],0,1).substr($admin['nom'],0,1)) ?></div>
                <span class="d-none d-md-inline"><?= adminSanitize($admin['prenom']) ?></span>
                <i class="fa fa-chevron-down ms-1" style="font-size:.7rem;"></i>
            </button>
            <ul class="dropdown-menu dropdown-menu-end">
                <li><a class="dropdown-item" href="<?= ADMIN_BASE_URL ?>/profile.php"><i class="fa fa-user me-2"></i>Mon profil</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item text-danger" href="<?= ADMIN_BASE_URL ?>/logout.php"><i class="fa fa-sign-out-alt me-2"></i>Déconnexion</a></li>
            </ul>
        </div>
    </div>
</nav>

<!-- Flash message -->
<?php if ($flash): ?>
<div class="flash-wrap">
    <div class="alert alert-<?= $flash['type']==='success'?'success':($flash['type']==='error'?'danger':'info') ?> alert-dismissible fade show flash-msg">
        <i class="fa fa-<?= $flash['type']==='success'?'check-circle':($flash['type']==='error'?'exclamation-circle':'info-circle') ?> me-2"></i>
        <?= adminSanitize($flash['message']) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
</div>
<?php endif; ?>

<div class="admin-content">
