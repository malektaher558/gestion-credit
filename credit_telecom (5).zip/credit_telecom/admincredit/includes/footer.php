    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
    <script src="<?= ADMIN_BASE_URL ?>/assets/js/admin.js"></script>
    <?= $extraJS ?? '' ?>
</body>
</html>
