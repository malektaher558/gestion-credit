<?php
// ============================================
// admin/includes/admin_config.php
// Configuration Admin
// ============================================

if (!defined('DB_HOST')) {
    define('DB_HOST',    'localhost');
    define('DB_NAME',    'gestion_credit');
    define('DB_USER',    'root');
    define('DB_PASS',    '');
    define('DB_CHARSET', 'utf8mb4');
}

define('ADMIN_BASE_URL', 'http://localhost/credit_telecom/admincredit');
define('ADMIN_VERSION',  '1.0.0');

// Credit types and statuses
if (!defined('CREDIT_TYPES'))   define('CREDIT_TYPES',   ['Solfa', 'Personnel', 'Consommation']);
if (!defined('CREDIT_STATUTS')) define('CREDIT_STATUTS', ['En attente', 'Accepté', 'Refusé']);
if (!defined('ITEMS_PER_PAGE')) define('ITEMS_PER_PAGE', 10);

// Start session if not started
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 3600,
        'path'     => '/',
        'secure'   => false,
        'httponly' => true,
        'samesite' => 'Strict',
    ]);
    session_start();
}

// PDO singleton
function getAdminDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = "mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=".DB_CHARSET;
        $opts = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $opts);
        } catch (PDOException $e) {
            die('<div style="font-family:sans-serif;padding:40px;color:#dc3545;"><h2>Erreur de connexion BDD</h2><p>'.$e->getMessage().'</p></div>');
        }
    }
    return $pdo;
}

// ── Auth helpers ─────────────────────────────
function adminIsLoggedIn(): bool {
    return isset($_SESSION['admin_id']) && !empty($_SESSION['admin_id']);
}

function requireAdminLogin(): void {
    if (!adminIsLoggedIn()) {
        header('Location: ' . ADMIN_BASE_URL . '/login.php');
        exit();
    }
}

function getCurrentAdmin(): ?array {
    if (!adminIsLoggedIn()) return null;
    $db   = getAdminDB();
    $stmt = $db->prepare("SELECT * FROM admins WHERE id = ? AND is_active = 1");
    $stmt->execute([$_SESSION['admin_id']]);
    return $stmt->fetch() ?: null;
}

function isSuperAdmin(): bool {
    return isset($_SESSION['admin_role']) && $_SESSION['admin_role'] === 'superadmin';
}

// ── Sanitize / Flash ─────────────────────────
function adminSanitize(string $input): string {
    return htmlspecialchars(strip_tags(trim($input)), ENT_QUOTES, 'UTF-8');
}

function adminFlash(string $type, string $message): void {
    $_SESSION['admin_flash'] = ['type' => $type, 'message' => $message];
}

function adminGetFlash(): ?array {
    if (isset($_SESSION['admin_flash'])) {
        $f = $_SESSION['admin_flash'];
        unset($_SESSION['admin_flash']);
        return $f;
    }
    return null;
}

function adminRedirect(string $url): void {
    header("Location: $url");
    exit();
}

// ── Notifications ─────────────────────────────
function createNotification(int $adminId, string $type, string $title, string $message, ?int $creditId = null, ?int $userId = null): void {
    try {
        $db   = getAdminDB();
        $stmt = $db->prepare("INSERT INTO notifications (admin_id, type, title, message, credit_id, user_id) VALUES (?,?,?,?,?,?)");
        $stmt->execute([$adminId, $type, $title, $message, $creditId, $userId]);
    } catch (Exception $e) { /* silent */ }
}

function notifyAllAdmins(string $type, string $title, string $message, ?int $creditId = null, ?int $userId = null): void {
    try {
        $db    = getAdminDB();
        $admins = $db->query("SELECT id FROM admins WHERE is_active=1")->fetchAll();
        foreach ($admins as $a) {
            createNotification($a['id'], $type, $title, $message, $creditId, $userId);
        }
    } catch (Exception $e) { /* silent */ }
}

function getUnreadCount(int $adminId): int {
    try {
        $db   = getAdminDB();
        $stmt = $db->prepare("SELECT COUNT(*) FROM notifications WHERE admin_id=? AND is_read=0");
        $stmt->execute([$adminId]);
        return (int)$stmt->fetchColumn();
    } catch (Exception $e) { return 0; }
}

function markAllRead(int $adminId): void {
    $db   = getAdminDB();
    $stmt = $db->prepare("UPDATE notifications SET is_read=1 WHERE admin_id=?");
    $stmt->execute([$adminId]);
}

// ── Stats helper ─────────────────────────────
function getGlobalStats(): array {
    $db = getAdminDB();
    return [
        'total_users'    => $db->query("SELECT COUNT(*) FROM users")->fetchColumn(),
        'total_credits'  => $db->query("SELECT COUNT(*) FROM credits")->fetchColumn(),
        'pending'        => $db->query("SELECT COUNT(*) FROM credits WHERE statut='En attente'")->fetchColumn(),
        'accepted'       => $db->query("SELECT COUNT(*) FROM credits WHERE statut='Accepté'")->fetchColumn(),
        'refused'        => $db->query("SELECT COUNT(*) FROM credits WHERE statut='Refusé'")->fetchColumn(),
        'total_montant'  => $db->query("SELECT COALESCE(SUM(montant),0) FROM credits")->fetchColumn(),
        'montant_accorde'=> $db->query("SELECT COALESCE(SUM(montant),0) FROM credits WHERE statut='Accepté'")->fetchColumn(),
    ];
}
?>
