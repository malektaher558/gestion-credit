// ============================================
// Admin Panel — JavaScript
// ============================================

document.addEventListener('DOMContentLoaded', function () {

    // ── Sidebar toggle ───────────────────────
    const sidebar  = document.getElementById('adminSidebar');
    const overlay  = document.getElementById('sidebarOverlay');
    const toggleBtn = document.getElementById('sidebarToggle');
    const closeBtn  = document.getElementById('sidebarClose');

    function openSidebar()  { sidebar?.classList.add('open'); overlay?.classList.add('open'); document.body.style.overflow='hidden'; }
    function closeSidebar() { sidebar?.classList.remove('open'); overlay?.classList.remove('open'); document.body.style.overflow=''; }

    toggleBtn?.addEventListener('click', openSidebar);
    closeBtn?.addEventListener('click', closeSidebar);
    overlay?.addEventListener('click', closeSidebar);

    // ── Password toggle ──────────────────────
    document.querySelectorAll('.toggle-pass').forEach(btn => {
        btn.addEventListener('click', function () {
            const inp  = this.closest('.input-wrap').querySelector('input');
            const icon = this.querySelector('i');
            if (inp.type === 'password') { inp.type = 'text'; icon.classList.replace('fa-eye','fa-eye-slash'); }
            else { inp.type = 'password'; icon.classList.replace('fa-eye-slash','fa-eye'); }
        });
    });

    // ── Auto-dismiss flash ───────────────────
    setTimeout(() => {
        document.querySelectorAll('.flash-msg').forEach(el => {
            try { new bootstrap.Alert(el).close(); } catch(e){}
        });
    }, 5000);

    // ── Confirm dialogs ──────────────────────
    document.querySelectorAll('[data-confirm]').forEach(el => {
        el.addEventListener('click', function (e) {
            if (!confirm(this.dataset.confirm || 'Êtes-vous sûr ?')) e.preventDefault();
        });
    });

    // ── Clickable rows ───────────────────────
    document.querySelectorAll('tr[data-href]').forEach(row => {
        row.style.cursor = 'pointer';
        row.addEventListener('click', function (e) {
            if (!e.target.closest('a,button')) window.location.href = this.dataset.href;
        });
    });

    // ── Search input debounce ────────────────
    const searchInput = document.getElementById('searchInput');
    let searchTimeout;
    searchInput?.addEventListener('input', function () {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            const form = this.closest('form');
            if (form) form.submit();
        }, 500);
    });

    // ── Animate counter numbers ──────────────
    document.querySelectorAll('.stat-value[data-count]').forEach(el => {
        const target = parseInt(el.dataset.count) || 0;
        let current = 0;
        const step = Math.ceil(target / 40);
        const timer = setInterval(() => {
            current = Math.min(current + step, target);
            el.textContent = current.toLocaleString('fr-TN');
            if (current >= target) clearInterval(timer);
        }, 30);
    });
});

// ── Charts factory ───────────────────────────
function buildDoughnut(id, labels, data, colors) {
    const ctx = document.getElementById(id);
    if (!ctx) return;
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels,
            datasets: [{ data, backgroundColor: colors, borderWidth: 2, borderColor: '#fff', hoverOffset: 6 }]
        },
        options: {
            responsive: true,
            cutout: '70%',
            plugins: {
                legend: { position: 'bottom', labels: { padding: 16, font: { size: 12, family: 'IBM Plex Sans' } } },
                tooltip: { callbacks: { label: ctx => ' ' + ctx.label + ': ' + ctx.parsed.toLocaleString('fr-TN') } }
            }
        }
    });
}

function buildBar(id, labels, datasets, opts = {}) {
    const ctx = document.getElementById(id);
    if (!ctx) return;
    new Chart(ctx, {
        type: 'bar',
        data: { labels, datasets },
        options: {
            responsive: true,
            scales: {
                y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,.06)' }, ticks: { font: { size: 11 } } },
                x: { grid: { display: false }, ticks: { font: { size: 11 } } }
            },
            plugins: {
                legend: { display: datasets.length > 1, labels: { padding: 14, font: { size: 12 } } },
                tooltip: { callbacks: { label: ctx => ' ' + ctx.dataset.label + ': ' + ctx.parsed.y.toLocaleString('fr-TN') + (opts.suffix || '') } }
            },
            ...opts
        }
    });
}

function buildLine(id, labels, datasets) {
    const ctx = document.getElementById(id);
    if (!ctx) return;
    new Chart(ctx, {
        type: 'line',
        data: { labels, datasets },
        options: {
            responsive: true,
            tension: 0.4,
            scales: {
                y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,.06)' }, ticks: { font: { size: 11 } } },
                x: { grid: { display: false }, ticks: { font: { size: 11 } } }
            },
            plugins: { legend: { labels: { padding: 14, font: { size: 12 } } } }
        }
    });
}
