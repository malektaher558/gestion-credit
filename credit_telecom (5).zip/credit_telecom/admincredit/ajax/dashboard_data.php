<?php
// ============================================
// ajax/dashboard_data.php
// Endpoint AJAX pour les données du dashboard
// ============================================
require_once '../includes/admin_config.php';
requireAdminLogin();

header('Content-Type: application/json; charset=utf-8');

$action = $_GET['action'] ?? '';
$search = trim($_GET['q'] ?? '');
$page   = max(1, intval($_GET['page'] ?? 1));
$per    = 10;
$offset = ($page - 1) * $per;

function sanitizeOut(string $val): string {
    return htmlspecialchars($val, ENT_QUOTES, 'UTF-8');
}

function buildWhere(array &$params, string $search, string $extra = ''): string {
    $w = 'WHERE 1=1';
    if ($extra) $w .= $extra;
    if ($search) {
        $w .= " AND (u.nom LIKE ? OR u.prenom LIKE ? OR u.email LIKE ? OR u.matricule LIKE ?)";
        foreach (range(0,3) as $i) $params[] = "%$search%";
    }
    return $w;
}

try {
    $db = getAdminDB();

    switch ($action) {

        // ── Utilisateurs inscrits ──────────────────────────────────
        case 'users':
            $params = [];
            $where  = buildWhere($params, $search);

            $total = $db->prepare("SELECT COUNT(*) FROM users u $where");
            $total->execute($params);
            $total = (int)$total->fetchColumn();
            $pages = max(1, ceil($total / $per));

            $stmt = $db->prepare("
                SELECT u.id, u.matricule, u.nom, u.prenom, u.email,
                       u.role, u.created_at,
                       COUNT(c.id) as nb_credits
                FROM users u
                LEFT JOIN credits c ON c.user_id = u.id
                $where
                GROUP BY u.id
                ORDER BY u.created_at DESC
                LIMIT $per OFFSET $offset
            ");
            $stmt->execute($params);
            $rows = $stmt->fetchAll();

            $data = [];
            foreach ($rows as $r) {
                $data[] = [
                    'id'          => $r['id'],
                    'matricule'   => sanitizeOut($r['matricule']),
                    'nom'         => sanitizeOut($r['nom']),
                    'prenom'      => sanitizeOut($r['prenom']),
                    'email'       => sanitizeOut($r['email']),
                    'role'        => sanitizeOut($r['role']),
                    'nb_credits'  => (int)$r['nb_credits'],
                    'created_at'  => date('d/m/Y H:i', strtotime($r['created_at'])),
                ];
            }
            echo json_encode(['success'=>true,'data'=>$data,'total'=>$total,'pages'=>$pages,'page'=>$page]);
            break;

        // ── Toutes les demandes ────────────────────────────────────
        case 'credits':
        case 'pending':
        case 'accepted':
        case 'refused':
            $params = [];
            $extra  = '';
            if ($action === 'pending')  { $extra = " AND c.statut = 'En attente'"; }
            if ($action === 'accepted') { $extra = " AND c.statut = 'Accepté'"; }
            if ($action === 'refused')  { $extra = " AND c.statut = 'Refusé'"; }

            $creditSearch = '';
            if ($search) {
                $creditSearch = " AND (c.reference LIKE ? OR u.nom LIKE ? OR u.prenom LIKE ? OR u.matricule LIKE ?)";
                foreach (range(0,3) as $i) $params[] = "%$search%";
            }

            $cntParams = $params;
            $totalStmt = $db->prepare("SELECT COUNT(*) FROM credits c JOIN users u ON c.user_id=u.id WHERE 1=1 $extra $creditSearch");
            $totalStmt->execute($cntParams);
            $total = (int)$totalStmt->fetchColumn();
            $pages = max(1, ceil($total / $per));

            $stmt = $db->prepare("
                SELECT c.id, c.reference, c.type_credit, c.montant, c.echeance,
                       c.statut, c.date_depot, c.created_at, c.commentaire, c.admin_comment,
                       u.nom, u.prenom, u.matricule, u.email
                FROM credits c
                JOIN users u ON c.user_id = u.id
                WHERE 1=1 $extra $creditSearch
                ORDER BY c.created_at DESC
                LIMIT $per OFFSET $offset
            ");
            $stmt->execute($params);
            $rows = $stmt->fetchAll();

            $data = [];
            foreach ($rows as $r) {
                $data[] = [
                    'id'            => $r['id'],
                    'reference'     => sanitizeOut($r['reference']),
                    'type_credit'   => sanitizeOut($r['type_credit']),
                    'montant'       => number_format($r['montant'], 0, ',', ' '),
                    'montant_raw'   => (float)$r['montant'],
                    'echeance'      => (int)$r['echeance'],
                    'statut'        => sanitizeOut($r['statut']),
                    'date_depot'    => date('d/m/Y', strtotime($r['date_depot'])),
                    'created_at'    => date('d/m/Y H:i', strtotime($r['created_at'])),
                    'commentaire'   => sanitizeOut($r['commentaire'] ?? ''),
                    'admin_comment' => sanitizeOut($r['admin_comment'] ?? ''),
                    'nom'           => sanitizeOut($r['nom']),
                    'prenom'        => sanitizeOut($r['prenom']),
                    'matricule'     => sanitizeOut($r['matricule']),
                    'email'         => sanitizeOut($r['email']),
                ];
            }
            echo json_encode(['success'=>true,'data'=>$data,'total'=>$total,'pages'=>$pages,'page'=>$page]);
            break;

        // ── DT accordés ───────────────────────────────────────────
        case 'montant':
            $params = [];
            $creditSearch = '';
            if ($search) {
                $creditSearch = " AND (c.reference LIKE ? OR u.nom LIKE ? OR u.prenom LIKE ? OR u.matricule LIKE ?)";
                foreach (range(0,3) as $i) $params[] = "%$search%";
            }

            $totalStmt = $db->prepare("SELECT COUNT(*) FROM credits c JOIN users u ON c.user_id=u.id WHERE c.statut='Accepté' $creditSearch");
            $totalStmt->execute($params);
            $total = (int)$totalStmt->fetchColumn();
            $pages = max(1, ceil($total / $per));

            $stmt = $db->prepare("
                SELECT c.id, c.reference, c.type_credit, c.montant, c.echeance,
                       c.statut, c.date_depot, c.processed_at, c.created_at,
                       u.nom, u.prenom, u.matricule, u.email
                FROM credits c
                JOIN users u ON c.user_id = u.id
                WHERE c.statut = 'Accepté' $creditSearch
                ORDER BY c.processed_at DESC, c.created_at DESC
                LIMIT $per OFFSET $offset
            ");
            $stmt->execute($params);
            $rows = $stmt->fetchAll();

            $totalMontant = $db->query("SELECT COALESCE(SUM(montant),0) FROM credits WHERE statut='Accepté'")->fetchColumn();

            $data = [];
            foreach ($rows as $r) {
                $data[] = [
                    'id'           => $r['id'],
                    'reference'    => sanitizeOut($r['reference']),
                    'type_credit'  => sanitizeOut($r['type_credit']),
                    'montant'      => number_format($r['montant'], 0, ',', ' '),
                    'montant_raw'  => (float)$r['montant'],
                    'echeance'     => (int)$r['echeance'],
                    'date_depot'   => date('d/m/Y', strtotime($r['date_depot'])),
                    'processed_at' => $r['processed_at'] ? date('d/m/Y H:i', strtotime($r['processed_at'])) : '—',
                    'nom'          => sanitizeOut($r['nom']),
                    'prenom'       => sanitizeOut($r['prenom']),
                    'matricule'    => sanitizeOut($r['matricule']),
                    'email'        => sanitizeOut($r['email']),
                ];
            }
            echo json_encode([
                'success'        => true,
                'data'           => $data,
                'total'          => $total,
                'pages'          => $pages,
                'page'           => $page,
                'total_montant'  => number_format($totalMontant, 0, ',', ' '),
            ]);
            break;

        default:
            echo json_encode(['success'=>false,'message'=>'Action invalide']);
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success'=>false,'message'=>'Erreur serveur: '.$e->getMessage()]);
}
