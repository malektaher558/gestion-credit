<?php
require_once 'includes/admin_config.php';
requireAdminLogin();

$db  = getAdminDB();
$id  = intval($_GET['id'] ?? 0);

$stmt = $db->prepare("SELECT c.*, u.nom, u.prenom, u.matricule, u.email FROM credits c JOIN users u ON c.user_id=u.id WHERE c.id=?");
$stmt->execute([$id]);
$credit = $stmt->fetch();
if (!$credit) { adminFlash('error','Demande introuvable.'); adminRedirect(ADMIN_BASE_URL.'/credits.php'); }

$pageTitle  = 'Détail de la demande';
$breadcrumb = [['label'=>'Demandes','url'=>ADMIN_BASE_URL.'/credits.php'],['label'=>$credit['reference'],'active'=>true]];

$bc = match($credit['statut']) { 'Accepté'=>'bs-accepted','Refusé'=>'bs-refused',default=>'bs-pending' };
$bi = match($credit['statut']) { 'Accepté'=>'fa-check-circle','Refusé'=>'fa-times-circle',default=>'fa-clock' };

require_once 'includes/header.php';
?>
<div class="d-flex">
<?php require_once 'includes/sidebar.php'; ?>
<?php require_once 'includes/topbar.php'; ?>

<div class="row g-4">
    <div class="col-lg-8">
        <div class="card-a">
            <div class="card-a-header">
                <div class="card-a-title"><i class="fa fa-file-alt"></i> Détail de la demande</div>
                <span class="bs <?= $bc ?>"><i class="fa <?= $bi ?>"></i> <?= $credit['statut'] ?></span>
            </div>
            <div class="card-a-body">
                <div class="mb-4 p-3" style="background:var(--accent);border-radius:10px;">
                    <div style="font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:var(--text-m);">Référence</div>
                    <div class="ref-badge" style="font-size:.95rem;padding:4px 14px;display:inline-block;margin-top:4px;"><?= adminSanitize($credit['reference']) ?></div>
                </div>

                <div class="detail-sec">
                    <div class="detail-sec-title"><i class="fa fa-user"></i> Informations du demandeur</div>
                    <div class="detail-row"><span class="detail-label">Nom & Prénom</span><span class="detail-value fw7"><?= adminSanitize($credit['prenom'].' '.$credit['nom']) ?></span></div>
                    <div class="detail-row"><span class="detail-label">Matricule</span><span class="detail-value"><?= adminSanitize($credit['matricule']) ?></span></div>
                    <div class="detail-row"><span class="detail-label">Email</span><span class="detail-value"><?= adminSanitize($credit['email']) ?></span></div>
                </div>

                <div class="detail-sec">
                    <div class="detail-sec-title"><i class="fa fa-coins"></i> Détails du crédit</div>
                    <div class="detail-row"><span class="detail-label">Type</span><span class="detail-value"><span class="bs bs-type"><?= adminSanitize($credit['type_credit']) ?></span></span></div>
                    <div class="detail-row"><span class="detail-label">Montant</span><span class="detail-value"><span class="montant-xl" style="font-size:1.4rem;"><?= number_format($credit['montant'],2,',',' ') ?> DT</span></span></div>
                    <div class="detail-row"><span class="detail-label">Durée</span><span class="detail-value fw7"><?= $credit['echeance'] ?> mois</span></div>
                </div>

                <div class="detail-sec">
                    <div class="detail-sec-title"><i class="fa fa-calendar-check"></i> Statut & Dates</div>
                    <div class="detail-row"><span class="detail-label">Statut</span><span class="detail-value"><span class="bs <?= $bc ?>"><i class="fa <?= $bi ?>"></i> <?= $credit['statut'] ?></span></span></div>
                    <div class="detail-row"><span class="detail-label">Date de dépôt</span><span class="detail-value"><?= date('d/m/Y', strtotime($credit['date_depot'])) ?></span></div>
                    <div class="detail-row"><span class="detail-label">Créé le</span><span class="detail-value"><?= date('d/m/Y H:i', strtotime($credit['created_at'])) ?></span></div>
                    <?php if ($credit['processed_at']): ?>
                    <div class="detail-row"><span class="detail-label">Traité le</span><span class="detail-value"><?= date('d/m/Y H:i', strtotime($credit['processed_at'])) ?></span></div>
                    <?php endif; ?>
                </div>

                <?php if ($credit['admin_comment']): ?>
                <div class="detail-sec">
                    <div class="detail-sec-title"><i class="fa fa-comment-alt"></i> Commentaire administrateur</div>
                    <div class="p-3" style="background:var(--accent);border-radius:8px;font-size:.875rem;"><?= nl2br(adminSanitize($credit['admin_comment'])) ?></div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="card-a mb-4">
            <div class="card-a-header"><div class="card-a-title"><i class="fa fa-cog"></i> Actions</div></div>
            <div class="card-a-body d-grid gap-2">
                <?php if ($credit['statut'] === 'En attente'): ?>
                <button class="btn btn-success btn-sm" onclick='openDecisionModal(<?= $credit['id'] ?>, "Accepté", "<?= adminSanitize($credit['reference']) ?>")'>
                    <i class="fa fa-check me-2"></i>Accepter la demande
                </button>
                <button class="btn btn-danger btn-sm" onclick='openDecisionModal(<?= $credit['id'] ?>, "Refusé", "<?= adminSanitize($credit['reference']) ?>")'>
                    <i class="fa fa-times me-2"></i>Refuser la demande
                </button>
                <?php else: ?>
                <div class="p-3 text-center" style="background:var(--accent);border-radius:9px;font-size:.82rem;color:var(--text-m);">
                    <i class="fa fa-lock me-1"></i>Demande déjà traitée
                </div>
                <?php endif; ?>
                <a href="user_view.php?id=<?= $credit['user_id'] ?>" class="btn btn-outline-primary btn-sm">
                    <i class="fa fa-user me-2"></i>Voir profil employé
                </a>
                <a href="credits.php" class="btn btn-outline-secondary btn-sm">
                    <i class="fa fa-arrow-left me-2"></i>Retour à la liste
                </a>
            </div>
        </div>
    </div>
</div>

<!-- Decision Modal -->
<div class="modal fade" id="decisionModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalTitle"><i class="fa fa-gavel me-2"></i>Décision</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="credit_action.php">
                <div class="modal-body">
                    <input type="hidden" name="credit_id" id="modalCreditId" value="<?= $credit['id'] ?>">
                    <input type="hidden" name="statut" id="modalStatut">
                    <input type="hidden" name="redirect" value="<?= ADMIN_BASE_URL ?>/credit_view.php?id=<?= $credit['id'] ?>">
                    <div class="p-3 mb-3" id="modalBanner" style="border-radius:9px;"></div>
                    <div class="mb-3">
                        <label class="form-label"><i class="fa fa-comment"></i> Commentaire (optionnel)</label>
                        <textarea name="admin_comment" class="form-control" rows="3" placeholder="Motif de la décision..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-sm" id="modalSubmitBtn">Confirmer</button>
                </div>
            </form>
        </div>
    </div>
</div>

</div></div></div>

<?php $extraJS = <<<JS
<script>
function openDecisionModal(id, statut, ref) {
    document.getElementById('modalStatut').value = statut;
    const banner = document.getElementById('modalBanner');
    const btn    = document.getElementById('modalSubmitBtn');
    if (statut === 'Accepté') {
        banner.innerHTML = '<i class="fa fa-check-circle me-2" style="color:#28A745"></i>Accepter la demande <strong>' + ref + '</strong> ?';
        banner.style.cssText = 'background:rgba(40,167,69,.08);color:#155724;border-radius:9px;';
        btn.className = 'btn btn-success btn-sm'; btn.innerHTML = '<i class="fa fa-check me-1"></i>Accepter';
    } else {
        banner.innerHTML = '<i class="fa fa-times-circle me-2" style="color:#DC3545"></i>Refuser la demande <strong>' + ref + '</strong> ?';
        banner.style.cssText = 'background:rgba(220,53,69,.08);color:#721c24;border-radius:9px;';
        btn.className = 'btn btn-danger btn-sm'; btn.innerHTML = '<i class="fa fa-times me-1"></i>Refuser';
    }
    new bootstrap.Modal(document.getElementById('decisionModal')).show();
}
</script>
JS;
require_once 'includes/footer.php'; ?>
