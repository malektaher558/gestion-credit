<?php
require_once 'includes/admin_config.php';
requireAdminLogin();

$db  = getAdminDB();
$uid = intval($_GET['id'] ?? 0);

$stmt = $db->prepare("SELECT * FROM users WHERE id=?");
$stmt->execute([$uid]);
$user = $stmt->fetch();
if (!$user) { adminFlash('error','Utilisateur introuvable.'); adminRedirect(ADMIN_BASE_URL.'/users.php'); }

$pageTitle  = 'Profil utilisateur';
$breadcrumb = [['label'=>'Utilisateurs','url'=>ADMIN_BASE_URL.'/users.php'],['label'=>$user['prenom'].' '.$user['nom'],'active'=>true]];

// User credits
$credits = $db->prepare("SELECT * FROM credits WHERE user_id=? ORDER BY created_at DESC");
$credits->execute([$uid]);
$credits = $credits->fetchAll();

// User stats
$stats = $db->prepare("SELECT
    COUNT(*) as total,
    SUM(CASE WHEN statut='En attente' THEN 1 ELSE 0 END) as pending,
    SUM(CASE WHEN statut='Accepté' THEN 1 ELSE 0 END) as accepted,
    SUM(CASE WHEN statut='Refusé' THEN 1 ELSE 0 END) as refused,
    SUM(CASE WHEN statut='Accepté' THEN montant ELSE 0 END) as montant_total
    FROM credits WHERE user_id=?");
$stats->execute([$uid]);
$stats = $stats->fetch();

require_once 'includes/header.php';
?>
<div class="d-flex">
<?php require_once 'includes/sidebar.php'; ?>
<?php require_once 'includes/topbar.php'; ?>

<div class="row g-4">
    <div class="col-lg-4">
        <!-- Profile card -->
        <div class="card-a mb-4">
            <div class="card-a-body text-center">
                <div style="width:70px;height:70px;background:linear-gradient(135deg,var(--p),var(--s));border-radius:50%;display:flex;align-items:center;justify-content:center;font-family:'Sora',sans-serif;font-weight:800;font-size:1.3rem;color:#fff;margin:0 auto 14px;box-shadow:0 6px 20px rgba(0,87,184,.3);">
                    <?= strtoupper(substr($user['prenom'],0,1).substr($user['nom'],0,1)) ?>
                </div>
                <div class="fw7 font-sora" style="font-size:1.05rem;"><?= adminSanitize($user['prenom'].' '.$user['nom']) ?></div>
                <div style="color:var(--text-m);font-size:.82rem;margin:4px 0;"><?= adminSanitize($user['email']) ?></div>
                <span class="bs bs-type">Mat: <?= adminSanitize($user['matricule']) ?></span>
                <div style="margin-top:12px;font-size:.75rem;color:var(--text-l);">Inscrit le <?= date('d/m/Y', strtotime($user['created_at'])) ?></div>
            </div>
        </div>

        <!-- Mini stats -->
        <div class="card-a">
            <div class="card-a-header"><div class="card-a-title"><i class="fa fa-chart-pie"></i> Statistiques crédit</div></div>
            <div class="card-a-body">
                <?php foreach ([
                    ['Total demandes','total','fa-file-alt','var(--p)'],
                    ['En attente','pending','fa-clock','var(--warning)'],
                    ['Acceptées','accepted','fa-check-circle','var(--success)'],
                    ['Refusées','refused','fa-times-circle','var(--danger)'],
                ] as [$label,$key,$icon,$color]): ?>
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <div class="d-flex align-items-center gap-2">
                        <div style="width:28px;height:28px;border-radius:7px;background:<?= $color ?>18;color:<?= $color ?>;display:flex;align-items:center;justify-content:center;font-size:.75rem;">
                            <i class="fa <?= $icon ?>"></i>
                        </div>
                        <span style="font-size:.82rem;font-weight:600;"><?= $label ?></span>
                    </div>
                    <span class="fw7" style="color:<?= $color ?>;"><?= $stats[$key] ?></span>
                </div>
                <?php endforeach; ?>
                <div class="pt-3" style="border-top:1px solid var(--border);">
                    <div style="font-size:.78rem;color:var(--text-m);">Montant total accordé</div>
                    <div class="montant-xl"><?= number_format($stats['montant_total'],0,',',' ') ?> <span style="font-size:1rem;">DT</span></div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-8">
        <div class="card-a">
            <div class="card-a-header">
                <div class="card-a-title"><i class="fa fa-file-invoice-dollar"></i> Demandes de crédit</div>
                <a href="user_edit.php?id=<?= $uid ?>" class="btn btn-outline-primary btn-sm"><i class="fa fa-edit me-1"></i>Modifier</a>
            </div>
            <?php if (empty($credits)): ?>
            <div class="empty-state"><i class="fa fa-folder-open"></i><h5>Aucune demande</h5><p>Cet utilisateur n'a pas encore soumis de demande.</p></div>
            <?php else: ?>
            <div class="table-responsive">
                <table class="table-admin">
                    <thead>
                        <tr><th>Référence</th><th>Type</th><th>Montant</th><th>Échéance</th><th>Date</th><th>Statut</th><th></th></tr>
                    </thead>
                    <tbody>
                    <?php foreach ($credits as $c):
                        $bc = match($c['statut']) { 'Accepté'=>'bs-accepted','Refusé'=>'bs-refused',default=>'bs-pending' };
                        $bi = match($c['statut']) { 'Accepté'=>'fa-check-circle','Refusé'=>'fa-times-circle',default=>'fa-clock' };
                    ?>
                    <tr>
                        <td><span class="ref-badge"><?= adminSanitize($c['reference']) ?></span></td>
                        <td><span class="bs bs-type"><?= adminSanitize($c['type_credit']) ?></span></td>
                        <td class="fw7"><?= number_format($c['montant'],0,',',' ') ?> DT</td>
                        <td><?= $c['echeance'] ?> mois</td>
                        <td style="font-size:.8rem;"><?= date('d/m/Y', strtotime($c['date_depot'])) ?></td>
                        <td><span class="bs <?= $bc ?>"><i class="fa <?= $bi ?>"></i><?= $c['statut'] ?></span></td>
                        <td><a href="credit_view.php?id=<?= $c['id'] ?>" class="btn-act view"><i class="fa fa-eye"></i></a></td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

</div></div></div>
<?php require_once 'includes/footer.php'; ?>
