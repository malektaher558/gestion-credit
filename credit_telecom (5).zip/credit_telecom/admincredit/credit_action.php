<?php
require_once 'includes/admin_config.php';
requireAdminLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    adminRedirect(ADMIN_BASE_URL . '/credits.php');
}

$db        = getAdminDB();
$admin     = getCurrentAdmin();
$creditId  = intval($_POST['credit_id'] ?? 0);
$statut    = adminSanitize($_POST['statut'] ?? '');
$comment   = adminSanitize($_POST['admin_comment'] ?? '');
$redirect  = $_POST['redirect'] ?? ADMIN_BASE_URL . '/credits.php';

if (!in_array($statut, ['Accepté', 'Refusé'])) {
    adminFlash('error', 'Statut invalide.');
    adminRedirect($redirect);
}

// Get credit
$stmt = $db->prepare("SELECT c.*, u.nom, u.prenom, u.id as uid FROM credits c JOIN users u ON c.user_id=u.id WHERE c.id=?");
$stmt->execute([$creditId]);
$credit = $stmt->fetch();

if (!$credit) {
    adminFlash('error', 'Demande introuvable.');
    adminRedirect($redirect);
}

if ($credit['statut'] !== 'En attente') {
    adminFlash('error', 'Cette demande a déjà été traitée.');
    adminRedirect($redirect);
}

// Update credit
$db->prepare("UPDATE credits SET statut=?, admin_comment=?, processed_by=?, processed_at=NOW() WHERE id=?")
   ->execute([$statut, $comment ?: null, $admin['id'], $creditId]);

// Create notification for all admins
$type    = $statut === 'Accepté' ? 'accepted' : 'refused';
$title   = "Demande {$statut}e";
$message = "La demande {$credit['reference']} de {$credit['prenom']} {$credit['nom']} ({$credit['type_credit']}, {$credit['montant']} DT) a été {$statut}e par {$admin['prenom']} {$admin['nom']}.";
notifyAllAdmins($type, $title, $message, $creditId, $credit['uid']);

adminFlash('success', "Demande {$credit['reference']} {$statut}e avec succès !");
adminRedirect($redirect);
?>
