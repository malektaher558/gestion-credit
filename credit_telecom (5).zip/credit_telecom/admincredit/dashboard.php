<?php
require_once 'includes/admin_config.php';
requireAdminLogin();

$pageTitle  = 'Tableau de bord';
$breadcrumb = [];

$db    = getAdminDB();
$stats = getGlobalStats();

// Monthly credits for line chart (last 6 months)
$monthly = $db->query("
    SELECT DATE_FORMAT(created_at,'%b %Y') as month,
           COUNT(*) as total,
           SUM(CASE WHEN statut='Accepté' THEN 1 ELSE 0 END) as accepted,
           SUM(CASE WHEN statut='Refusé'  THEN 1 ELSE 0 END) as refused
    FROM credits
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
    GROUP BY DATE_FORMAT(created_at,'%Y-%m')
    ORDER BY MIN(created_at)
")->fetchAll();

// Credits by type
$byType = $db->query("SELECT type_credit, COUNT(*) as nb, SUM(montant) as total FROM credits GROUP BY type_credit")->fetchAll();

// Recent activity (last 8 credits)
$recent = $db->query("
    SELECT c.*, u.nom, u.prenom, u.matricule
    FROM credits c
    JOIN users u ON c.user_id = u.id
    ORDER BY c.created_at DESC
    LIMIT 8
")->fetchAll();

// Recent registrations
$newUsers = $db->query("SELECT * FROM users ORDER BY created_at DESC LIMIT 5")->fetchAll();

// Amounts by type
$amountByType = $db->query("
    SELECT type_credit,
           SUM(CASE WHEN statut='Accepté' THEN montant ELSE 0 END) as montant_ok,
           COUNT(CASE WHEN statut='Accepté' THEN 1 END) as nb_ok
    FROM credits GROUP BY type_credit
")->fetchAll();

require_once 'includes/header.php';
?>
<div class="d-flex">
<?php require_once 'includes/sidebar.php'; ?>
<?php require_once 'includes/topbar.php'; ?>

<!-- ══════════════ STATS GRID ══════════════ -->
<div class="stats-grid" id="statsGrid">

    <div class="stat-card c-primary stat-clickable" data-action="users" data-label="Utilisateurs inscrits" title="Cliquez pour voir les utilisateurs">
        <div class="stat-icon"><i class="fa fa-users"></i></div>
        <div>
            <div class="stat-value" data-count="<?= $stats['total_users'] ?>"><?= $stats['total_users'] ?></div>
            <div class="stat-label">Utilisateurs inscrits</div>
        </div>
        <div class="stat-click-hint"><i class="fa fa-mouse-pointer"></i></div>
    </div>

    <div class="stat-card c-info stat-clickable" data-action="credits" data-label="Toutes les demandes" title="Cliquez pour voir toutes les demandes">
        <div class="stat-icon"><i class="fa fa-file-alt"></i></div>
        <div>
            <div class="stat-value" data-count="<?= $stats['total_credits'] ?>"><?= $stats['total_credits'] ?></div>
            <div class="stat-label">Total demandes</div>
        </div>
        <div class="stat-click-hint"><i class="fa fa-mouse-pointer"></i></div>
    </div>

    <div class="stat-card c-warning stat-clickable" data-action="pending" data-label="Demandes en attente" title="Cliquez pour voir les demandes en attente">
        <div class="stat-icon"><i class="fa fa-clock"></i></div>
        <div>
            <div class="stat-value" data-count="<?= $stats['pending'] ?>"><?= $stats['pending'] ?></div>
            <div class="stat-label">En attente</div>
        </div>
        <div class="stat-click-hint"><i class="fa fa-mouse-pointer"></i></div>
    </div>

    <div class="stat-card c-success stat-clickable" data-action="accepted" data-label="Demandes acceptées" title="Cliquez pour voir les demandes acceptées">
        <div class="stat-icon"><i class="fa fa-check-circle"></i></div>
        <div>
            <div class="stat-value" data-count="<?= $stats['accepted'] ?>"><?= $stats['accepted'] ?></div>
            <div class="stat-label">Acceptées</div>
        </div>
        <div class="stat-click-hint"><i class="fa fa-mouse-pointer"></i></div>
    </div>

    <div class="stat-card c-danger stat-clickable" data-action="refused" data-label="Demandes refusées" title="Cliquez pour voir les demandes refusées">
        <div class="stat-icon"><i class="fa fa-times-circle"></i></div>
        <div>
            <div class="stat-value" data-count="<?= $stats['refused'] ?>"><?= $stats['refused'] ?></div>
            <div class="stat-label">Refusées</div>
        </div>
        <div class="stat-click-hint"><i class="fa fa-mouse-pointer"></i></div>
    </div>

    <div class="stat-card c-secondary stat-clickable" data-action="montant" data-label="Crédits accordés (DT)" title="Cliquez pour voir les montants accordés">
        <div class="stat-icon"><i class="fa fa-coins"></i></div>
        <div>
            <div class="stat-value"><?= number_format($stats['montant_accorde']/1000, 1, ',', '') ?>K</div>
            <div class="stat-label">DT accordés</div>
        </div>
        <div class="stat-click-hint"><i class="fa fa-mouse-pointer"></i></div>
    </div>

</div>

<!-- ══════════════ PANNEAU DONNÉES INTERACTIF ══════════════ -->
<div id="dataPanel" style="display:none;" class="mb-4">
    <div class="card-a">
        <div class="card-a-header" style="flex-wrap:wrap;gap:10px;">
            <div class="card-a-title" id="dataPanelTitle">
                <i class="fa fa-table"></i> <span id="dataPanelTitleText">Données</span>
            </div>
            <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-left:auto;">
                <!-- Search -->
                <div style="position:relative;">
                    <i class="fa fa-search" style="position:absolute;left:10px;top:50%;transform:translateY(-50%);color:var(--text-l);font-size:.8rem;"></i>
                    <input type="text" id="dataPanelSearch" placeholder="Rechercher…"
                        style="padding:6px 12px 6px 32px;border:1px solid var(--border);border-radius:8px;font-size:.82rem;width:200px;outline:none;transition:var(--tr);"
                        onfocus="this.style.borderColor='var(--p)'" onblur="this.style.borderColor='var(--border)'">
                </div>
                <!-- Refresh -->
                <button onclick="refreshPanel()" class="btn btn-outline-primary btn-sm" style="font-size:.8rem;">
                    <i class="fa fa-sync-alt" id="refreshIcon"></i> Actualiser
                </button>
                <!-- Back -->
                <button onclick="closePanel()" class="btn btn-outline-secondary btn-sm" style="font-size:.8rem;">
                    <i class="fa fa-arrow-left"></i> Vue globale
                </button>
            </div>
        </div>

        <!-- Spinner -->
        <div id="dataSpinner" style="display:none;text-align:center;padding:60px 20px;">
            <div class="spinner-border text-primary" role="status" style="width:2.5rem;height:2.5rem;">
                <span class="visually-hidden">Chargement…</span>
            </div>
            <div style="margin-top:14px;color:var(--text-m);font-size:.85rem;">Chargement des données…</div>
        </div>

        <!-- Content -->
        <div id="dataContent" style="overflow-x:auto;"></div>

        <!-- Pagination -->
        <div id="dataPagination" style="display:none;padding:14px 22px;border-top:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;">
            <div id="paginationInfo" style="font-size:.78rem;color:var(--text-m);"></div>
            <div id="paginationBtns" style="display:flex;gap:6px;flex-wrap:wrap;"></div>
        </div>
    </div>
</div>

<!-- ══════════════ CHARTS ══════════════ -->
<div id="chartsSection">

<!-- Row 1: Charts -->
<div class="row g-4 mb-4">
    <div class="col-lg-8">
        <div class="card-a h-100">
            <div class="card-a-header">
                <div class="card-a-title"><i class="fa fa-chart-line"></i> Évolution mensuelle des demandes</div>
            </div>
            <div class="card-a-body">
                <div class="chart-wrap" style="height:240px;"><canvas id="lineChart"></canvas></div>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card-a h-100">
            <div class="card-a-header">
                <div class="card-a-title"><i class="fa fa-chart-pie"></i> Répartition des statuts</div>
            </div>
            <div class="card-a-body">
                <div class="chart-wrap" style="height:240px;"><canvas id="statusChart"></canvas></div>
            </div>
        </div>
    </div>
</div>

<!-- Row 2 -->
<div class="row g-4 mb-4">
    <div class="col-lg-7">
        <div class="card-a h-100">
            <div class="card-a-header">
                <div class="card-a-title"><i class="fa fa-chart-bar"></i> Montants accordés par type (DT)</div>
            </div>
            <div class="card-a-body">
                <div class="chart-wrap" style="height:220px;"><canvas id="barChart"></canvas></div>
            </div>
        </div>
    </div>
    <div class="col-lg-5">
        <div class="card-a h-100">
            <div class="card-a-header">
                <div class="card-a-title"><i class="fa fa-chart-pie"></i> Demandes par type</div>
            </div>
            <div class="card-a-body">
                <div class="chart-wrap" style="height:220px;"><canvas id="typeChart"></canvas></div>
            </div>
        </div>
    </div>
</div>

<!-- Row 3: Recent activity + new users -->
<div class="row g-4">
    <div class="col-lg-8">
        <div class="card-a">
            <div class="card-a-header">
                <div class="card-a-title"><i class="fa fa-history"></i> Activité récente</div>
                <a href="<?= ADMIN_BASE_URL ?>/credits.php" class="btn btn-outline-primary btn-sm">Voir tout</a>
            </div>
            <?php if (empty($recent)): ?>
            <div class="empty-state"><i class="fa fa-inbox"></i><h5>Aucune activité</h5></div>
            <?php else: ?>
            <div style="padding:8px 0;">
                <?php foreach ($recent as $c):
                    $dot = match($c['statut']) {
                        'Accepté' => ['fa-check','#28A745','rgba(40,167,69,.1)'],
                        'Refusé'  => ['fa-times','#DC3545','rgba(220,53,69,.1)'],
                        default   => ['fa-clock','#FFC107','rgba(255,193,7,.12)']
                    };
                ?>
                <div class="activity-item" style="padding:12px 22px;">
                    <div class="activity-dot" style="background:<?= $dot[2] ?>;color:<?= $dot[1] ?>;">
                        <i class="fa <?= $dot[0] ?>"></i>
                    </div>
                    <div style="flex:1;">
                        <div class="activity-text">
                            <strong><?= adminSanitize($c['prenom'].' '.$c['nom']) ?></strong>
                            — Demande <span class="ref-badge"><?= adminSanitize($c['reference']) ?></span>
                            <span class="bs <?= match($c['statut']) { 'Accepté'=>'bs-accepted','Refusé'=>'bs-refused',default=>'bs-pending' } ?>" style="font-size:.68rem;padding:2px 8px;margin-left:4px;"><?= $c['statut'] ?></span>
                        </div>
                        <div class="activity-time">
                            <?= adminSanitize($c['type_credit']) ?> — <?= number_format($c['montant'],0,',',' ') ?> DT
                            &nbsp;·&nbsp; <?= date('d/m/Y H:i', strtotime($c['created_at'])) ?>
                        </div>
                    </div>
                    <a href="<?= ADMIN_BASE_URL ?>/credit_view.php?id=<?= $c['id'] ?>" class="btn-act view"><i class="fa fa-eye"></i></a>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="card-a">
            <div class="card-a-header">
                <div class="card-a-title"><i class="fa fa-user-plus"></i> Nouveaux utilisateurs</div>
                <a href="<?= ADMIN_BASE_URL ?>/users.php" class="btn btn-outline-primary btn-sm">Voir tout</a>
            </div>
            <div style="padding:8px 0;">
                <?php foreach ($newUsers as $u): ?>
                <div class="activity-item" style="padding:10px 20px;">
                    <div class="topbar-avatar" style="width:36px;height:36px;font-size:.75rem;background:var(--p);color:#fff;border-radius:50%;display:flex;align-items:center;justify-content:center;font-family:'Sora',sans-serif;font-weight:700;flex-shrink:0;">
                        <?= strtoupper(substr($u['prenom'],0,1).substr($u['nom'],0,1)) ?>
                    </div>
                    <div>
                        <div style="font-size:.83rem;font-weight:600;"><?= adminSanitize($u['prenom'].' '.$u['nom']) ?></div>
                        <div style="font-size:.72rem;color:var(--text-l);">Mat: <?= adminSanitize($u['matricule']) ?> · <?= date('d/m/Y', strtotime($u['created_at'])) ?></div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="card-a mt-4">
            <div class="card-a-header"><div class="card-a-title"><i class="fa fa-bolt"></i> Actions rapides</div></div>
            <div class="card-a-body d-grid gap-2">
                <a href="<?= ADMIN_BASE_URL ?>/credits.php?statut=En+attente" class="btn btn-warning btn-sm text-dark">
                    <i class="fa fa-clock me-2"></i>Demandes en attente (<?= $stats['pending'] ?>)
                </a>
                <a href="<?= ADMIN_BASE_URL ?>/users.php" class="btn btn-outline-primary btn-sm">
                    <i class="fa fa-users me-2"></i>Gérer les utilisateurs
                </a>
                <a href="<?= ADMIN_BASE_URL ?>/statistics.php" class="btn btn-outline-secondary btn-sm">
                    <i class="fa fa-chart-bar me-2"></i>Voir les statistiques
                </a>
            </div>
        </div>
    </div>
</div>

</div><!-- /chartsSection -->
</div></div></div>

<?php
$mLabels   = json_encode(array_column($monthly, 'month'));
$mTotal    = json_encode(array_column($monthly, 'total'));
$mAccepted = json_encode(array_column($monthly, 'accepted'));
$mRefused  = json_encode(array_column($monthly, 'refused'));
$typeLabels  = json_encode(array_column($byType, 'type_credit'));
$typeData    = json_encode(array_column($byType, 'nb'));
$barLabels   = json_encode(array_column($amountByType, 'type_credit'));
$barMontant  = json_encode(array_column($amountByType, 'montant_ok'));
$statusData  = json_encode([$stats['pending'], $stats['accepted'], $stats['refused']]);
$adminBaseUrl = ADMIN_BASE_URL;
?>

<?php $extraJS = '<script>
// ── Charts ──────────────────────────────────────
buildLine(\'lineChart\',
    ' . $mLabels . ',
    [
        { label:\'Total\',     data:' . $mTotal . ',    borderColor:\'#0057B8\', backgroundColor:\'rgba(0,87,184,.08)\',   fill:true },
        { label:\'Acceptées\', data:' . $mAccepted . ', borderColor:\'#28A745\', backgroundColor:\'rgba(40,167,69,.06)\',  fill:true },
        { label:\'Refusées\',  data:' . $mRefused . ',  borderColor:\'#DC3545\', backgroundColor:\'rgba(220,53,69,.06)\',  fill:true }
    ]
);
buildDoughnut(\'statusChart\', [\'En attente\',\'Acceptées\',\'Refusées\'], ' . $statusData . ', [\'#FFC107\',\'#28A745\',\'#DC3545\']);
buildBar(\'barChart\', ' . $barLabels . ',
    [{ label:\'Montant accordé (DT)\', data:' . $barMontant . ', backgroundColor:[\'rgba(0,87,184,.8)\',\'rgba(0,174,239,.8)\',\'rgba(40,167,69,.8)\'], borderRadius:6 }],
    { suffix:\' DT\' }
);
buildDoughnut(\'typeChart\', ' . $typeLabels . ', ' . $typeData . ', [\'#0057B8\',\'#00AEEF\',\'#28A745\']);

</script>';

require_once 'includes/footer.php';
?>
<!-- ── Dashboard interactif JS (hors PHP heredoc) ── -->
<script>
(function() {
const AJAX_URL = '<?= ADMIN_BASE_URL ?>/ajax/dashboard_data.php';
const VIEW_URL = '<?= ADMIN_BASE_URL ?>/credit_view.php';
const USER_URL = '<?= ADMIN_BASE_URL ?>/user_view.php';

let currentAction = null;
let currentPage   = 1;
let searchTimer   = null;

// Cartes cliquables
document.querySelectorAll('.stat-clickable').forEach(function(card) {
    card.addEventListener('click', function() {
        var action = this.dataset.action;
        var label  = this.dataset.label;
        openPanel(action, label, 1);
        document.querySelectorAll('.stat-clickable').forEach(function(c){ c.classList.remove('stat-active'); });
        this.classList.add('stat-active');
    });
});

// Recherche instantanée
document.getElementById('dataPanelSearch').addEventListener('input', function() {
    clearTimeout(searchTimer);
    var val = this.value.trim();
    searchTimer = setTimeout(function(){ currentPage = 1; fetchData(currentAction, currentPage, val); }, 350);
});

function openPanel(action, label, page) {
    currentAction = action;
    currentPage   = page;
    document.getElementById('dataPanelTitleText').textContent = label;
    document.getElementById('dataPanelSearch').value = '';
    document.getElementById('dataPanel').style.display = 'block';
    document.getElementById('dataPanel').scrollIntoView({ behavior:'smooth', block:'start' });
    fetchData(action, page, '');
}

window.refreshPanel = function() {
    var icon = document.getElementById('refreshIcon');
    icon.classList.add('fa-spin');
    setTimeout(function(){ icon.classList.remove('fa-spin'); }, 600);
    fetchData(currentAction, currentPage, document.getElementById('dataPanelSearch').value.trim());
};

window.closePanel = function() {
    document.getElementById('dataPanel').style.display = 'none';
    document.querySelectorAll('.stat-clickable').forEach(function(c){ c.classList.remove('stat-active'); });
    currentAction = null;
    currentPage   = 1;
    document.getElementById('dataContent').innerHTML = '';
    document.getElementById('dataPagination').style.display = 'none';
    document.getElementById('statsGrid').scrollIntoView({ behavior:'smooth', block:'start' });
};

function fetchData(action, page, search) {
    document.getElementById('dataSpinner').style.display = 'block';
    document.getElementById('dataContent').innerHTML = '';
    document.getElementById('dataPagination').style.display = 'none';

    var url = AJAX_URL + '?action=' + action + '&page=' + page + '&q=' + encodeURIComponent(search);

    fetch(url)
        .then(function(r){ return r.json(); })
        .then(function(json) {
            document.getElementById('dataSpinner').style.display = 'none';
            if (!json.success) {
                document.getElementById('dataContent').innerHTML = '<div style="padding:40px;text-align:center;color:var(--danger);"><i class="fa fa-exclamation-triangle fa-2x mb-3"></i><br>' + (json.message || 'Erreur') + '</div>';
                return;
            }
            if (action === 'users') renderUsers(json);
            else if (action === 'montant') renderMontant(json);
            else renderCredits(json);
        })
        .catch(function() {
            document.getElementById('dataSpinner').style.display = 'none';
            document.getElementById('dataContent').innerHTML = '<div style="padding:40px;text-align:center;color:var(--danger);"><i class="fa fa-wifi fa-2x mb-3"></i><br>Erreur de connexion</div>';
        });
}

function renderUsers(json) {
    if (!json.data.length) { renderEmpty('Aucun utilisateur trouvé'); return; }
    var html = '<table class="table-admin"><thead><tr>'
        + '<th>#</th><th>Matricule</th><th>Nom &amp; Prénom</th><th>Email</th>'
        + '<th style="text-align:center;">Demandes</th><th style="text-align:center;">Rôle</th>'
        + '<th>Inscription</th><th style="text-align:center;">Action</th>'
        + '</tr></thead><tbody>';
    json.data.forEach(function(u) {
        var roleHtml = u.role === 'admin'
            ? '<span style="background:rgba(0,87,184,.1);color:var(--p);font-size:.7rem;padding:3px 9px;border-radius:20px;font-weight:600;">Admin</span>'
            : '<span style="background:rgba(107,114,128,.1);color:var(--text-m);font-size:.7rem;padding:3px 9px;border-radius:20px;font-weight:600;">User</span>';
        html += '<tr>'
            + '<td style="color:var(--text-l);font-size:.78rem;">' + u.id + '</td>'
            + '<td><span style="font-family:Sora,sans-serif;font-weight:700;font-size:.8rem;background:rgba(0,87,184,.08);color:var(--p);padding:3px 9px;border-radius:6px;">' + u.matricule + '</span></td>'
            + '<td><div style="font-weight:600;font-size:.87rem;">' + u.prenom + ' ' + u.nom + '</div><div style="font-size:.72rem;color:var(--text-l);">' + u.email + '</div></td>'
            + '<td style="font-size:.82rem;">' + u.email + '</td>'
            + '<td style="text-align:center;font-weight:700;color:var(--p);">' + u.nb_credits + '</td>'
            + '<td style="text-align:center;">' + roleHtml + '</td>'
            + '<td style="font-size:.8rem;color:var(--text-m);">' + u.created_at + '</td>'
            + '<td style="text-align:center;"><a href="' + USER_URL + '?id=' + u.id + '" class="btn-act view" title="Voir"><i class="fa fa-eye"></i></a></td>'
            + '</tr>';
    });
    html += '</tbody></table>';
    document.getElementById('dataContent').innerHTML = html;
    renderPagination(json);
}

function renderCredits(json) {
    if (!json.data.length) { renderEmpty('Aucune demande trouvée'); return; }
    var statutClass = { 'En attente':'bs-pending', 'Accepté':'bs-accepted', 'Refusé':'bs-refused' };
    var html = '<table class="table-admin"><thead><tr>'
        + '<th>Référence</th><th>Client</th><th>Type</th>'
        + '<th style="text-align:right;">Montant</th><th style="text-align:center;">Échéance</th>'
        + '<th style="text-align:center;">Statut</th><th>Date dépôt</th><th style="text-align:center;">Action</th>'
        + '</tr></thead><tbody>';
    json.data.forEach(function(c) {
        var cls = statutClass[c.statut] || 'bs-pending';
        html += '<tr>'
            + '<td><span class="ref-badge" style="font-size:.75rem;">' + c.reference + '</span></td>'
            + '<td><div style="font-weight:600;font-size:.87rem;">' + c.prenom + ' ' + c.nom + '</div><div style="font-size:.72rem;color:var(--text-l);">Mat: ' + c.matricule + '</div></td>'
            + '<td style="font-size:.82rem;">' + c.type_credit + '</td>'
            + '<td style="text-align:right;font-family:Sora,sans-serif;font-weight:700;color:var(--p);">' + c.montant + ' DT</td>'
            + '<td style="text-align:center;font-size:.82rem;">' + c.echeance + ' mois</td>'
            + '<td style="text-align:center;"><span class="bs ' + cls + '">' + c.statut + '</span></td>'
            + '<td style="font-size:.8rem;color:var(--text-m);">' + c.date_depot + '</td>'
            + '<td style="text-align:center;"><a href="' + VIEW_URL + '?id=' + c.id + '" class="btn-act view" title="Voir"><i class="fa fa-eye"></i></a></td>'
            + '</tr>';
    });
    html += '</tbody></table>';
    document.getElementById('dataContent').innerHTML = html;
    renderPagination(json);
}

function renderMontant(json) {
    if (!json.data.length) { renderEmpty('Aucun crédit accordé'); return; }
    var html = '<div style="padding:14px 22px 0;display:flex;align-items:center;gap:10px;">'
        + '<div style="background:rgba(40,167,69,.1);color:var(--success);padding:8px 18px;border-radius:10px;font-family:Sora,sans-serif;font-weight:800;font-size:1.1rem;">'
        + '<i class="fa fa-coins me-2"></i>Total accordé : ' + json.total_montant + ' DT</div>'
        + '<div style="font-size:.78rem;color:var(--text-m);">(' + json.total + ' crédits)</div></div>'
        + '<table class="table-admin" style="margin-top:10px;"><thead><tr>'
        + '<th>Référence</th><th>Client</th><th>Type</th>'
        + '<th style="text-align:right;">Montant accordé</th><th style="text-align:center;">Durée</th>'
        + '<th>Date dépôt</th><th>Date approbation</th><th style="text-align:center;">Action</th>'
        + '</tr></thead><tbody>';
    json.data.forEach(function(c) {
        html += '<tr>'
            + '<td><span class="ref-badge" style="font-size:.75rem;">' + c.reference + '</span></td>'
            + '<td><div style="font-weight:600;font-size:.87rem;">' + c.prenom + ' ' + c.nom + '</div><div style="font-size:.72rem;color:var(--text-l);">Mat: ' + c.matricule + '</div></td>'
            + '<td style="font-size:.82rem;">' + c.type_credit + '</td>'
            + '<td style="text-align:right;font-family:Sora,sans-serif;font-weight:700;color:var(--success);">' + c.montant + ' DT</td>'
            + '<td style="text-align:center;font-size:.82rem;">' + c.echeance + ' mois</td>'
            + '<td style="font-size:.8rem;color:var(--text-m);">' + c.date_depot + '</td>'
            + '<td style="font-size:.8rem;color:var(--text-m);">' + c.processed_at + '</td>'
            + '<td style="text-align:center;"><a href="' + VIEW_URL + '?id=' + c.id + '" class="btn-act view" title="Voir"><i class="fa fa-eye"></i></a></td>'
            + '</tr>';
    });
    html += '</tbody></table>';
    document.getElementById('dataContent').innerHTML = html;
    renderPagination(json);
}

function renderEmpty(msg) {
    document.getElementById('dataContent').innerHTML = '<div style="padding:60px 20px;text-align:center;color:var(--text-l);"><i class="fa fa-inbox fa-3x mb-3" style="color:var(--border);"></i><div style="font-size:.9rem;">' + msg + '</div></div>';
    document.getElementById('dataPagination').style.display = 'none';
}

function renderPagination(json) {
    var total = json.total, pages = json.pages, page = json.page, per = 10;
    var from = (page - 1) * per + 1;
    var to   = Math.min(page * per, total);
    document.getElementById('paginationInfo').textContent = total > 0 ? ('Affichage ' + from + '–' + to + ' sur ' + total + ' résultat(s)') : '0 résultat';
    var btns = '';
    if (pages > 1) {
        btns += '<button onclick="goPage(' + (page-1) + ')" ' + (page<=1?'disabled':'') + ' style="padding:5px 12px;border:1px solid var(--border);border-radius:7px;background:' + (page<=1?'var(--accent)':'var(--white)') + ';cursor:' + (page<=1?'default':'pointer') + ';font-size:.8rem;color:var(--text-m);"><i class="fa fa-chevron-left"></i></button>';
        for (var p = 1; p <= pages; p++) {
            var active = p === page;
            btns += '<button onclick="goPage(' + p + ')" style="padding:5px 12px;border:1px solid ' + (active?'var(--p)':'var(--border)') + ';border-radius:7px;background:' + (active?'var(--p)':'var(--white)') + ';color:' + (active?'#fff':'var(--text-m)') + ';cursor:pointer;font-size:.8rem;font-weight:' + (active?700:400) + ';">' + p + '</button>';
        }
        btns += '<button onclick="goPage(' + (page+1) + ')" ' + (page>=pages?'disabled':'') + ' style="padding:5px 12px;border:1px solid var(--border);border-radius:7px;background:' + (page>=pages?'var(--accent)':'var(--white)') + ';cursor:' + (page>=pages?'default':'pointer') + ';font-size:.8rem;color:var(--text-m);"><i class="fa fa-chevron-right"></i></button>';
    }
    document.getElementById('paginationBtns').innerHTML = btns;
    document.getElementById('dataPagination').style.display = 'flex';
}

window.goPage = function(p) {
    currentPage = p;
    fetchData(currentAction, currentPage, document.getElementById('dataPanelSearch').value.trim());
    document.getElementById('dataPanel').scrollIntoView({ behavior:'smooth', block:'start' });
};

})();
</script>
