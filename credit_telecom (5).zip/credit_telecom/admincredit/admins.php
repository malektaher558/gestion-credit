<?php
require_once 'includes/admin_config.php';
requireAdminLogin();

// Réservé aux superadmins uniquement
if (!isSuperAdmin()) {
    adminFlash('danger', 'Accès réservé au Super Administrateur.');
    adminRedirect(ADMIN_BASE_URL . '/dashboard.php');
}

$pageTitle  = 'Gestion des administrateurs';
$breadcrumb = [['label' => 'Admins', 'active' => true]];

$db = getAdminDB();

// ── Supprimer un admin ───────────────────────────────────────
if (isset($_GET['delete'])) {
    $aid = intval($_GET['delete']);
    $current = getCurrentAdmin();
    if ($aid === (int)$current['id']) {
        adminFlash('danger', 'Vous ne pouvez pas supprimer votre propre compte.');
    } else {
        $db->prepare("DELETE FROM admins WHERE id = ?")->execute([$aid]);
        adminFlash('success', 'Administrateur supprimé avec succès.');
    }
    adminRedirect(ADMIN_BASE_URL . '/admins.php');
}

// ── Activer / Désactiver ─────────────────────────────────────
if (isset($_GET['toggle'])) {
    $aid  = intval($_GET['toggle']);
    $curr = $db->prepare("SELECT is_active FROM admins WHERE id = ?");
    $curr->execute([$aid]);
    $row  = $curr->fetch();
    if ($row) {
        $newVal = $row['is_active'] ? 0 : 1;
        $db->prepare("UPDATE admins SET is_active = ? WHERE id = ?")->execute([$newVal, $aid]);
        adminFlash('success', $newVal ? 'Compte activé.' : 'Compte désactivé.');
    }
    adminRedirect(ADMIN_BASE_URL . '/admins.php');
}

// ── Ajouter un admin (POST) ──────────────────────────────────
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_admin'])) {
    $nom     = adminSanitize($_POST['nom']    ?? '');
    $prenom  = adminSanitize($_POST['prenom'] ?? '');
    $email   = adminSanitize($_POST['email']  ?? '');
    $role    = in_array($_POST['role'] ?? '', ['admin','superadmin']) ? $_POST['role'] : 'admin';
    $pass    = $_POST['password'] ?? '';
    $pass2   = $_POST['password2'] ?? '';

    if (!$nom)   $errors[] = 'Le nom est obligatoire.';
    if (!$prenom) $errors[] = 'Le prénom est obligatoire.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Email invalide.';
    if (strlen($pass) < 6) $errors[] = 'Le mot de passe doit contenir au moins 6 caractères.';
    if ($pass !== $pass2)  $errors[] = 'Les mots de passe ne correspondent pas.';

    // Vérifier unicité email
    $check = $db->prepare("SELECT id FROM admins WHERE email = ?");
    $check->execute([$email]);
    if ($check->fetch()) $errors[] = 'Cet email est déjà utilisé.';

    if (empty($errors)) {
        $hash = password_hash($pass, PASSWORD_BCRYPT);
        $db->prepare("INSERT INTO admins (nom, prenom, email, password, role) VALUES (?,?,?,?,?)")
           ->execute([$nom, $prenom, $email, $hash, $role]);
        adminFlash('success', 'Administrateur ' . $prenom . ' ' . $nom . ' ajouté avec succès.');
        adminRedirect(ADMIN_BASE_URL . '/admins.php');
    }
}

// ── Liste des admins ─────────────────────────────────────────
$search = adminSanitize($_GET['q'] ?? '');
$page   = max(1, intval($_GET['page'] ?? 1));
$per    = ITEMS_PER_PAGE;

$where  = 'WHERE 1=1';
$params = [];
if ($search) {
    $where   .= ' AND (a.nom LIKE ? OR a.prenom LIKE ? OR a.email LIKE ?)';
    $params   = array_fill(0, 3, "%$search%");
}

$total = $db->prepare("SELECT COUNT(*) FROM admins a $where");
$total->execute($params);
$total  = (int)$total->fetchColumn();
$pages  = max(1, ceil($total / $per));
$offset = ($page - 1) * $per;

$stmt = $db->prepare("
    SELECT a.*
    FROM admins a
    $where
    ORDER BY a.role DESC, a.created_at ASC
    LIMIT $per OFFSET $offset
");
$stmt->execute($params);
$admins = $stmt->fetchAll();

$currentAdmin = getCurrentAdmin();

require_once 'includes/header.php';
?>
<div class="d-flex">
<?php require_once 'includes/sidebar.php'; ?>
<?php require_once 'includes/topbar.php'; ?>

<!-- ══ LISTE DES ADMINS ══════════════════════════════════════ -->
<div class="card-a mb-4">
    <div class="card-a-header" style="flex-wrap:wrap;gap:10px;">
        <div class="card-a-title"><i class="fa fa-user-shield"></i> Administrateurs du système</div>
        <div style="display:flex;gap:10px;align-items:center;margin-left:auto;flex-wrap:wrap;">
            <form method="GET" class="d-flex gap-2">
                <div class="input-wrap" style="min-width:220px;">
                    <i class="fi fa fa-search"></i>
                    <input type="text" name="q" class="form-control" placeholder="Rechercher un admin..."
                           value="<?= adminSanitize($search) ?>">
                </div>
                <button type="submit" class="btn btn-primary btn-sm"><i class="fa fa-search"></i></button>
                <?php if ($search): ?>
                <a href="admins.php" class="btn btn-outline-secondary btn-sm"><i class="fa fa-times"></i></a>
                <?php endif; ?>
            </form>
            <button class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#addAdminModal">
                <i class="fa fa-plus me-1"></i> Ajouter un admin
            </button>
        </div>
    </div>

    <?php if (empty($admins)): ?>
    <div class="empty-state"><i class="fa fa-user-shield"></i><h5>Aucun administrateur trouvé</h5></div>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table-admin">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Administrateur</th>
                    <th>Email</th>
                    <th style="text-align:center;">Rôle</th>
                    <th style="text-align:center;">Statut</th>
                    <th>Dernière connexion</th>
                    <th>Créé le</th>
                    <th style="text-align:center;">Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($admins as $i => $a): ?>
            <tr>
                <td style="color:var(--text-l);font-size:.78rem;"><?= $offset + $i + 1 ?></td>
                <td>
                    <div class="d-flex align-items-center" style="gap:10px;">
                        <div style="width:36px;height:36px;font-size:.75rem;border-radius:50%;display:flex;align-items:center;justify-content:center;font-family:'Sora',sans-serif;font-weight:700;flex-shrink:0;
                            background:<?= $a['role']==='superadmin' ? 'linear-gradient(135deg,#f59e0b,#d97706)' : 'var(--p)' ?>;color:#fff;">
                            <?= strtoupper(substr($a['prenom'],0,1) . substr($a['nom'],0,1)) ?>
                        </div>
                        <div>
                            <div style="font-weight:600;font-size:.87rem;">
                                <?= adminSanitize($a['prenom'] . ' ' . $a['nom']) ?>
                                <?php if ((int)$a['id'] === (int)$currentAdmin['id']): ?>
                                <span style="font-size:.65rem;background:rgba(0,87,184,.1);color:var(--p);padding:2px 7px;border-radius:10px;margin-left:5px;">Vous</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </td>
                <td style="font-size:.82rem;"><?= adminSanitize($a['email']) ?></td>
                <td style="text-align:center;">
                    <?php if ($a['role'] === 'superadmin'): ?>
                    <span style="background:linear-gradient(135deg,#f59e0b,#d97706);color:#fff;font-size:.7rem;padding:3px 10px;border-radius:20px;font-weight:700;">
                        ⭐ Super Admin
                    </span>
                    <?php else: ?>
                    <span style="background:rgba(0,87,184,.1);color:var(--p);font-size:.7rem;padding:3px 10px;border-radius:20px;font-weight:600;">
                        🔑 Admin
                    </span>
                    <?php endif; ?>
                </td>
                <td style="text-align:center;">
                    <?php if ($a['is_active']): ?>
                    <span style="background:rgba(40,167,69,.1);color:var(--success);font-size:.7rem;padding:3px 10px;border-radius:20px;font-weight:600;">
                        <i class="fa fa-circle" style="font-size:.5rem;"></i> Actif
                    </span>
                    <?php else: ?>
                    <span style="background:rgba(220,53,69,.1);color:var(--danger);font-size:.7rem;padding:3px 10px;border-radius:20px;font-weight:600;">
                        <i class="fa fa-circle" style="font-size:.5rem;"></i> Inactif
                    </span>
                    <?php endif; ?>
                </td>
                <td style="font-size:.8rem;color:var(--text-m);">
                    <?= $a['last_login'] ? date('d/m/Y H:i', strtotime($a['last_login'])) : '<span style="color:var(--text-l);">Jamais</span>' ?>
                </td>
                <td style="font-size:.8rem;color:var(--text-m);"><?= date('d/m/Y', strtotime($a['created_at'])) ?></td>
                <td>
                    <div class="d-flex justify-content-center gap-1">
                        <?php if ((int)$a['id'] !== (int)$currentAdmin['id']): ?>
                        <!-- Activer/Désactiver -->
                        <a href="admins.php?toggle=<?= $a['id'] ?>"
                           class="btn-act <?= $a['is_active'] ? 'edit' : 'view' ?>"
                           title="<?= $a['is_active'] ? 'Désactiver' : 'Activer' ?>"
                           onclick="return confirm('<?= $a['is_active'] ? 'Désactiver' : 'Activer' ?> ce compte ?')">
                            <i class="fa <?= $a['is_active'] ? 'fa-ban' : 'fa-check' ?>"></i>
                        </a>
                        <!-- Supprimer -->
                        <a href="admins.php?delete=<?= $a['id'] ?>"
                           class="btn-act del" title="Supprimer"
                           onclick="return confirm('Supprimer définitivement cet administrateur ?')">
                            <i class="fa fa-trash"></i>
                        </a>
                        <?php else: ?>
                        <span style="font-size:.72rem;color:var(--text-l);padding:4px 8px;">Votre compte</span>
                        <?php endif; ?>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <div class="d-flex align-items-center justify-content-between px-4 py-3" style="border-top:1px solid var(--border);">
        <div style="font-size:.78rem;color:var(--text-m);">
            <?= $total ?> administrateur(s) au total
        </div>
        <?php if ($pages > 1): ?>
        <nav><ul class="pagination mb-0 pagination-sm">
            <?php for ($p = 1; $p <= $pages; $p++): ?>
            <li class="page-item <?= $p === $page ? 'active' : '' ?>">
                <a class="page-link" href="?page=<?= $p ?>&q=<?= urlencode($search) ?>"><?= $p ?></a>
            </li>
            <?php endfor; ?>
        </ul></nav>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>

</div></div></div>

<!-- ══ MODAL : Ajouter un admin ══════════════════════════════ -->
<div class="modal fade" id="addAdminModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content" style="border-radius:var(--radius-lg);border:none;box-shadow:var(--shadow-lg);">
            <div class="modal-header" style="border-bottom:1px solid var(--border);padding:20px 24px;">
                <h5 class="modal-title" style="font-family:'Sora',sans-serif;font-weight:700;font-size:.95rem;">
                    <i class="fa fa-user-plus me-2 text-success"></i>Ajouter un administrateur
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body" style="padding:24px;">

                    <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger py-2" style="font-size:.82rem;border-radius:8px;">
                        <?php foreach ($errors as $e): ?>
                        <div><i class="fa fa-exclamation-circle me-1"></i><?= $e ?></div>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>

                    <div class="row g-3">
                        <div class="col-6">
                            <label class="form-label" style="font-size:.82rem;font-weight:600;">Nom</label>
                            <input type="text" name="nom" class="form-control form-control-sm"
                                   value="<?= adminSanitize($_POST['nom'] ?? '') ?>" required>
                        </div>
                        <div class="col-6">
                            <label class="form-label" style="font-size:.82rem;font-weight:600;">Prénom</label>
                            <input type="text" name="prenom" class="form-control form-control-sm"
                                   value="<?= adminSanitize($_POST['prenom'] ?? '') ?>" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label" style="font-size:.82rem;font-weight:600;">Email</label>
                            <input type="email" name="email" class="form-control form-control-sm"
                                   value="<?= adminSanitize($_POST['email'] ?? '') ?>" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label" style="font-size:.82rem;font-weight:600;">Rôle</label>
                            <select name="role" class="form-select form-select-sm">
                                <option value="admin" <?= ($_POST['role'] ?? '') === 'admin' ? 'selected' : '' ?>>🔑 Admin</option>
                                <option value="superadmin" <?= ($_POST['role'] ?? '') === 'superadmin' ? 'selected' : '' ?>>⭐ Super Admin</option>
                            </select>
                        </div>
                        <div class="col-6">
                            <label class="form-label" style="font-size:.82rem;font-weight:600;">Mot de passe</label>
                            <input type="password" name="password" class="form-control form-control-sm"
                                   placeholder="Min. 6 caractères" required>
                        </div>
                        <div class="col-6">
                            <label class="form-label" style="font-size:.82rem;font-weight:600;">Confirmer</label>
                            <input type="password" name="password2" class="form-control form-control-sm"
                                   placeholder="Répéter le mot de passe" required>
                        </div>
                    </div>
                </div>
                <div class="modal-footer" style="border-top:1px solid var(--border);padding:16px 24px;">
                    <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">Annuler</button>
                    <button type="submit" name="add_admin" class="btn btn-success btn-sm">
                        <i class="fa fa-plus me-1"></i> Ajouter
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
// Rouvrir modal si erreurs
$extraJS = '';
if (!empty($errors)) {
    $extraJS = '<script>document.addEventListener("DOMContentLoaded",function(){ new bootstrap.Modal(document.getElementById("addAdminModal")).show(); });</script>';
}
require_once 'includes/footer.php';
?>
