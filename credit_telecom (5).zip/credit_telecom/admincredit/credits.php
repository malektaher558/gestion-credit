<?php
require_once 'includes/admin_config.php';
requireAdminLogin();

$pageTitle  = 'Gestion des demandes de crédit';
$breadcrumb = [['label'=>'Demandes de crédit','active'=>true]];

$db = getAdminDB();

$search       = adminSanitize($_GET['q'] ?? '');
$filterStatut = $_GET['statut'] ?? '';
$filterType   = $_GET['type'] ?? '';
$page         = max(1, intval($_GET['page'] ?? 1));
$per          = ITEMS_PER_PAGE;

$where  = "WHERE 1=1";
$params = [];
if ($filterStatut) { $where .= " AND c.statut=?";      $params[] = $filterStatut; }
if ($filterType)   { $where .= " AND c.type_credit=?"; $params[] = $filterType; }
if ($search)       { $where .= " AND (c.reference LIKE ? OR u.nom LIKE ? OR u.prenom LIKE ? OR u.matricule LIKE ?)"; foreach(range(0,3) as $x) $params[] = "%$search%"; }

$cStmt = $db->prepare("SELECT COUNT(*) FROM credits c JOIN users u ON c.user_id=u.id $where");
$cStmt->execute($params);
$total  = $cStmt->fetchColumn();
$pages  = max(1, ceil($total/$per));
$offset = ($page-1)*$per;

$stmt = $db->prepare("
    SELECT c.*, u.nom, u.prenom, u.matricule, u.email
    FROM credits c JOIN users u ON c.user_id=u.id
    $where
    ORDER BY c.created_at DESC
    LIMIT $per OFFSET $offset
");
$stmt->execute($params);
$credits = $stmt->fetchAll();

require_once 'includes/header.php';
?>
<div class="d-flex">
<?php require_once 'includes/sidebar.php'; ?>
<?php require_once 'includes/topbar.php'; ?>

<!-- Quick filter tabs -->
<div class="d-flex gap-2 mb-4 flex-wrap">
    <?php
    $tabs = [
        ['','Toutes les demandes','fa-list'],
        ['En attente','En attente','fa-clock'],
        ['Accepté','Acceptées','fa-check-circle'],
        ['Refusé','Refusées','fa-times-circle'],
    ];
    foreach ($tabs as [$val,$label,$icon]):
        $count = $val ? $db->query("SELECT COUNT(*) FROM credits WHERE statut='$val'")->fetchColumn() : $total;
        $active = $filterStatut === $val;
    ?>
    <a href="credits.php?statut=<?= urlencode($val) ?>" class="btn btn-sm <?= $active ? 'btn-primary' : 'btn-outline-secondary' ?>">
        <i class="fa <?= $icon ?> me-1"></i><?= $label ?> <span class="ms-1" style="opacity:.7;">(<?= $count ?>)</span>
    </a>
    <?php endforeach; ?>
</div>

<div class="card-a">
    <div class="filter-bar">
        <form method="GET" class="d-flex gap-2 flex-wrap align-items-center w-100">
            <input type="hidden" name="statut" value="<?= adminSanitize($filterStatut) ?>">
            <div class="input-wrap flex-grow-1" style="max-width:260px;">
                <i class="fi fa fa-search"></i>
                <input type="text" name="q" id="searchInput" class="form-control"
                       placeholder="Référence, nom, matricule..."
                       value="<?= adminSanitize($search) ?>">
            </div>
            <select name="type" class="form-select">
                <option value="">Tous les types</option>
                <?php foreach(['Solfa','Personnel','Consommation'] as $t): ?>
                <option value="<?= $t ?>" <?= $filterType===$t?'selected':'' ?>><?= $t ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="btn btn-primary btn-sm"><i class="fa fa-filter me-1"></i>Filtrer</button>
            <?php if ($search||$filterType): ?><a href="credits.php?statut=<?= urlencode($filterStatut) ?>" class="btn btn-outline-secondary btn-sm"><i class="fa fa-times me-1"></i>Reset</a><?php endif; ?>
            <span style="margin-left:auto;font-size:.78rem;color:var(--text-m);"><?= $total ?> demande(s)</span>
        </form>
    </div>

    <?php if (empty($credits)): ?>
    <div class="empty-state"><i class="fa fa-inbox"></i><h5>Aucune demande trouvée</h5><p>Modifiez vos critères de recherche.</p></div>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table-admin">
            <thead>
                <tr>
                    <th>Référence</th><th>Employé</th><th>Type</th><th>Montant</th>
                    <th>Échéance</th><th>Date</th><th>Statut</th><th class="text-center">Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($credits as $c):
                $bc = match($c['statut']) { 'Accepté'=>'bs-accepted','Refusé'=>'bs-refused',default=>'bs-pending' };
                $bi = match($c['statut']) { 'Accepté'=>'fa-check-circle','Refusé'=>'fa-times-circle',default=>'fa-clock' };
            ?>
            <tr data-href="<?= ADMIN_BASE_URL ?>/credit_view.php?id=<?= $c['id'] ?>">
                <td><span class="ref-badge"><?= adminSanitize($c['reference']) ?></span></td>
                <td>
                    <div class="fw7" style="font-size:.84rem;"><?= adminSanitize($c['prenom'].' '.$c['nom']) ?></div>
                    <div style="font-size:.73rem;color:var(--text-l);">Mat: <?= adminSanitize($c['matricule']) ?></div>
                </td>
                <td><span class="bs bs-type"><?= adminSanitize($c['type_credit']) ?></span></td>
                <td class="fw7"><?= number_format($c['montant'],0,',',' ') ?> DT</td>
                <td><?= $c['echeance'] ?> mois</td>
                <td style="font-size:.8rem;"><?= date('d/m/Y', strtotime($c['date_depot'])) ?></td>
                <td><span class="bs <?= $bc ?>"><i class="fa <?= $bi ?>"></i> <?= $c['statut'] ?></span></td>
                <td>
                    <div class="d-flex justify-content-center gap-1">
                        <a href="credit_view.php?id=<?= $c['id'] ?>" class="btn-act view" title="Consulter"><i class="fa fa-eye"></i></a>
                        <?php if ($c['statut'] === 'En attente'): ?>
                        <button class="btn-act ok" title="Accepter"
                                onclick='openDecisionModal(<?= $c['id'] ?>, "Accepté", "<?= adminSanitize($c['reference']) ?>")'>
                            <i class="fa fa-check"></i>
                        </button>
                        <button class="btn-act refuse" title="Refuser"
                                onclick='openDecisionModal(<?= $c['id'] ?>, "Refusé", "<?= adminSanitize($c['reference']) ?>")'>
                            <i class="fa fa-times"></i>
                        </button>
                        <?php endif; ?>
                        <?php if (isSuperAdmin()): ?>
                        <a href="credits.php?delete=<?= $c['id'] ?>&statut=<?= urlencode($filterStatut) ?>" class="btn-act del" title="Supprimer" data-confirm="Supprimer cette demande définitivement ?"><i class="fa fa-trash"></i></a>
                        <?php endif; ?>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="d-flex align-items-center justify-content-between px-4 py-3" style="border-top:1px solid var(--border);">
        <div style="font-size:.78rem;color:var(--text-m);">Affichage de <?= $offset+1 ?> à <?= min($offset+$per,$total) ?> sur <?= $total ?></div>
        <?php if ($pages > 1): ?>
        <nav><ul class="pagination mb-0 pagination-sm">
            <?php for ($p=1;$p<=$pages;$p++): ?>
            <li class="page-item <?= $p===$page?'active':'' ?>">
                <a class="page-link" href="?page=<?= $p ?>&statut=<?= urlencode($filterStatut) ?>&type=<?= urlencode($filterType) ?>&q=<?= urlencode($search) ?>"><?= $p ?></a>
            </li>
            <?php endfor; ?>
        </ul></nav>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>

<!-- Decision Modal -->
<div class="modal fade" id="decisionModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalTitle"><i class="fa fa-gavel me-2"></i>Décision sur la demande</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="credit_action.php">
                <div class="modal-body">
                    <input type="hidden" name="credit_id" id="modalCreditId">
                    <input type="hidden" name="statut"    id="modalStatut">
                    <input type="hidden" name="redirect"  value="<?= ADMIN_BASE_URL ?>/credits.php?statut=<?= urlencode($filterStatut) ?>">

                    <div class="p-3 mb-3" id="modalBanner" style="border-radius:9px;font-size:.85rem;"></div>

                    <div class="mb-3">
                        <label class="form-label"><i class="fa fa-comment"></i> Commentaire pour l'employé (optionnel)</label>
                        <textarea name="admin_comment" class="form-control" rows="3" placeholder="Motif de la décision, conditions, etc."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-sm" id="modalSubmitBtn">Confirmer</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
// Handle delete
if (isset($_GET['delete']) && isSuperAdmin()) {
    $cid = intval($_GET['delete']);
    getAdminDB()->prepare("DELETE FROM credits WHERE id=?")->execute([$cid]);
    adminFlash('success','Demande supprimée.');
    adminRedirect(ADMIN_BASE_URL.'/credits.php');
}
?>

<?php $extraJS = <<<JS
<script>
function openDecisionModal(id, statut, ref) {
    document.getElementById('modalCreditId').value = id;
    document.getElementById('modalStatut').value   = statut;
    const banner = document.getElementById('modalBanner');
    const btn    = document.getElementById('modalSubmitBtn');
    if (statut === 'Accepté') {
        banner.innerHTML = '<i class="fa fa-check-circle me-2" style="color:#28A745"></i>Vous allez <strong>accepter</strong> la demande <strong>' + ref + '</strong>';
        banner.style.background = 'rgba(40,167,69,.08)';
        banner.style.color = '#155724';
        btn.className = 'btn btn-success btn-sm';
        btn.innerHTML = '<i class="fa fa-check me-1"></i>Accepter';
        document.getElementById('modalTitle').innerHTML = '<i class="fa fa-check-circle me-2"></i>Accepter la demande';
    } else {
        banner.innerHTML = '<i class="fa fa-times-circle me-2" style="color:#DC3545"></i>Vous allez <strong>refuser</strong> la demande <strong>' + ref + '</strong>';
        banner.style.background = 'rgba(220,53,69,.08)';
        banner.style.color = '#721c24';
        btn.className = 'btn btn-danger btn-sm';
        btn.innerHTML = '<i class="fa fa-times me-1"></i>Refuser';
        document.getElementById('modalTitle').innerHTML = '<i class="fa fa-times-circle me-2"></i>Refuser la demande';
    }
    new bootstrap.Modal(document.getElementById('decisionModal')).show();
}
</script>
JS;
require_once 'includes/footer.php'; ?>
