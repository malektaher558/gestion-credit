<?php
require_once 'includes/admin_config.php';
requireAdminLogin();

$db  = getAdminDB();
$uid = intval($_GET['id'] ?? 0);

$stmt = $db->prepare("SELECT * FROM users WHERE id=?");
$stmt->execute([$uid]);
$user = $stmt->fetch();
if (!$user) { adminFlash('error','Utilisateur introuvable.'); adminRedirect(ADMIN_BASE_URL.'/users.php'); }

$pageTitle  = 'Modifier utilisateur';
$breadcrumb = [['label'=>'Utilisateurs','url'=>ADMIN_BASE_URL.'/users.php'],['label'=>'Modifier','active'=>true]];
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $prenom = adminSanitize($_POST['prenom'] ?? '');
    $nom    = adminSanitize($_POST['nom'] ?? '');
    $email  = adminSanitize($_POST['email'] ?? '');
    $mat    = adminSanitize($_POST['matricule'] ?? '');

    if (empty($prenom)) $errors[] = 'Le prénom est requis.';
    if (empty($nom))    $errors[] = 'Le nom est requis.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Email invalide.';

    if (empty($errors)) {
        $db->prepare("UPDATE users SET prenom=?,nom=?,email=?,matricule=? WHERE id=?")->execute([$prenom,$nom,$email,$mat,$uid]);
        adminFlash('success','Utilisateur modifié avec succès.');
        adminRedirect(ADMIN_BASE_URL.'/user_view.php?id='.$uid);
    }
}

require_once 'includes/header.php';
?>
<div class="d-flex">
<?php require_once 'includes/sidebar.php'; ?>
<?php require_once 'includes/topbar.php'; ?>

<div class="row justify-content-center">
<div class="col-lg-6">
<div class="card-a">
    <div class="card-a-header"><div class="card-a-title"><i class="fa fa-user-edit"></i> Modifier l'utilisateur</div></div>
    <div class="card-a-body">
        <?php if (!empty($errors)): ?>
        <div class="alert alert-danger py-2 mb-3" style="font-size:.84rem;border-radius:8px;">
            <ul class="mb-0 ps-3"><?php foreach($errors as $e): ?><li><?= $e ?></li><?php endforeach; ?></ul>
        </div>
        <?php endif; ?>
        <form method="POST">
            <div class="row g-3">
                <div class="col-6">
                    <label class="form-label"><i class="fa fa-user"></i> Prénom</label>
                    <input type="text" name="prenom" class="form-control" value="<?= adminSanitize($user['prenom']) ?>" required>
                </div>
                <div class="col-6">
                    <label class="form-label"><i class="fa fa-user"></i> Nom</label>
                    <input type="text" name="nom" class="form-control" value="<?= adminSanitize($user['nom']) ?>" required>
                </div>
                <div class="col-12">
                    <label class="form-label"><i class="fa fa-envelope"></i> Email</label>
                    <input type="email" name="email" class="form-control" value="<?= adminSanitize($user['email']) ?>" required>
                </div>
                <div class="col-12">
                    <label class="form-label"><i class="fa fa-id-badge"></i> Matricule</label>
                    <input type="text" name="matricule" class="form-control" value="<?= adminSanitize($user['matricule']) ?>" maxlength="10">
                </div>
            </div>
            <div class="d-flex gap-2 mt-4">
                <a href="user_view.php?id=<?= $uid ?>" class="btn btn-outline-secondary btn-sm"><i class="fa fa-times me-1"></i>Annuler</a>
                <button type="submit" class="btn btn-primary btn-sm"><i class="fa fa-save me-1"></i>Enregistrer</button>
            </div>
        </form>
    </div>
</div>
</div>
</div>

</div></div></div>
<?php require_once 'includes/footer.php'; ?>
