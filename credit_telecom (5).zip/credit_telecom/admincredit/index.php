<?php
require_once 'includes/admin_config.php';
if (adminIsLoggedIn()) {
    adminRedirect(ADMIN_BASE_URL . '/dashboard.php');
} else {
    adminRedirect(ADMIN_BASE_URL . '/login.php');
}
?>
