<?php
require_once 'includes/admin_config.php';
requireAdminLogin();

$pageTitle  = 'Gestion des utilisateurs';
$breadcrumb = [['label'=>'Utilisateurs','active'=>true]];

$db = getAdminDB();

// Delete user
if (isset($_GET['delete']) && isSuperAdmin()) {
    $uid = intval($_GET['delete']);
    $db->prepare("DELETE FROM users WHERE id=?")->execute([$uid]);
    adminFlash('success', 'Utilisateur supprimé.');
    adminRedirect(ADMIN_BASE_URL . '/users.php');
}

$search = adminSanitize($_GET['q'] ?? '');
$page   = max(1, intval($_GET['page'] ?? 1));
$per    = ITEMS_PER_PAGE;

$where  = "WHERE 1=1";
$params = [];
if ($search) {
    $where  .= " AND (u.nom LIKE ? OR u.prenom LIKE ? OR u.matricule LIKE ? OR u.email LIKE ?)";
    $params  = array_fill(0, 4, "%$search%");
}

$countStmt = $db->prepare("SELECT COUNT(*) FROM users u $where");
$countStmt->execute($params);
$total  = $countStmt->fetchColumn();
$pages  = max(1, ceil($total / $per));
$offset = ($page - 1) * $per;

$stmt = $db->prepare("
    SELECT u.*, COUNT(c.id) as nb_credits,
           SUM(CASE WHEN c.statut='En attente' THEN 1 ELSE 0 END) as pending,
           SUM(CASE WHEN c.statut='Accepté' THEN 1 ELSE 0 END) as accepted
    FROM users u
    LEFT JOIN credits c ON c.user_id = u.id
    $where
    GROUP BY u.id
    ORDER BY u.created_at DESC
    LIMIT $per OFFSET $offset
");
$stmt->execute($params);
$users = $stmt->fetchAll();

require_once 'includes/header.php';
?>
<div class="d-flex">
<?php require_once 'includes/sidebar.php'; ?>
<?php require_once 'includes/topbar.php'; ?>

<div class="card-a">
    <div class="filter-bar">
        <form method="GET" class="d-flex gap-2 flex-wrap align-items-center w-100">
            <div class="input-wrap flex-grow-1" style="max-width:300px;">
                <i class="fi fa fa-search"></i>
                <input type="text" name="q" id="searchInput" class="form-control"
                       placeholder="Rechercher nom, matricule, email..."
                       value="<?= adminSanitize($search) ?>">
            </div>
            <button type="submit" class="btn btn-primary btn-sm"><i class="fa fa-search me-1"></i>Rechercher</button>
            <?php if ($search): ?><a href="users.php" class="btn btn-outline-secondary btn-sm"><i class="fa fa-times me-1"></i>Reset</a><?php endif; ?>
            <span style="margin-left:auto;font-size:.8rem;color:var(--text-m);"><?= $total ?> utilisateur(s)</span>
        </form>
    </div>

    <?php if (empty($users)): ?>
    <div class="empty-state"><i class="fa fa-users"></i><h5>Aucun utilisateur trouvé</h5></div>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table-admin">
            <thead>
                <tr>
                    <th>#</th><th>Utilisateur</th><th>Matricule</th><th>Email</th>
                    <th>Demandes</th><th>En attente</th><th>Acceptées</th>
                    <th>Inscrit le</th><th class="text-center">Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($users as $i => $u): ?>
            <tr data-href="<?= ADMIN_BASE_URL ?>/user_view.php?id=<?= $u['id'] ?>">
                <td style="color:var(--text-l);font-size:.78rem;"><?= $offset+$i+1 ?></td>
                <td>
                    <div class="d-flex align-items-center" style="gap:10px;">
                        <div style="width:34px;height:34px;font-size:.72rem;background:var(--p);color:#fff;border-radius:50%;display:flex;align-items:center;justify-content:center;font-family:'Sora',sans-serif;font-weight:700;flex-shrink:0;">
                            <?= strtoupper(substr($u['prenom'],0,1).substr($u['nom'],0,1)) ?>
                        </div>
                        <div class="fw7" style="font-size:.855rem;"><?= adminSanitize($u['prenom'].' '.$u['nom']) ?></div>
                    </div>
                </td>
                <td><span class="ref-badge"><?= adminSanitize($u['matricule']) ?></span></td>
                <td style="font-size:.8rem;"><?= adminSanitize($u['email']) ?></td>
                <td class="fw7 text-p"><?= $u['nb_credits'] ?></td>
                <td><?= $u['pending'] > 0 ? '<span class="bs bs-pending" style="font-size:.7rem;padding:2px 8px;">'.$u['pending'].'</span>' : '<span style="color:var(--text-l);">—</span>' ?></td>
                <td><?= $u['accepted'] > 0 ? '<span class="bs bs-accepted" style="font-size:.7rem;padding:2px 8px;">'.$u['accepted'].'</span>' : '<span style="color:var(--text-l);">—</span>' ?></td>
                <td style="font-size:.8rem;"><?= date('d/m/Y', strtotime($u['created_at'])) ?></td>
                <td>
                    <div class="d-flex justify-content-center gap-1">
                        <a href="user_view.php?id=<?= $u['id'] ?>" class="btn-act view" title="Voir"><i class="fa fa-eye"></i></a>
                        <a href="user_edit.php?id=<?= $u['id'] ?>" class="btn-act edit" title="Modifier"><i class="fa fa-edit"></i></a>
                        <?php if (isSuperAdmin()): ?>
                        <a href="users.php?delete=<?= $u['id'] ?>" class="btn-act del" title="Supprimer" data-confirm="Supprimer cet utilisateur ?"><i class="fa fa-trash"></i></a>
                        <?php endif; ?>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="d-flex align-items-center justify-content-between px-4 py-3" style="border-top:1px solid var(--border);">
        <div style="font-size:.78rem;color:var(--text-m);">Affichage de <?= $offset+1 ?> à <?= min($offset+$per,$total) ?> sur <?= $total ?></div>
        <?php if ($pages > 1): ?>
        <nav><ul class="pagination mb-0 pagination-sm">
            <?php for ($p=1;$p<=$pages;$p++): ?>
            <li class="page-item <?= $p===$page?'active':'' ?>">
                <a class="page-link" href="?page=<?= $p ?>&q=<?= urlencode($search) ?>"><?= $p ?></a>
            </li>
            <?php endfor; ?>
        </ul></nav>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>

</div></div></div>
<?php require_once 'includes/footer.php'; ?>
