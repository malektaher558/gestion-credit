<?php
require_once 'includes/admin_config.php';
requireAdminLogin();

$pageTitle  = 'Mon Profil';
$breadcrumb = [['label'=>'Profil','active'=>true]];

$admin  = getCurrentAdmin();
$db     = getAdminDB();
$errors = [];
$tab    = $_GET['tab'] ?? 'info';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($tab === 'info') {
        $prenom = adminSanitize($_POST['prenom'] ?? '');
        $nom    = adminSanitize($_POST['nom'] ?? '');
        $email  = adminSanitize($_POST['email'] ?? '');
        if (empty($prenom)) $errors[] = 'Le prénom est requis.';
        if (empty($nom))    $errors[] = 'Le nom est requis.';
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Email invalide.';
        if (empty($errors)) {
            $db->prepare("UPDATE admins SET prenom=?,nom=?,email=? WHERE id=?")->execute([$prenom,$nom,$email,$admin['id']]);
            adminFlash('success','Profil mis à jour.');
            adminRedirect(ADMIN_BASE_URL.'/profile.php?tab=info');
        }
    } elseif ($tab === 'password') {
        $current = $_POST['current_password'] ?? '';
        $new     = $_POST['new_password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';
        if (!password_verify($current, $admin['password'])) $errors[] = 'Mot de passe actuel incorrect.';
        if (strlen($new) < 8) $errors[] = 'Le nouveau mot de passe doit avoir au moins 8 caractères.';
        if ($new !== $confirm) $errors[] = 'Les mots de passe ne correspondent pas.';
        if (empty($errors)) {
            $db->prepare("UPDATE admins SET password=? WHERE id=?")->execute([password_hash($new, PASSWORD_DEFAULT), $admin['id']]);
            adminFlash('success','Mot de passe modifié avec succès.');
            adminRedirect(ADMIN_BASE_URL.'/profile.php?tab=password');
        }
    }
}

require_once 'includes/header.php';
?>
<div class="d-flex">
<?php require_once 'includes/sidebar.php'; ?>
<?php require_once 'includes/topbar.php'; ?>

<div class="row g-4">
    <div class="col-lg-3">
        <div class="card-a mb-4">
            <div class="card-a-body text-center">
                <div style="width:70px;height:70px;background:linear-gradient(135deg,var(--p),var(--s));border-radius:50%;display:flex;align-items:center;justify-content:center;font-family:'Sora',sans-serif;font-weight:800;font-size:1.3rem;color:#fff;margin:0 auto 14px;box-shadow:0 6px 20px rgba(0,87,184,.3);">
                    <?= strtoupper(substr($admin['prenom'],0,1).substr($admin['nom'],0,1)) ?>
                </div>
                <div class="fw7 font-sora" style="font-size:1rem;"><?= adminSanitize($admin['prenom'].' '.$admin['nom']) ?></div>
                <div style="font-size:.8rem;color:var(--text-m);margin:4px 0;"><?= adminSanitize($admin['email']) ?></div>
                <span class="bs <?= $admin['role']==='superadmin'?'bs-super':'bs-admin' ?>">
                    <?= $admin['role']==='superadmin' ? '⭐ Super Admin' : '🔑 Admin' ?>
                </span>
                <div style="margin-top:12px;font-size:.73rem;color:var(--text-l);">
                    Dernière connexion:<br><?= $admin['last_login'] ? date('d/m/Y H:i', strtotime($admin['last_login'])) : 'N/A' ?>
                </div>
            </div>
        </div>
        <div class="card-a">
            <div class="card-a-body d-grid gap-1">
                <a href="?tab=info" class="btn btn-sm <?= $tab==='info'?'btn-primary':'btn-outline-secondary' ?>"><i class="fa fa-user me-2"></i>Informations</a>
                <a href="?tab=password" class="btn btn-sm <?= $tab==='password'?'btn-primary':'btn-outline-secondary' ?>"><i class="fa fa-lock me-2"></i>Mot de passe</a>
            </div>
        </div>
    </div>

    <div class="col-lg-9">
        <div class="card-a">
            <div class="card-a-header">
                <div class="card-a-title">
                    <i class="fa <?= $tab==='password'?'fa-lock':'fa-user-edit' ?>"></i>
                    <?= $tab==='password' ? 'Changer le mot de passe' : 'Modifier mes informations' ?>
                </div>
            </div>
            <div class="card-a-body">
                <?php if (!empty($errors)): ?>
                <div class="alert alert-danger py-2 mb-3" style="font-size:.84rem;border-radius:8px;">
                    <ul class="mb-0 ps-3"><?php foreach($errors as $e): ?><li><?= $e ?></li><?php endforeach; ?></ul>
                </div>
                <?php endif; ?>

                <?php if ($tab === 'info'): ?>
                <form method="POST" action="?tab=info">
                    <div class="row g-3">
                        <div class="col-6">
                            <label class="form-label"><i class="fa fa-user"></i> Prénom</label>
                            <input type="text" name="prenom" class="form-control" value="<?= adminSanitize($admin['prenom']) ?>" required>
                        </div>
                        <div class="col-6">
                            <label class="form-label"><i class="fa fa-user"></i> Nom</label>
                            <input type="text" name="nom" class="form-control" value="<?= adminSanitize($admin['nom']) ?>" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label"><i class="fa fa-envelope"></i> Email</label>
                            <input type="email" name="email" class="form-control" value="<?= adminSanitize($admin['email']) ?>" required>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary btn-sm mt-4"><i class="fa fa-save me-1"></i>Enregistrer</button>
                </form>

                <?php else: ?>
                <form method="POST" action="?tab=password">
                    <div class="row g-3">
                        <div class="col-12">
                            <label class="form-label"><i class="fa fa-lock"></i> Mot de passe actuel</label>
                            <div class="input-wrap">
                                <i class="fi fa fa-lock"></i>
                                <input type="password" name="current_password" class="form-control" placeholder="••••••••" required>
                                <button type="button" class="toggle-pass"><i class="fa fa-eye"></i></button>
                            </div>
                        </div>
                        <div class="col-6">
                            <label class="form-label"><i class="fa fa-key"></i> Nouveau mot de passe</label>
                            <div class="input-wrap">
                                <i class="fi fa fa-key"></i>
                                <input type="password" name="new_password" class="form-control" placeholder="Min. 8 caractères" required>
                                <button type="button" class="toggle-pass"><i class="fa fa-eye"></i></button>
                            </div>
                        </div>
                        <div class="col-6">
                            <label class="form-label"><i class="fa fa-key"></i> Confirmer</label>
                            <div class="input-wrap">
                                <i class="fi fa fa-key"></i>
                                <input type="password" name="confirm_password" class="form-control" placeholder="Répéter" required>
                                <button type="button" class="toggle-pass"><i class="fa fa-eye"></i></button>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary btn-sm mt-4"><i class="fa fa-save me-1"></i>Changer le mot de passe</button>
                </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

</div></div></div>
<?php require_once 'includes/footer.php'; ?>
