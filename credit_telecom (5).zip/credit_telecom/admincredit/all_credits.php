<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/auth_helper.php';

requireLogin();

if (!isAdmin()) {
    flashMessage('error', 'Accès réservé aux administrateurs.');
    redirect(BASE_URL . '/dashboard/index.php');
}

$pageTitle  = 'Gestion de tous les crédits';
$breadcrumb = [['label' => 'Administration'], ['label' => 'Tous les crédits', 'active' => true]];

$db = getDB();

// Handle status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $creditId = intval($_POST['credit_id']);
    $newStatut = sanitize($_POST['statut']);
    $commentaire = sanitize($_POST['commentaire'] ?? '');

    if (in_array($newStatut, CREDIT_STATUTS)) {
        $stmt = $db->prepare("UPDATE credits SET statut=?, commentaire=? WHERE id=?");
        $stmt->execute([$newStatut, $commentaire ?: null, $creditId]);
        flashMessage('success', "Statut mis à jour avec succès.");
    }
    redirect(BASE_URL . '/admin/all_credits.php');
}

// Stats globales
$totalAll = $db->query("SELECT COUNT(*) FROM credits")->fetchColumn();
$pending  = $db->query("SELECT COUNT(*) FROM credits WHERE statut='En attente'")->fetchColumn();
$accepted = $db->query("SELECT COUNT(*) FROM credits WHERE statut='Accepté'")->fetchColumn();
$refused  = $db->query("SELECT COUNT(*) FROM credits WHERE statut='Refusé'")->fetchColumn();

// Filter
$filterStatut = $_GET['statut'] ?? '';
$filterType   = $_GET['type'] ?? '';
$page   = max(1, intval($_GET['page'] ?? 1));
$perPage = ITEMS_PER_PAGE;

$where  = "WHERE 1=1";
$params = [];
if ($filterStatut) { $where .= " AND c.statut = ?"; $params[] = $filterStatut; }
if ($filterType)   { $where .= " AND c.type_credit = ?"; $params[] = $filterType; }

$countStmt = $db->prepare("SELECT COUNT(*) FROM credits c $where");
$countStmt->execute($params);
$total = $countStmt->fetchColumn();
$pages  = max(1, ceil($total / $perPage));
$offset = ($page - 1) * $perPage;

$stmt = $db->prepare("SELECT c.*, u.nom, u.prenom, u.matricule FROM credits c JOIN users u ON c.user_id=u.id $where ORDER BY c.created_at DESC LIMIT $perPage OFFSET $offset");
$stmt->execute($params);
$credits = $stmt->fetchAll();

require_once '../includes/header.php';
?>
<div class="d-flex">
<?php require_once '../includes/sidebar.php'; ?>
<?php require_once '../includes/navbar.php'; ?>

<!-- Global stats -->
<div class="stats-grid">
    <div class="stat-card primary">
        <div class="stat-icon"><i class="fa fa-file-alt"></i></div>
        <div><div class="stat-value"><?= $totalAll ?></div><div class="stat-label">Total crédits</div></div>
    </div>
    <div class="stat-card warning">
        <div class="stat-icon"><i class="fa fa-clock"></i></div>
        <div><div class="stat-value"><?= $pending ?></div><div class="stat-label">En attente</div></div>
    </div>
    <div class="stat-card success">
        <div class="stat-icon"><i class="fa fa-check-circle"></i></div>
        <div><div class="stat-value"><?= $accepted ?></div><div class="stat-label">Acceptés</div></div>
    </div>
    <div class="stat-card danger">
        <div class="stat-icon"><i class="fa fa-times-circle"></i></div>
        <div><div class="stat-value"><?= $refused ?></div><div class="stat-label">Refusés</div></div>
    </div>
</div>

<div class="card-tt">
    <div class="card-tt-header">
        <div class="card-tt-title"><i class="fa fa-database"></i> Toutes les demandes de crédit</div>
    </div>

    <!-- Filters -->
    <div class="filter-bar">
        <form method="GET" class="d-flex gap-2 flex-wrap">
            <select name="statut" class="form-select">
                <option value="">Tous les statuts</option>
                <?php foreach (CREDIT_STATUTS as $s): ?>
                <option value="<?= $s ?>" <?= $filterStatut === $s ? 'selected' : '' ?>><?= $s ?></option>
                <?php endforeach; ?>
            </select>
            <select name="type" class="form-select">
                <option value="">Tous les types</option>
                <?php foreach (CREDIT_TYPES as $t): ?>
                <option value="<?= $t ?>" <?= $filterType === $t ? 'selected' : '' ?>><?= $t ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="btn btn-primary btn-sm"><i class="fa fa-filter me-1"></i> Filtrer</button>
            <?php if ($filterStatut || $filterType): ?>
            <a href="all_credits.php" class="btn btn-outline-secondary btn-sm"><i class="fa fa-times me-1"></i> Reset</a>
            <?php endif; ?>
        </form>
    </div>

    <div class="table-responsive">
        <table class="table-tt">
            <thead>
                <tr>
                    <th>Référence</th>
                    <th>Employé</th>
                    <th>Matricule</th>
                    <th>Type</th>
                    <th>Montant</th>
                    <th>Échéance</th>
                    <th>Date</th>
                    <th>Statut</th>
                    <th class="text-center">Action</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($credits as $c):
                $badgeClass = match($c['statut']) { 'Accepté' => 'accepte', 'Refusé' => 'refuse', default => 'attente' };
                $badgeIcon  = match($c['statut']) { 'Accepté' => 'fa-check-circle', 'Refusé' => 'fa-times-circle', default => 'fa-clock' };
            ?>
            <tr>
                <td><span class="ref-cell"><?= sanitize($c['reference']) ?></span></td>
                <td class="fw-700"><?= sanitize($c['prenom'] . ' ' . $c['nom']) ?></td>
                <td><?= sanitize($c['matricule']) ?></td>
                <td><span class="badge-type"><?= sanitize($c['type_credit']) ?></span></td>
                <td class="fw-700"><?= number_format($c['montant'], 0, ',', ' ') ?> DT</td>
                <td><?= $c['echeance'] ?> mois</td>
                <td><?= date('d/m/Y', strtotime($c['date_depot'])) ?></td>
                <td><span class="badge-statut <?= $badgeClass ?>"><i class="fa <?= $badgeIcon ?>"></i> <?= $c['statut'] ?></span></td>
                <td class="text-center">
                    <a href="<?= BASE_URL ?>/credits/view.php?id=<?= $c['id'] ?>" class="btn-action view" title="Voir">
                        <i class="fa fa-eye"></i>
                    </a>
                    <?php if ($c['statut'] === 'En attente'): ?>
                    <button class="btn-action edit"
                            title="Changer statut"
                            onclick='openStatusModal(<?= json_encode(["id"=>$c['id'],"reference"=>$c['reference'],"nom"=>$c['prenom'].' '.$c['nom']]) ?>)'>
                        <i class="fa fa-check-square"></i>
                    </button>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="d-flex align-items-center justify-content-between px-4 py-3" style="border-top:1px solid var(--border);">
        <div style="font-size:.8rem;color:var(--text-muted);">
            <?= $total ?> demande(s) au total
        </div>
        <?php if ($pages > 1): ?>
        <nav>
            <ul class="pagination mb-0 pagination-sm">
                <?php for ($p = 1; $p <= $pages; $p++): ?>
                <li class="page-item <?= $p === $page ? 'active' : '' ?>">
                    <a class="page-link" href="?page=<?= $p ?>&statut=<?= $filterStatut ?>&type=<?= $filterType ?>"><?= $p ?></a>
                </li>
                <?php endfor; ?>
            </ul>
        </nav>
        <?php endif; ?>
    </div>
</div>

<!-- Status Modal -->
<div class="modal fade" id="statusModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fa fa-check-square me-2"></i>Mettre à jour le statut</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" value="update_status">
                    <input type="hidden" name="credit_id" id="modalCreditId">

                    <p style="font-size:.85rem;color:var(--text-muted);">
                        Demande : <strong id="modalRef"></strong><br>
                        Employé : <strong id="modalNom"></strong>
                    </p>

                    <div class="form-group">
                        <label class="form-label"><i class="fa fa-tag"></i> Nouveau statut</label>
                        <select name="statut" class="form-select" required>
                            <option value="Accepté">✅ Accepté</option>
                            <option value="Refusé">❌ Refusé</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label"><i class="fa fa-comment"></i> Commentaire (optionnel)</label>
                        <textarea name="commentaire" class="form-control" rows="3" placeholder="Motif de la décision..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-primary btn-sm">Confirmer</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function openStatusModal(data) {
    document.getElementById('modalCreditId').value = data.id;
    document.getElementById('modalRef').textContent = data.reference;
    document.getElementById('modalNom').textContent = data.nom;
    new bootstrap.Modal(document.getElementById('statusModal')).show();
}
</script>

    </div>
</div>
</div>

<?php require_once '../includes/footer.php'; ?>
