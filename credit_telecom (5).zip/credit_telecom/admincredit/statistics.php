<?php
require_once 'includes/admin_config.php';
requireAdminLogin();

$pageTitle  = 'Statistiques';
$breadcrumb = [['label'=>'Statistiques','active'=>true]];

$db = getAdminDB();

// Global stats
$stats = getGlobalStats();

// By type
$byType = $db->query("SELECT type_credit, COUNT(*) as nb, SUM(montant) as total, SUM(CASE WHEN statut='Accepté' THEN montant ELSE 0 END) as accorde, COUNT(CASE WHEN statut='Accepté' THEN 1 END) as nb_ok, COUNT(CASE WHEN statut='Refusé' THEN 1 END) as nb_ko FROM credits GROUP BY type_credit")->fetchAll();

// Monthly stats (12 months)
$monthly12 = $db->query("SELECT DATE_FORMAT(created_at,'%b %Y') as month, DATE_FORMAT(created_at,'%Y-%m') as ym, COUNT(*) as total, SUM(CASE WHEN statut='Accepté' THEN 1 ELSE 0 END) as accepted, SUM(montant) as montant FROM credits WHERE created_at >= DATE_SUB(NOW(), INTERVAL 12 MONTH) GROUP BY DATE_FORMAT(created_at,'%Y-%m') ORDER BY ym")->fetchAll();

// Top users
$topUsers = $db->query("SELECT u.prenom, u.nom, u.matricule, COUNT(c.id) as nb, SUM(c.montant) as total, SUM(CASE WHEN c.statut='Accepté' THEN c.montant ELSE 0 END) as accorde FROM users u LEFT JOIN credits c ON c.user_id=u.id GROUP BY u.id ORDER BY nb DESC LIMIT 8")->fetchAll();

require_once 'includes/header.php';
?>
<div class="d-flex">
<?php require_once 'includes/sidebar.php'; ?>
<?php require_once 'includes/topbar.php'; ?>

<!-- KPI Cards -->
<div class="stats-grid mb-4">
    <div class="stat-card c-primary">
        <div class="stat-icon"><i class="fa fa-file-alt"></i></div>
        <div><div class="stat-value"><?= $stats['total_credits'] ?></div><div class="stat-label">Total demandes</div></div>
    </div>
    <div class="stat-card c-success">
        <div class="stat-icon"><i class="fa fa-check-circle"></i></div>
        <div><div class="stat-value"><?= $stats['accepted'] ?></div><div class="stat-label">Acceptées</div></div>
    </div>
    <div class="stat-card c-danger">
        <div class="stat-icon"><i class="fa fa-times-circle"></i></div>
        <div><div class="stat-value"><?= $stats['refused'] ?></div><div class="stat-label">Refusées</div></div>
    </div>
    <div class="stat-card c-secondary">
        <div class="stat-icon"><i class="fa fa-coins"></i></div>
        <div>
            <div class="stat-value"><?= number_format($stats['montant_accorde']/1000,1,',','') ?>K</div>
            <div class="stat-label">DT accordés</div>
        </div>
    </div>
    <div class="stat-card c-warning">
        <div class="stat-icon"><i class="fa fa-percent"></i></div>
        <div>
            <div class="stat-value"><?= $stats['total_credits'] > 0 ? round($stats['accepted']/$stats['total_credits']*100) : 0 ?>%</div>
            <div class="stat-label">Taux d'acceptation</div>
        </div>
    </div>
</div>

<!-- Charts Row 1 -->
<div class="row g-4 mb-4">
    <div class="col-lg-8">
        <div class="card-a h-100">
            <div class="card-a-header"><div class="card-a-title"><i class="fa fa-chart-line"></i> Évolution sur 12 mois</div></div>
            <div class="card-a-body"><div style="height:250px;"><canvas id="monthlyChart"></canvas></div></div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card-a h-100">
            <div class="card-a-header"><div class="card-a-title"><i class="fa fa-chart-pie"></i> Répartition statuts</div></div>
            <div class="card-a-body"><div style="height:250px;"><canvas id="statusChart"></canvas></div></div>
        </div>
    </div>
</div>

<!-- Charts Row 2 -->
<div class="row g-4 mb-4">
    <div class="col-lg-6">
        <div class="card-a h-100">
            <div class="card-a-header"><div class="card-a-title"><i class="fa fa-chart-bar"></i> Demandes par type de crédit</div></div>
            <div class="card-a-body"><div style="height:220px;"><canvas id="typeBarChart"></canvas></div></div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card-a h-100">
            <div class="card-a-header"><div class="card-a-title"><i class="fa fa-money-bill-wave"></i> Montants accordés par type (DT)</div></div>
            <div class="card-a-body"><div style="height:220px;"><canvas id="montantChart"></canvas></div></div>
        </div>
    </div>
</div>

<!-- Type breakdown table -->
<div class="row g-4 mb-4">
    <div class="col-lg-7">
        <div class="card-a">
            <div class="card-a-header"><div class="card-a-title"><i class="fa fa-table"></i> Analyse par type de crédit</div></div>
            <div class="table-responsive">
                <table class="table-admin">
                    <thead>
                        <tr><th>Type</th><th>Total</th><th>Acceptées</th><th>Refusées</th><th>Montant total</th><th>Accordé</th></tr>
                    </thead>
                    <tbody>
                    <?php foreach ($byType as $t): ?>
                    <tr>
                        <td><span class="bs bs-type"><?= adminSanitize($t['type_credit']) ?></span></td>
                        <td class="fw7"><?= $t['nb'] ?></td>
                        <td><span class="bs bs-accepted" style="font-size:.7rem;padding:2px 8px;"><?= $t['nb_ok'] ?></span></td>
                        <td><span class="bs bs-refused" style="font-size:.7rem;padding:2px 8px;"><?= $t['nb_ko'] ?></span></td>
                        <td class="fw7"><?= number_format($t['total'],0,',',' ') ?> DT</td>
                        <td class="fw7 text-p"><?= number_format($t['accorde'],0,',',' ') ?> DT</td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-lg-5">
        <div class="card-a h-100">
            <div class="card-a-header"><div class="card-a-title"><i class="fa fa-trophy"></i> Top utilisateurs</div></div>
            <div style="padding:8px 0;">
                <?php foreach ($topUsers as $i => $u): if (!$u['nb']) continue; ?>
                <div class="activity-item" style="padding:10px 20px;">
                    <div style="width:26px;height:26px;border-radius:50%;background:var(--p);color:#fff;font-family:'Sora',sans-serif;font-weight:800;font-size:.72rem;display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                        <?= $i+1 ?>
                    </div>
                    <div style="flex:1;">
                        <div style="font-size:.83rem;font-weight:700;"><?= adminSanitize($u['prenom'].' '.$u['nom']) ?></div>
                        <div style="font-size:.72rem;color:var(--text-l);">Mat: <?= adminSanitize($u['matricule']) ?> · <?= $u['nb'] ?> demande(s)</div>
                    </div>
                    <div class="fw7 text-p" style="font-size:.82rem;"><?= number_format($u['accorde'],0,',',' ') ?> DT</div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

</div></div></div>

<?php
$mLabels  = json_encode(array_column($monthly12,'month'));
$mTotal   = json_encode(array_column($monthly12,'total'));
$mAcc     = json_encode(array_column($monthly12,'accepted'));
$mMontant = json_encode(array_column($monthly12,'montant'));

$tLabels  = json_encode(array_column($byType,'type_credit'));
$tNb      = json_encode(array_column($byType,'nb'));
$tAcc     = json_encode(array_column($byType,'accorde'));

$sData    = json_encode([$stats['pending'],$stats['accepted'],$stats['refused']]);
?>
<?php $extraJS = <<<JS
<script>
buildLine('monthlyChart', $mLabels, [
    { label:'Total', data:$mTotal, borderColor:'#0057B8', backgroundColor:'rgba(0,87,184,.07)', fill:true },
    { label:'Acceptées', data:$mAcc, borderColor:'#28A745', backgroundColor:'rgba(40,167,69,.05)', fill:true }
]);
buildDoughnut('statusChart',
    ['En attente','Acceptées','Refusées'],
    $sData,
    ['#FFC107','#28A745','#DC3545']
);
buildBar('typeBarChart', $tLabels, [{ label:'Nombre de demandes', data:$tNb, backgroundColor:['rgba(0,87,184,.8)','rgba(0,174,239,.8)','rgba(40,167,69,.8)'], borderRadius:6 }]);
buildBar('montantChart', $tLabels, [{ label:'Montant accordé (DT)', data:$tAcc, backgroundColor:['rgba(0,87,184,.7)','rgba(0,174,239,.7)','rgba(40,167,69,.7)'], borderRadius:6 }], {suffix:' DT'});
</script>
JS;
require_once 'includes/footer.php'; ?>
