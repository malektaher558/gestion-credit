<?php
require_once 'includes/admin_config.php';
session_destroy();
header('Location: ' . ADMIN_BASE_URL . '/login.php');
exit();
