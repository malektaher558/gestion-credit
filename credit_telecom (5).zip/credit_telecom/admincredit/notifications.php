<?php
require_once 'includes/admin_config.php';
requireAdminLogin();

$pageTitle  = 'Notifications';
$breadcrumb = [['label'=>'Notifications','active'=>true]];

$admin = getCurrentAdmin();
$db    = getAdminDB();

// Mark all read
if (isset($_GET['mark_read'])) {
    markAllRead($admin['id']);
    adminFlash('success','Toutes les notifications ont été marquées comme lues.');
    adminRedirect(ADMIN_BASE_URL.'/notifications.php');
}

// Mark single read
if (isset($_GET['read'])) {
    $db->prepare("UPDATE notifications SET is_read=1 WHERE id=? AND admin_id=?")->execute([intval($_GET['read']), $admin['id']]);
    adminRedirect(ADMIN_BASE_URL.'/notifications.php');
}

// Delete
if (isset($_GET['delete'])) {
    $db->prepare("DELETE FROM notifications WHERE id=? AND admin_id=?")->execute([intval($_GET['delete']), $admin['id']]);
    adminFlash('success','Notification supprimée.');
    adminRedirect(ADMIN_BASE_URL.'/notifications.php');
}

$page   = max(1, intval($_GET['page'] ?? 1));
$per    = 15;
$total  = $db->prepare("SELECT COUNT(*) FROM notifications WHERE admin_id=?");
$total->execute([$admin['id']]);
$total  = $total->fetchColumn();
$pages  = max(1, ceil($total/$per));
$offset = ($page-1)*$per;

$stmt = $db->prepare("SELECT * FROM notifications WHERE admin_id=? ORDER BY created_at DESC LIMIT $per OFFSET $offset");
$stmt->execute([$admin['id']]);
$notifs = $stmt->fetchAll();

$unread = getUnreadCount($admin['id']);

require_once 'includes/header.php';
?>
<div class="d-flex">
<?php require_once 'includes/sidebar.php'; ?>
<?php require_once 'includes/topbar.php'; ?>

<div class="card-a">
    <div class="card-a-header">
        <div class="card-a-title"><i class="fa fa-bell"></i> Notifications <?php if ($unread>0): ?><span class="nav-badge-count" style="position:static;margin-left:6px;"><?= $unread ?></span><?php endif; ?></div>
        <?php if ($unread > 0): ?>
        <a href="notifications.php?mark_read=1" class="btn btn-outline-primary btn-sm"><i class="fa fa-check-double me-1"></i>Tout marquer lu</a>
        <?php endif; ?>
    </div>

    <?php if (empty($notifs)): ?>
    <div class="empty-state">
        <i class="fa fa-bell-slash"></i>
        <h5>Aucune notification</h5>
        <p>Vous êtes à jour !</p>
    </div>
    <?php else: ?>
    <div>
    <?php foreach ($notifs as $n):
        $icon = match($n['type']) {
            'new_request'     => ['fa-file-plus',    '#0057B8', 'rgba(0,87,184,.1)'],
            'accepted'        => ['fa-check-circle', '#28A745', 'rgba(40,167,69,.1)'],
            'refused'         => ['fa-times-circle', '#DC3545', 'rgba(220,53,69,.1)'],
            'user_registered' => ['fa-user-plus',    '#00AEEF', 'rgba(0,174,239,.1)'],
            default           => ['fa-bell',         '#6B7280', 'rgba(107,114,128,.1)'],
        };
    ?>
    <div class="activity-item <?= $n['is_read'] ? '' : 'unread-notif' ?>" style="padding:16px 22px;<?= !$n['is_read'] ? 'background:rgba(0,87,184,.03);' : '' ?>">
        <div class="activity-dot" style="background:<?= $icon[2] ?>;color:<?= $icon[1] ?>;width:40px;height:40px;border-radius:10px;flex-shrink:0;">
            <i class="fa <?= $icon[0] ?>"></i>
        </div>
        <div style="flex:1;">
            <div style="font-size:.84rem;font-weight:<?= $n['is_read'] ? '500' : '700' ?>;color:var(--text);">
                <?php if (!$n['is_read']): ?><span style="display:inline-block;width:8px;height:8px;background:var(--p);border-radius:50%;margin-right:7px;"></span><?php endif; ?>
                <?= adminSanitize($n['title']) ?>
            </div>
            <div style="font-size:.8rem;color:var(--text-m);margin-top:3px;line-height:1.4;"><?= adminSanitize($n['message']) ?></div>
            <div style="font-size:.72rem;color:var(--text-l);margin-top:5px;">
                <i class="fa fa-clock me-1"></i><?= date('d/m/Y à H:i', strtotime($n['created_at'])) ?>
            </div>
        </div>
        <div class="d-flex flex-column gap-1">
            <?php if ($n['credit_id']): ?>
            <a href="credit_view.php?id=<?= $n['credit_id'] ?>" class="btn-act view" title="Voir la demande"><i class="fa fa-eye"></i></a>
            <?php endif; ?>
            <?php if (!$n['is_read']): ?>
            <a href="notifications.php?read=<?= $n['id'] ?>" class="btn-act ok" title="Marquer lu"><i class="fa fa-check"></i></a>
            <?php endif; ?>
            <a href="notifications.php?delete=<?= $n['id'] ?>" class="btn-act del" title="Supprimer" data-confirm="Supprimer cette notification ?"><i class="fa fa-trash"></i></a>
        </div>
    </div>
    <?php endforeach; ?>
    </div>

    <?php if ($pages > 1): ?>
    <div class="d-flex justify-content-center py-3" style="border-top:1px solid var(--border);">
        <nav><ul class="pagination mb-0 pagination-sm">
            <?php for ($p=1;$p<=$pages;$p++): ?>
            <li class="page-item <?= $p===$page?'active':'' ?>">
                <a class="page-link" href="?page=<?= $p ?>"><?= $p ?></a>
            </li>
            <?php endfor; ?>
        </ul></nav>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>

</div></div></div>
<?php require_once 'includes/footer.php'; ?>
