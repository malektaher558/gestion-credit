<?php
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/auth_helper.php';

if (isLoggedIn()) {
    redirect(BASE_URL . '/dashboard/index.php');
} else {
    redirect(BASE_URL . '/auth/login.php');
}
?>
