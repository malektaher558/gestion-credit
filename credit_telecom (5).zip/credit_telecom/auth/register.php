<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/auth_helper.php';

if (isLoggedIn()) {
    redirect(BASE_URL . '/dashboard/index.php');
}

$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $matricule = sanitize($_POST['matricule'] ?? '');
    $prenom    = sanitize($_POST['prenom'] ?? '');
    $nom       = sanitize($_POST['nom'] ?? '');
    $email     = sanitize($_POST['email'] ?? '');
    $password  = $_POST['password'] ?? '';
    $confirm   = $_POST['confirm_password'] ?? '';

    if (empty($matricule) || !preg_match('/^\d{5}$/', $matricule))
        $errors[] = 'Le matricule doit contenir exactement 5 chiffres.';
    if (empty($prenom))
        $errors[] = 'Le prénom est requis.';
    if (empty($nom))
        $errors[] = 'Le nom est requis.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || !str_contains($email, 'tunisietelecom'))
        $errors[] = 'Utilisez votre adresse email Tunisie Telecom (prenom.nom@tunisietelecom.tn).';
    if (strlen($password) < 6)
        $errors[] = 'Le mot de passe doit avoir au moins 6 caractères.';
    if ($password !== $confirm)
        $errors[] = 'Les mots de passe ne correspondent pas.';

    if (empty($errors)) {
        $db = getDB();
        // Check if matricule or email exists
        $stmt = $db->prepare("SELECT id FROM users WHERE matricule = ? OR email = ?");
        $stmt->execute([$matricule, $email]);
        if ($stmt->fetch()) {
            $errors[] = 'Ce matricule ou cet email est déjà utilisé.';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $db->prepare("INSERT INTO users (matricule, nom, prenom, email, password) VALUES (?,?,?,?,?)");
            $stmt->execute([$matricule, $nom, $prenom, $email, $hash]);
            $success = 'Compte créé avec succès ! Vous pouvez maintenant vous connecter.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription — Crédit TT</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Sora:wght@300;400;500;600;700&family=IBM+Plex+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>
<div class="auth-wrapper">
    <div class="auth-box" style="max-width:480px;">
        <div class="auth-logo">
            <svg width="56" height="56" viewBox="0 0 56 56" xmlns="http://www.w3.org/2000/svg">
                <rect width="56" height="56" rx="14" fill="#0057B8"/>
                <text x="28" y="36" text-anchor="middle" fill="white" font-size="20" font-weight="800" font-family="Sora,sans-serif">TT</text>
            </svg>
            <h2>Portail Crédit TT</h2>
            <p>Créer votre compte employé</p>
        </div>

        <div class="auth-tabs">
            <a href="login.php" class="auth-tab">
                <i class="fa fa-sign-in-alt me-1"></i> Connexion
            </a>
            <a href="register.php" class="auth-tab active">
                <i class="fa fa-user-plus me-1"></i> Créer un compte
            </a>
        </div>

        <?php if ($success): ?>
        <div class="alert alert-success py-2 mb-3" style="font-size:.85rem;border-radius:8px;">
            <i class="fa fa-check-circle me-2"></i><?= $success ?>
            <br><a href="login.php" class="alert-link">→ Se connecter</a>
        </div>
        <?php endif; ?>

        <?php if (!empty($errors)): ?>
        <div class="alert alert-danger py-2 mb-3" style="font-size:.85rem;border-radius:8px;">
            <i class="fa fa-exclamation-circle me-2"></i>
            <ul class="mb-0 ps-3">
                <?php foreach ($errors as $e): ?><li><?= $e ?></li><?php endforeach; ?>
            </ul>
        </div>
        <?php endif; ?>

        <form method="POST" novalidate>
            <div class="row g-3">
                <div class="col-12">
                    <label class="form-label"><i class="fa fa-id-badge"></i> Matricule TT</label>
                    <div class="input-icon-wrap">
                        <i class="fa fa-id-badge field-icon"></i>
                        <input type="text" name="matricule" class="form-control"
                               placeholder="Matricule (5 chiffres)"
                               value="<?= sanitize($_POST['matricule'] ?? '') ?>"
                               maxlength="5" pattern="\d{5}">
                    </div>
                </div>
                <div class="col-6">
                    <label class="form-label"><i class="fa fa-user"></i> Prénom</label>
                    <input type="text" name="prenom" class="form-control"
                           placeholder="Prénom"
                           value="<?= sanitize($_POST['prenom'] ?? '') ?>">
                </div>
                <div class="col-6">
                    <label class="form-label"><i class="fa fa-user"></i> Nom</label>
                    <input type="text" name="nom" class="form-control"
                           placeholder="Nom"
                           value="<?= sanitize($_POST['nom'] ?? '') ?>">
                </div>
                <div class="col-12">
                    <label class="form-label"><i class="fa fa-envelope"></i> Email TT</label>
                    <div class="input-icon-wrap">
                        <i class="fa fa-envelope field-icon"></i>
                        <input type="email" name="email" class="form-control"
                               placeholder="prenom.nom@tunisietelecom.tn"
                               value="<?= sanitize($_POST['email'] ?? '') ?>">
                    </div>
                </div>
                <div class="col-6">
                    <label class="form-label"><i class="fa fa-lock"></i> Mot de passe</label>
                    <div class="input-icon-wrap">
                        <i class="fa fa-lock field-icon"></i>
                        <input type="password" name="password" class="form-control" placeholder="Min. 6 caractères">
                        <button type="button" class="toggle-pass"><i class="fa fa-eye"></i></button>
                    </div>
                </div>
                <div class="col-6">
                    <label class="form-label"><i class="fa fa-lock"></i> Confirmer</label>
                    <div class="input-icon-wrap">
                        <i class="fa fa-lock field-icon"></i>
                        <input type="password" name="confirm_password" class="form-control" placeholder="Répéter">
                        <button type="button" class="toggle-pass"><i class="fa fa-eye"></i></button>
                    </div>
                </div>
            </div>

            <button type="submit" class="btn-auth mt-3">
                <i class="fa fa-user-plus"></i>
                S'inscrire
            </button>
        </form>

        <hr style="margin:20px 0;border-color:var(--border);">
        <p style="font-size:.72rem;color:var(--text-light);text-align:center;">
            © 2025 Tunisie Telecom. Tous droits réservés.
        </p>
    </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
<script src="<?= BASE_URL ?>/assets/js/app.js"></script>
</body>
</html>
