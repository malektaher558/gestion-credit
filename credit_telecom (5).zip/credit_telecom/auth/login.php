<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/auth_helper.php';

if (isLoggedIn()) {
    redirect(BASE_URL . '/dashboard/index.php');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $matricule = sanitize($_POST['matricule'] ?? '');
    $password  = $_POST['password'] ?? '';

    if (empty($matricule) || empty($password)) {
        $error = 'Veuillez remplir tous les champs.';
    } else {
        $db   = getDB();
        $stmt = $db->prepare("SELECT * FROM users WHERE matricule = ?");
        $stmt->execute([$matricule]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id']  = $user['id'];
            $_SESSION['role']     = $user['role'];
            $_SESSION['nom']      = $user['nom'];
            $_SESSION['prenom']   = $user['prenom'];
            flashMessage('success', 'Bienvenue, ' . $user['prenom'] . ' ' . $user['nom'] . ' !');
            redirect(BASE_URL . '/dashboard/index.php');
        } else {
            $error = 'Matricule ou mot de passe incorrect.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion — Crédit TT</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Sora:wght@300;400;500;600;700&family=IBM+Plex+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>
<div class="auth-wrapper">
    <div class="auth-box">
        <div class="auth-logo">
            <img src="<?= BASE_URL ?>/assets/img/logo_tt.png" alt="Tunisie Telecom" style="width:90px;height:90px;object-fit:contain;margin-bottom:12px;">
            <h2>Portail Crédit TT</h2>
            <p>Tunisie Telecom — Espace Employé</p>
        </div>

        <div class="auth-tabs">
            <a href="login.php" class="auth-tab active">
                <i class="fa fa-sign-in-alt me-1"></i> Connexion
            </a>
            <a href="register.php" class="auth-tab">
                <i class="fa fa-user-plus me-1"></i> Créer un compte
            </a>
        </div>

        <?php if ($error): ?>
        <div class="alert alert-danger py-2 mb-3" style="font-size:.85rem;border-radius:8px;">
            <i class="fa fa-exclamation-circle me-2"></i><?= $error ?>
        </div>
        <?php endif; ?>

        <form method="POST" novalidate>
            <div class="form-group">
                <label class="form-label"><i class="fa fa-id-badge"></i> Matricule TT</label>
                <div class="input-icon-wrap">
                    <i class="fa fa-id-badge field-icon"></i>
                    <input type="text" name="matricule" class="form-control"
                           placeholder="Matricule (5 chiffres)"
                           value="<?= sanitize($_POST['matricule'] ?? '') ?>"
                           maxlength="10" required>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label"><i class="fa fa-lock"></i> Mot de passe</label>
                <div class="input-icon-wrap">
                    <i class="fa fa-lock field-icon"></i>
                    <input type="password" name="password" class="form-control"
                           placeholder="Mot de passe" required>
                    <button type="button" class="toggle-pass">
                        <i class="fa fa-eye"></i>
                    </button>
                </div>
            </div>

            <button type="submit" class="btn-auth mt-2">
                <i class="fa fa-sign-in-alt"></i>
                Se connecter
            </button>
        </form>

        <p class="text-center mt-3 mb-0" style="font-size:.8rem;color:var(--text-muted);">
            Mot de passe oublié ? Contactez la DRH
        </p>

        <hr style="margin:20px 0;border-color:var(--border);">
        <p style="font-size:.72rem;color:var(--text-light);text-align:center;">
            © 2025 Tunisie Telecom. Tous droits réservés.
        </p>
    </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
<script src="<?= BASE_URL ?>/assets/js/app.js"></script>
</body>
</html>
