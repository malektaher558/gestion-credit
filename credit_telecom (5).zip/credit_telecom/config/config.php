<?php
// ============================================
// config/config.php
// Configuration globale de l'application
// ============================================

define('APP_NAME', 'Crédit TT');
define('APP_VERSION', '1.0.0');
define('BASE_URL', 'http://localhost/credit_telecom');

// Types de crédit disponibles
define('CREDIT_TYPES', ['Solfa', 'Personnel', 'Consommation']);

// Montants disponibles
define('CREDIT_AMOUNTS', [500, 1000, 1500, 2000, 2500, 3000, 4000, 5000, 7500, 10000]);

// Échéances disponibles (mois)
define('CREDIT_ECHEANCES', [3, 6, 9, 12, 15, 18, 24, 36, 48, 60]);

// Statuts
define('CREDIT_STATUTS', ['En attente', 'Accepté', 'Refusé']);

// Pagination
define('ITEMS_PER_PAGE', 10);

// Session lifetime (secondes)
define('SESSION_LIFETIME', 3600);

session_start();
?>
